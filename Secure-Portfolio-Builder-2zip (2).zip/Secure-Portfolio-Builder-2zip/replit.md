# Security Archive Portfolio

A personal security and certification portfolio with a public editorial site and an admin dashboard.

## Run & Operate

- `pnpm --filter @workspace/portfolio run dev` — run the portfolio frontend
- `pnpm --filter @workspace/api-server run dev` — run the API server
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string
- Required env: `SESSION_SECRET` — session signing secret
- After installing dependencies, run `pnpm --filter @workspace/db run push` to apply the development schema.

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/portfolio` — React/Vite public portfolio and admin UI
- `artifacts/api-server` — Express API and file serving
- `lib/db/src/schema` — Drizzle PostgreSQL schema
- `lib/api-spec` — OpenAPI source and Orval code generation
- `attached_assets` — frontend image and font assets

## Architecture decisions

- The frontend and API run as separate artifact services, routed through `/` and `/api`.
- The development database schema is applied with Drizzle Kit rather than checked-in migration SQL.
- Portfolio data is loaded from PostgreSQL; an empty database is a valid initial state.

## Product

- Public editorial portfolio homepage with certificate archive and terminal-style content.
- Admin dashboard for profile, certificate, and terminal command content.

## User preferences

_No additional user preferences recorded._

## Gotchas

- Keep the API and portfolio workflows running together because the frontend reads `/api` routes.
- Do not use the API before applying the development database schema.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
