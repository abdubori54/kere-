---
name: Hack the System scope
description: Durable safety and architecture boundaries for the portfolio's fictional security puzzle game.
---

Keep Hack the System as a fictional browser-only learning exercise. It must not call backend APIs, require authentication, connect to external services, or interact with real systems. Its console is a fixed local text simulation with an explicit allowlist; it must never execute commands or make network requests. Browser storage is optional and must not be required to play.

**Why:** The user specified this as a safe, self-contained portfolio exercise rather than an operational security tool.

**How to apply:** Preserve these boundaries when changing game missions, routing, persistence, or console behavior. Keep all evidence fictional and inert.
