---
name: QA Lab scope
description: User-defined constraints for the portfolio's QA practice area.
---

The QA Lab is a frontend-only practice area. Interactive scenarios use local sample data, and recorded test progress, notes, and user-created reports stay in the visitor's browser. Do not add QA-specific backend services, database storage, authentication, dependencies, or external-service calls. Demo credentials must remain fictional and must never be persisted. Portfolio examples must be labeled as samples, not verified client work.

**Why:** The user explicitly scoped this feature as a local practice environment and wants existing portfolio features preserved without expanding infrastructure.

**How to apply:** Preserve these boundaries when changing QA demos, progress storage, bug reporting, or portfolio materials. Existing portfolio APIs are outside this QA-specific constraint.