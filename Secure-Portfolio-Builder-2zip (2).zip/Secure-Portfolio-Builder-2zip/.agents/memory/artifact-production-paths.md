---
name: Artifact production paths
description: Deployment constraints for this pnpm artifact workspace.
---

Standalone artifact builds may not receive the service runtime environment, so Vite configs must have safe build-time defaults for PORT and BASE_PATH while still honoring managed workflow values.

**Why:** The portfolio dev preview supplied those variables, but the production build command could run without them and fail before producing a fresh static bundle.

**How to apply:** When adding or changing a Vite artifact, test its package build directly without manually exported runtime variables.

Bundled API services run from the generated dist entry point, not necessarily the package working directory. Persistent package-local files must resolve relative to the built module location, not process.cwd().

**Why:** The published API started successfully but served tracked certificate uploads as 404s when process.cwd() differed from the API package directory.

**How to apply:** Resolve package-local runtime files from the bundle/artifact location and verify them with the exact production run command.