import { boolean, integer, pgTable, serial, text } from "drizzle-orm/pg-core";

export const securityLabTypesTable = pgTable("security_lab_types", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  label: text("label").notNull(),
  enabled: boolean("enabled").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
});

export type SecurityLabType = typeof securityLabTypesTable.$inferSelect;