import { boolean, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const siteSettingsTable = pgTable("site_settings", {
  id: serial("id").primaryKey(),
  fullName: text("full_name"),
  username: text("username"),
  professionalTitle: text("professional_title"),
  shortBio: text("short_bio"),
  email: text("email"),
  phone: text("phone"),
  location: text("location"),
  githubUrl: text("github_url"),
  linkedinUrl: text("linkedin_url"),
  telegramUrl: text("telegram_url"),
  availabilityStatus: text("availability_status"),
  heroTitle: text("hero_title"),
  heroSubtitle: text("hero_subtitle"),
  contactText: text("contact_text"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export type SiteSettings = typeof siteSettingsTable.$inferSelect;