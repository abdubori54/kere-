import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";

export const terminalCommandsTable = pgTable("terminal_commands", {
  id: serial("id").primaryKey(),
  command: text("command").notNull(),
  response: text("response").notNull(),
  output: text("output").notNull().default(""),
  description: text("description"),
  sortOrder: integer("sort_order").notNull().default(0),
  enabled: boolean("enabled").notNull().default(true),
});

export type TerminalCommand = typeof terminalCommandsTable.$inferSelect;
