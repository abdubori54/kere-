import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const portfolioViewsTable = pgTable("portfolio_views", {
  id: serial("id").primaryKey(),
  path: text("path").notNull().default("/"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});