import { boolean, integer, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const securityLabsTable = pgTable("security_labs", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  shortDescription: text("short_description").notNull(),
  category: text("category").notNull(),
  difficulty: text("difficulty").notNull().default("Beginner"),
  estimatedMinutes: integer("estimated_minutes").notNull().default(5),
  learningObjective: text("learning_objective").notNull(),
  challengeDescription: text("challenge_description").notNull(),
  task: text("task").notNull(),
  hints: text("hints").notNull().default(""),
  expectedResult: text("expected_result").notNull(),
  explanation: text("explanation").notNull(),
  demoType: text("demo_type").notNull().default("generic"),
  published: boolean("published").notNull().default(true),
  enabled: boolean("enabled").notNull().default(true),
  featured: boolean("featured").notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export type SecurityLab = typeof securityLabsTable.$inferSelect;