import type { ReactNode } from "react";

export function QASection({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <section className={`rounded-2xl border border-border/80 bg-card/90 p-5 shadow-sm sm:p-7 ${className}`}>{children}</section>;
}

export function QAKicker({ children }: { children: ReactNode }) {
  return <p className="editorial-kicker mb-2 text-muted-foreground">{children}</p>;
}

export function QAButton({ children, onClick, variant = "solid", type = "button", disabled = false, className = "", ...props }: {
  children: ReactNode; onClick?: () => void; variant?: "solid" | "line" | "quiet" | "danger"; type?: "button" | "submit"; disabled?: boolean; className?: string;
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const style = variant === "solid" ? "bg-foreground text-background hover:bg-foreground/90" : variant === "danger" ? "border border-destructive/40 text-destructive hover:bg-destructive/10" : variant === "quiet" ? "text-muted-foreground hover:bg-muted" : "border border-border bg-card text-foreground hover:border-primary";
  return <button type={type} onClick={onClick} disabled={disabled} className={`inline-flex min-h-10 items-center justify-center gap-2 rounded-full px-4 py-2 text-sm font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary disabled:cursor-not-allowed disabled:opacity-50 ${style} ${className}`} {...props}>{children}</button>;
}

export function QASelect({ value, onChange, options, label, testId }: { value: string; onChange: (value: string) => void; options: string[]; label: string; testId?: string }) {
  return <label className="grid gap-1.5 text-xs font-semibold text-muted-foreground">{label}<select data-testid={testId} value={value} onChange={(event) => onChange(event.target.value)} className="min-h-10 rounded-xl border border-input bg-background px-3 text-sm text-foreground focus-visible:ring-2 focus-visible:ring-primary">{options.map((option) => <option key={option}>{option}</option>)}</select></label>;
}

export function StatusPill({ status }: { status: string }) {
  const tint: Record<string, string> = { Pass: "bg-primary/20 text-foreground", Fail: "bg-destructive/10 text-destructive", Blocked: "bg-accent/15 text-foreground", "Not Run": "bg-muted text-muted-foreground", Open: "bg-accent/15 text-foreground", "In Progress": "bg-primary/15 text-foreground", Fixed: "bg-primary/20 text-foreground", "Re-tested": "bg-primary/20 text-foreground", Closed: "bg-muted text-muted-foreground" };
  return <span className={`inline-flex rounded-full px-2.5 py-1 text-[11px] font-bold ${tint[status] || "bg-muted text-muted-foreground"}`}>{status}</span>;
}