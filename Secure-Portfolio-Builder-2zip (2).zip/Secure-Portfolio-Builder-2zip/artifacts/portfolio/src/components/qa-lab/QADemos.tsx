import { useEffect, useMemo, useState } from "react";
import { ArrowDown, ArrowUp, Check, Eye, EyeOff, Minus, Plus, Search, ShoppingBag, X } from "lucide-react";
import { modules, type ModuleKey } from "./qa-data";
import { QAButton, QASelect, QASection, QAKicker } from "./QASection";

const products = [
  { id: "p1", name: "Field Notes", category: "Stationery", price: 18, desc: "A pocket-sized test journal." },
  { id: "p2", name: "Signal Mug", category: "Desk", price: 24, desc: "A quiet companion for long runs." },
  { id: "p3", name: "Boundary Cards", category: "Learning", price: 32, desc: "Prompts for edge-case thinking." },
  { id: "p4", name: "Patch Set", category: "Desk", price: 12, desc: "Small markers for a big board." },
];
const people = [
  { name: "Amina Patel", role: "QA Analyst", team: "Quality", location: "London" },
  { name: "Jonah Reed", role: "Security Engineer", team: "Security", location: "Austin" },
  { name: "Maya Okafor", role: "QA Analyst", team: "Quality", location: "Toronto" },
  { name: "Theo Martin", role: "Product Designer", team: "Product", location: "London" },
  { name: "Leila Haddad", role: "Frontend Engineer", team: "Engineering", location: "Austin" },
  { name: "Ravi Shah", role: "Security Engineer", team: "Security", location: "Toronto" },
  { name: "Nora Kim", role: "Product Designer", team: "Product", location: "London" },
];

export function QADemos({ initialModule, onSelected }: { initialModule?: ModuleKey; onSelected?: (module: ModuleKey) => void }) {
  const [module, setModule] = useState<ModuleKey>(initialModule || "Authentication");
  useEffect(() => { if (initialModule) setModule(initialModule); }, [initialModule]);
  const chooseModule = (value: ModuleKey) => { setModule(value); onSelected?.(value); };
  return <div id="qa-demos" className="space-y-5">
    <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
      <div><QAKicker>Hands-on scenarios</QAKicker><h2 className="editorial-display text-3xl sm:text-4xl">Try the interface.<br className="sm:hidden" /> Then record what you see.</h2></div>
      <label className="grid gap-1.5 text-xs font-semibold text-muted-foreground">Choose a module<select data-testid="demo-module-select" value={module} onChange={(e) => chooseModule(e.target.value as ModuleKey)} className="min-h-10 min-w-56 rounded-xl border border-input bg-card px-3 text-sm text-foreground focus-visible:ring-2 focus-visible:ring-primary">{modules.map((item) => <option key={item.name}>{item.name}</option>)}</select></label>
    </div>
    {module === "Authentication" && <AuthenticationDemo />}
    {module === "Form validation" && <FormDemo />}
    {module === "E-commerce" && <CommerceDemo />}
    {module === "Directory" && <DirectoryDemo />}
    {module === "UI & responsive" && <UIDemo />}
  </div>;
}

function AuthenticationDemo() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [visible, setVisible] = useState(false);
  const [message, setMessage] = useState("");
  const [kind, setKind] = useState<"error" | "success">("error");
  const [submitting, setSubmitting] = useState(false);
  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    if (submitting) return;
    setSubmitting(true);
    const cleanEmail = email.trim();
    if (!cleanEmail || !password) { setMessage("Email and password are both required."); setKind("error"); setSubmitting(false); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) { setMessage("Enter an email in a valid format."); setKind("error"); setSubmitting(false); return; }
    if (password.length < 8) { setMessage("Demo passwords must be at least 8 characters."); setKind("error"); setSubmitting(false); return; }
    if (cleanEmail === "tester@lab.local" && password === "LabPass!42") { setMessage("Demo accepted. This is not a real sign-in or account."); setKind("success"); }
    else { setMessage("Those demo credentials do not match. Nothing was sent or saved."); setKind("error"); }
    window.setTimeout(() => setSubmitting(false), 250);
  };
  return <QASection className="grid gap-8 lg:grid-cols-[1fr_.8fr]">
    <div><QAKicker>01 / Authentication</QAKicker><h3 className="mb-2 text-xl font-bold">A login that goes nowhere</h3><p className="mb-5 max-w-lg text-sm leading-6 text-muted-foreground">Practice field-level validation against a local-only credential pair. No session is created and passwords are never stored.</p>
      <form onSubmit={submit} className="max-w-md space-y-4" noValidate>
        <label className="grid gap-1.5 text-sm font-semibold">Email<input data-testid="auth-email" autoComplete="off" value={email} onChange={(e) => setEmail(e.target.value)} className="min-h-11 rounded-xl border border-input bg-background px-3 font-normal focus-visible:ring-2 focus-visible:ring-primary" placeholder="name@example.com" /></label>
        <label className="grid gap-1.5 text-sm font-semibold">Password<span className="flex rounded-xl border border-input bg-background focus-within:ring-2 focus-within:ring-primary"><input data-testid="auth-password" autoComplete="new-password" type={visible ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)} className="min-h-11 min-w-0 flex-1 bg-transparent px-3 font-normal outline-none" placeholder="8 characters minimum" /><button type="button" aria-label={visible ? "Hide password" : "Show password"} onClick={() => setVisible(!visible)} className="px-3 text-muted-foreground focus-visible:ring-2 focus-visible:ring-primary">{visible ? <EyeOff size={17} /> : <Eye size={17} />}</button></span></label>
        <QAButton type="submit" disabled={submitting} className="w-full" data-testid="auth-submit">{submitting ? "Checking…" : "Test demo sign-in"}</QAButton>
        {message && <p role="status" data-testid="auth-feedback" className={`rounded-xl p-3 text-sm ${kind === "success" ? "bg-primary/15" : "bg-destructive/10 text-destructive"}`}>{message}</p>}
      </form>
    </div>
    <aside className="rounded-xl bg-muted/70 p-5"><p className="editorial-kicker mb-3 text-muted-foreground">Safe test data</p><p className="mb-3 text-sm">Valid demo pair</p><code className="block rounded-lg bg-background px-3 py-2 text-xs">tester@lab.local<br />LabPass!42</code><p className="mt-4 text-xs leading-5 text-muted-foreground">Try blank fields, malformed email, short passwords and repeated submits. Data stays in this form only.</p></aside>
  </QASection>;
}

function FormDemo() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [feedback, setFeedback] = useState("");
  const [busy, setBusy] = useState(false);
  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    if (busy) return;
    const cleanName = name.trim();
    if (cleanName.length < 2 || cleanName.length > 40) { setFeedback("Name must be 2–40 characters after trimming."); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) { setFeedback("Enter a valid email address."); return; }
    if (message.trim().length > 240) { setFeedback("Message must be 240 characters or fewer."); return; }
    setBusy(true); setFeedback("Form accepted locally. No message was sent.");
    window.setTimeout(() => setBusy(false), 600);
  };
  return <QASection className="grid gap-8 lg:grid-cols-[1fr_.8fr]">
    <div><QAKicker>02 / Form validation</QAKicker><h3 className="mb-2 text-xl font-bold">Boundary check-in</h3><p className="mb-5 text-sm text-muted-foreground">Names are trimmed before checking length; the message is optional.</p>
      <form onSubmit={submit} className="max-w-lg space-y-3" noValidate>
        <label className="grid gap-1 text-sm font-semibold">Name <span className="text-xs font-normal text-muted-foreground">2–40 characters</span><input data-testid="form-name" value={name} maxLength={60} onChange={(e) => setName(e.target.value)} className="min-h-11 rounded-xl border border-input bg-background px-3 font-normal focus-visible:ring-2 focus-visible:ring-primary" /></label>
        <label className="grid gap-1 text-sm font-semibold">Email<input data-testid="form-email" value={email} onChange={(e) => setEmail(e.target.value)} className="min-h-11 rounded-xl border border-input bg-background px-3 font-normal focus-visible:ring-2 focus-visible:ring-primary" /></label>
        <label className="grid gap-1 text-sm font-semibold">Note <span className="text-xs font-normal text-muted-foreground">Optional · 240 character max</span><textarea data-testid="form-message" value={message} onChange={(e) => setMessage(e.target.value)} className="min-h-24 rounded-xl border border-input bg-background p-3 font-normal focus-visible:ring-2 focus-visible:ring-primary" /></label>
        <QAButton type="submit" disabled={busy} data-testid="form-submit">{busy ? "Validating…" : "Validate form"}</QAButton>
        {feedback && <p role="status" data-testid="form-feedback" className="rounded-xl bg-muted p-3 text-sm">{feedback}</p>}
      </form>
    </div><aside className="rounded-xl bg-muted/70 p-5"><p className="editorial-kicker mb-3 text-muted-foreground">Try the edges</p><ul className="space-y-2 text-sm text-muted-foreground"><li>• Spaces only, then submit.</li><li>• 1, 2, 40 and 41 trimmed characters.</li><li>• Special characters and a malformed email.</li><li>• Double-submit while the action is busy.</li></ul></aside>
  </QASection>;
}

function CommerceDemo() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All categories");
  const [sort, setSort] = useState("Featured");
  const [cart, setCart] = useState<Record<string, number>>({});
  const categories = ["All categories", ...Array.from(new Set(products.map((item) => item.category)))];
  const visibleProducts = useMemo(() => products.filter((p) => p.name.toLowerCase().includes(query.trim().toLowerCase()) && (category === "All categories" || p.category === category)).sort((a, b) => sort === "Price: low to high" ? a.price - b.price : sort === "Price: high to low" ? b.price - a.price : a.name.localeCompare(b.name)), [query, category, sort]);
  const count = Object.values(cart).reduce((a, b) => a + b, 0);
  const total = products.reduce((sum, item) => sum + item.price * (cart[item.id] || 0), 0);
  const quantity = (id: string, value: string) => {
    const n = Number(value);
    if (!Number.isInteger(n) || n < 1 || n > 9) return;
    setCart((old) => ({ ...old, [id]: n }));
  };
  return <div className="space-y-4">
    <QASection className="flex flex-col justify-between gap-3 sm:flex-row sm:items-end"><div><QAKicker>03 / E-commerce</QAKicker><h3 className="text-xl font-bold">Test shop, no checkout</h3><p className="mt-1 text-sm text-muted-foreground">Products and cart exist only in component state.</p></div><div className="flex items-center gap-2 rounded-full bg-primary/20 px-4 py-2 text-sm font-semibold"><ShoppingBag size={16} /> {count} in cart · ${total.toFixed(2)}</div></QASection>
    <div className="grid gap-4 lg:grid-cols-[1fr_290px]">
      <QASection>
        <div className="mb-5 grid gap-3 sm:grid-cols-[1fr_180px_190px]">
          <label className="relative"><span className="sr-only">Search products</span><Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" /><input data-testid="shop-search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Find a product" className="min-h-10 w-full rounded-xl border border-input bg-background pl-9 pr-3 text-sm focus-visible:ring-2 focus-visible:ring-primary" /></label>
          <QASelect label="Category" value={category} onChange={setCategory} options={categories} />
          <QASelect label="Sort by" value={sort} onChange={setSort} options={["Featured", "Price: low to high", "Price: high to low"]} />
        </div>
        {visibleProducts.length ? <div className="grid gap-3 sm:grid-cols-2">{visibleProducts.map((product) => <article key={product.id} className="rounded-xl border border-border p-4"><div className="mb-3 flex items-start justify-between"><span className="editorial-kicker text-muted-foreground">{product.category}</span><span className="font-mono text-sm">${product.price}.00</span></div><h4 className="font-bold">{product.name}</h4><p className="mt-1 text-sm text-muted-foreground">{product.desc}</p><QAButton className="mt-4 min-h-9 px-3 text-xs" onClick={() => setCart((old) => ({ ...old, [product.id]: (old[product.id] || 0) + 1 }))}><Plus size={14} /> Add to cart</QAButton></article>)}</div> : <p className="rounded-xl bg-muted p-8 text-center text-sm text-muted-foreground">No products match. Try another search.</p>}
      </QASection>
      <QASection><QAKicker>Cart · {count} items</QAKicker><h4 className="mb-4 text-lg font-bold">Your basket</h4>{!count ? <div className="rounded-xl bg-muted/70 p-5 text-center text-sm text-muted-foreground">Your cart is empty. Add a product to begin.</div> : <div className="space-y-4">{products.filter((p) => cart[p.id]).map((product) => <div key={product.id} className="border-b border-border pb-3"><div className="flex justify-between gap-2 text-sm"><span className="font-semibold">{product.name}</span><span>${(product.price * cart[product.id]).toFixed(2)}</span></div><div className="mt-2 flex items-center gap-2"><QAButton variant="line" className="min-h-8 h-8 w-8 p-0" aria-label={`Decrease ${product.name} quantity`} onClick={() => setCart((old) => { const next = { ...old }; if (next[product.id] <= 1) delete next[product.id]; else next[product.id] -= 1; return next; })}><Minus size={13} /></QAButton><label className="sr-only" htmlFor={`qty-${product.id}`}>Quantity for {product.name}</label><input id={`qty-${product.id}`} data-testid={`quantity-${product.id}`} type="number" min="1" max="9" value={cart[product.id]} onChange={(e) => quantity(product.id, e.target.value)} className="h-8 w-14 rounded-lg border border-input bg-background text-center text-sm" /><QAButton variant="quiet" className="min-h-8 h-8 w-8 p-0" aria-label={`Increase ${product.name} quantity`} onClick={() => setCart((old) => ({ ...old, [product.id]: Math.min(9, old[product.id] + 1) }))}><Plus size={13} /></QAButton><QAButton variant="quiet" className="ml-auto min-h-8 h-8 px-2 text-xs" onClick={() => setCart((old) => { const next = { ...old }; delete next[product.id]; return next; })}>Remove</QAButton></div></div>)}<div className="flex justify-between font-bold"><span>Total</span><span>${total.toFixed(2)}</span></div></div>}</QASection>
    </div>
  </div>;
}

function DirectoryDemo() {
  const [query, setQuery] = useState("");
  const [role, setRole] = useState("All roles");
  const [location, setLocation] = useState("All locations");
  const [sort, setSort] = useState<"asc" | "desc">("asc");
  const [page, setPage] = useState(0);
  const pageSize = 4;
  const filtered = useMemo(() => people.filter((p) => p.name.toLowerCase().includes(query.trim().toLowerCase()) || p.role.toLowerCase().includes(query.trim().toLowerCase())).filter((p) => role === "All roles" || p.role === role).filter((p) => location === "All locations" || p.location === location).sort((a, b) => sort === "asc" ? a.name.localeCompare(b.name) : b.name.localeCompare(a.name)), [query, role, location, sort]);
  const entries = filtered.slice(page * pageSize, (page + 1) * pageSize);
  const change = (fn: () => void) => { fn(); setPage(0); };
  return <QASection>
    <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-end"><div><QAKicker>04 / Directory</QAKicker><h3 className="text-xl font-bold">People in the practice</h3><p className="mt-1 text-sm text-muted-foreground">Search combines with both filters; 4 entries per page.</p></div>
      <div className="grid gap-2 sm:grid-cols-3">
        <label className="relative"><span className="sr-only">Search directory</span><Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" /><input data-testid="directory-search" value={query} onChange={(e) => change(() => setQuery(e.target.value))} placeholder="Name or role" className="min-h-10 rounded-xl border border-input bg-background pl-9 pr-3 text-sm focus-visible:ring-2 focus-visible:ring-primary" /></label>
        <QASelect label="Role" value={role} onChange={(v) => change(() => setRole(v))} options={["All roles", ...Array.from(new Set(people.map((p) => p.role)))]} />
        <QASelect label="Location" value={location} onChange={(v) => change(() => setLocation(v))} options={["All locations", ...Array.from(new Set(people.map((p) => p.location)))]} />
      </div>
    </div>
    <div className="mt-5 overflow-hidden rounded-xl border border-border">
      <div className="grid grid-cols-[1.3fr_1fr_.8fr] bg-muted/70 px-4 py-3 text-[11px] font-bold uppercase tracking-wider text-muted-foreground"><button onClick={() => setSort(sort === "asc" ? "desc" : "asc")} className="flex items-center gap-1 text-left focus-visible:ring-2 focus-visible:ring-primary">Name {sort === "asc" ? <ArrowUp size={12} /> : <ArrowDown size={12} />}</button><span>Role</span><span>Location</span></div>
      {entries.length ? entries.map((person) => <div key={person.name} className="grid grid-cols-[1.3fr_1fr_.8fr] border-t border-border px-4 py-3 text-sm"><span className="font-semibold">{person.name}</span><span className="text-muted-foreground">{person.role}</span><span className="text-muted-foreground">{person.location}</span></div>) : <div className="p-8 text-center"><p className="font-semibold">No matching people</p><p className="mt-1 text-sm text-muted-foreground">Clear a filter or try a different search.</p></div>}
    </div>
    <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground"><span>{filtered.length ? `${page * pageSize + 1}–${Math.min(filtered.length, (page + 1) * pageSize)} of ${filtered.length}` : "0 results"}</span><div className="flex gap-2"><QAButton variant="line" className="min-h-8 h-8 px-3 text-xs" disabled={page === 0} onClick={() => setPage(Math.max(0, page - 1))}>Previous</QAButton><QAButton variant="line" className="min-h-8 h-8 px-3 text-xs" disabled={(page + 1) * pageSize >= filtered.length} onClick={() => setPage(page + 1)}>Next</QAButton></div></div>
  </QASection>;
}

function UIDemo() {
  const [modal, setModal] = useState(false);
  const [state, setState] = useState("Ready");
  useEffect(() => {
    if (!modal) return;
    const onKey = (event: KeyboardEvent) => { if (event.key === "Escape") setModal(false); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [modal]);
  return <QASection>
    <QAKicker>05 / UI & responsive</QAKicker><h3 className="text-xl font-bold">A small interaction playground</h3><p className="mb-5 mt-1 max-w-2xl text-sm text-muted-foreground">Try the modal, use only a keyboard, resize the viewport and inspect the state cards. All controls stay on this page.</p>
    <nav aria-label="Sample demo navigation" className="mb-5 flex flex-wrap gap-2 border-b border-border pb-4">{["Overview", "Methods", "Notes"].map((item, i) => <button key={item} onClick={() => setState(`${item} selected`)} className={`rounded-full px-4 py-2 text-sm focus-visible:ring-2 focus-visible:ring-primary ${state.startsWith(item) ? "bg-foreground text-background" : "bg-muted hover:bg-primary/20"}`}>{item}</button>)}</nav>
    <div className="grid gap-3 sm:grid-cols-3">{[["Ready", "All systems are ready for a manual run."], ["Loading", "Simulated loading state; no request is made."], ["Empty", "There are no pending items to review."], ["Error", "A local example error with a retry control."]].map(([title, copy]) => <article key={title} className="rounded-xl border border-border p-4"><p className="editorial-kicker text-muted-foreground">{title} state</p><p className="my-2 min-h-10 text-sm">{copy}</p>{title === "Error" && <QAButton variant="line" className="min-h-8 px-3 text-xs" onClick={() => setState("Retry selected")}>Retry example</QAButton>}</article>)}</div>
    <div className="mt-5 flex flex-wrap items-center gap-3"><QAButton onClick={() => setModal(true)}>Open accessible dialog</QAButton><p role="status" className="text-sm text-muted-foreground">{state}</p></div>
    {modal && <div className="fixed inset-0 z-[80] flex items-center justify-center bg-foreground/50 p-4" onMouseDown={(e) => { if (e.target === e.currentTarget) setModal(false); }}><section role="dialog" aria-modal="true" aria-labelledby="qa-dialog-title" className="w-full max-w-md rounded-2xl border border-border bg-card p-6 shadow-xl"><div className="flex items-start justify-between"><div><QAKicker>Keyboard check</QAKicker><h4 id="qa-dialog-title" className="text-xl font-bold">Modal is open</h4></div><button autoFocus onClick={() => setModal(false)} aria-label="Close dialog" className="rounded-full p-2 hover:bg-muted focus-visible:ring-2 focus-visible:ring-primary"><X size={18} /></button></div><p className="my-4 text-sm leading-6 text-muted-foreground">Close with Escape, the close button, or the backdrop. The focused close button has a visible keyboard focus ring.</p><QAButton onClick={() => { setModal(false); setState("Dialog confirmed"); }}><Check size={15} /> Confirm and close</QAButton></section></div>}
  </QASection>;
}