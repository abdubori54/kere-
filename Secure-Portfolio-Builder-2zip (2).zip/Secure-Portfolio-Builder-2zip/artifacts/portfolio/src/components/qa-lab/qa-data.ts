export type ModuleKey = "Authentication" | "Form validation" | "E-commerce" | "Directory" | "UI & responsive";
export type TestStatus = "Not Run" | "Pass" | "Fail" | "Blocked";
export type Severity = "Critical" | "High" | "Medium" | "Low";
export type Priority = "P1" | "P2" | "P3" | "P4";
export type BugStatus = "Open" | "In Progress" | "Fixed" | "Re-tested" | "Closed";

export interface TestCase {
  id: string;
  title: string;
  module: ModuleKey;
  preconditions: string;
  steps: string[];
  testData: string;
  expected: string;
  severity: Severity;
  priority: Priority;
}

export interface TestRecord { status: TestStatus; notes: string; updatedAt?: string }
export interface BugReport {
  id: string;
  title: string;
  module: ModuleKey;
  environment: string;
  steps: string;
  expected: string;
  actual: string;
  severity: Severity;
  priority: Priority;
  status: BugStatus;
  createdAt: string;
  updatedAt: string;
  sample?: boolean;
}
export interface QAState {
  tests: Record<string, TestRecord>;
  bugs: BugReport[];
  preferences: { activeTab: string; moduleFilter: string; completedChallenges: string[] };
  activity: { id: string; text: string; at: string }[];
}

export const modules: { name: ModuleKey; key: string; summary: string; icon: string; count: number }[] = [
  { name: "Authentication", key: "auth", summary: "Credential boundaries, field feedback & repeat submits.", icon: "01", count: 3 },
  { name: "Form validation", key: "forms", summary: "Required inputs, boundaries and whitespace behavior.", icon: "02", count: 2 },
  { name: "E-commerce", key: "commerce", summary: "Product discovery, quantities and cart math.", icon: "03", count: 2 },
  { name: "Directory", key: "directory", summary: "Search, combined filters, ordering and pages.", icon: "04", count: 2 },
  { name: "UI & responsive", key: "ui", summary: "Keyboard paths, modal states and responsive behavior.", icon: "05", count: 2 },
];

export const testCases: TestCase[] = [
  { id: "QA-AUTH-01", title: "Accept the documented demo account", module: "Authentication", preconditions: "Open the simulated sign-in panel.", steps: ["Enter the demo email and password.", "Submit once and inspect the feedback."], testData: "tester@lab.local / LabPass!42", expected: "Show a local success state; no account or session is created.", severity: "Medium", priority: "P2" },
  { id: "QA-AUTH-02", title: "Reject an incorrect password", module: "Authentication", preconditions: "The local sign-in form is visible.", steps: ["Enter the demo email with a different password.", "Submit and inspect feedback."], testData: "tester@lab.local / wrong", expected: "Keep the visitor on the demo and show a helpful error.", severity: "High", priority: "P1" },
  { id: "QA-AUTH-03", title: "Validate empty and malformed credentials", module: "Authentication", preconditions: "Sign-in form is clear.", steps: ["Submit blank fields.", "Enter malformed email and a short password."], testData: "not-an-email / 123", expected: "Inline validation appears and invalid values are not accepted.", severity: "Medium", priority: "P2" },
  { id: "QA-FORM-01", title: "Enforce required fields and email format", module: "Form validation", preconditions: "Registration demo is open.", steps: ["Submit with empty fields.", "Enter a malformed email and submit again."], testData: "Blank name / name-at-example", expected: "Required and format messages appear beside relevant inputs.", severity: "High", priority: "P1" },
  { id: "QA-FORM-02", title: "Check input length boundaries", module: "Form validation", preconditions: "Registration demo is open.", steps: ["Try a one-character name.", "Try a name longer than 40 characters.", "Submit a valid boundary value."], testData: "Name length: 1, 40, 41", expected: "Only names from 2 to 40 trimmed characters are accepted.", severity: "Medium", priority: "P2" },
  { id: "QA-CART-01", title: "Update cart quantity and total", module: "E-commerce", preconditions: "Product shelf is loaded.", steps: ["Add a product.", "Increase its quantity and compare the total."], testData: "Field Notes, quantity 2", expected: "Cart line and total reflect quantity × unit price.", severity: "Medium", priority: "P2" },
  { id: "QA-CART-02", title: "Prevent invalid cart quantities", module: "E-commerce", preconditions: "Add any product to cart.", steps: ["Try to decrease below one.", "Enter a non-positive quantity if editable."], testData: "0, -1", expected: "Quantity remains at least one; removal is an explicit action.", severity: "High", priority: "P1" },
  { id: "QA-DIR-01", title: "Search, filter and sort directory results", module: "Directory", preconditions: "Directory sample data is visible.", steps: ["Search a partial name.", "Add a role filter.", "Sort by name in both directions."], testData: "Search: analyst", expected: "Results honor search and filters together and sort consistently.", severity: "Medium", priority: "P2" },
  { id: "QA-DIR-02", title: "Handle no results and pagination", module: "Directory", preconditions: "Directory has multiple entries.", steps: ["Search a nonexistent term.", "Clear search and change result page."], testData: "Search: qzx-nothing", expected: "A composed empty state appears; pagination never shows invalid rows.", severity: "Low", priority: "P3" },
  { id: "QA-UI-01", title: "Operate modal using keyboard and focus", module: "UI & responsive", preconditions: "UI state playground is open.", steps: ["Open the details dialog.", "Close it with Escape and reopen.", "Tab between actions."], testData: "Keyboard only", expected: "Modal can be opened, closed, and navigated with visible focus.", severity: "Medium", priority: "P2" },
  { id: "QA-UI-02", title: "Inspect mobile and async interface states", module: "UI & responsive", preconditions: "Resize viewport to a narrow width.", steps: ["Check nav reflow.", "Trigger empty, loading and error examples."], testData: "Viewport under 390px", expected: "Controls remain reachable and each state is clearly identified.", severity: "Low", priority: "P3" },
];

export const sampleBugs: BugReport[] = [
  { id: "SAMPLE-104", title: "Whitespace-only name bypasses required check", module: "Form validation", environment: "Sample material · Chromium / desktop", steps: "1. Open registration.\n2. Enter spaces in Name.\n3. Submit the form.", expected: "Trimmed empty value should show a required message.", actual: "A whitespace-only value must be rejected after trimming.", severity: "High", priority: "P1", status: "Open", createdAt: "2025-02-12T10:00:00.000Z", updatedAt: "2025-02-12T10:00:00.000Z", sample: true },
  { id: "SAMPLE-108", title: "Directory page count not reset after filtering", module: "Directory", environment: "Sample material · mobile viewport", steps: "1. Navigate to the last directory page.\n2. Apply a restrictive role filter.", expected: "Return to first page and show all matching entries.", actual: "Stale page index can show an empty result despite matches.", severity: "Medium", priority: "P2", status: "In Progress", createdAt: "2025-02-15T14:30:00.000Z", updatedAt: "2025-02-15T14:30:00.000Z", sample: true },
];

export const defaultQAState: QAState = { tests: {}, bugs: [], preferences: { activeTab: "overview", moduleFilter: "All modules", completedChallenges: [] }, activity: [] };
export const emptyTestRecord: TestRecord = { status: "Not Run", notes: "" };