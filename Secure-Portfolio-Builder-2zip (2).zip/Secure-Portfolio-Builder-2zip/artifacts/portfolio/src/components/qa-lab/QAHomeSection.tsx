import { Link } from "wouter";
import { ArrowUpRight, FlaskConical } from "lucide-react";
import { modules, testCases } from "./qa-data";
import { useQALab } from "./use-qa-lab";

export function QAHomeSection() {
  const { state } = useQALab();
  const finished = testCases.filter((test) => ["Pass", "Fail", "Blocked"].includes(state.tests[test.id]?.status || "")).length;
  return <section id="qa-lab-preview" aria-labelledby="qa-home-title" className="relative scroll-mt-24 overflow-hidden rounded-[1.75rem] border border-border bg-card p-6 shadow-sm sm:p-9">
    <div className="grid gap-8 lg:grid-cols-[1fr_1fr] lg:items-center">
      <div><p className="editorial-kicker mb-3 text-muted-foreground">Practice room · no login required</p><h2 id="qa-home-title" className="editorial-display text-4xl sm:text-5xl">QA Testing Lab</h2><p className="mt-3 max-w-xl text-sm leading-6 text-muted-foreground">Explore interactive testing scenarios, discover bugs, and practice real-world QA workflows.</p>
        <div className="mt-5 flex flex-wrap items-center gap-3"><Link href="/qa-lab" data-testid="home-qa-lab-link" className="inline-flex min-h-11 items-center gap-2 rounded-full bg-foreground px-5 text-sm font-semibold text-background transition-colors hover:bg-foreground/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary">Explore QA Lab <ArrowUpRight size={15} /></Link><span className="text-xs text-muted-foreground">{finished} / {testCases.length} tests manually recorded here</span></div>
      </div>
      <div className="grid gap-2 sm:grid-cols-2">
         {modules.map((module) => <Link key={module.name} href="/qa-lab" className="group flex items-start gap-3 rounded-xl border border-border bg-background/65 p-4 transition-colors hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary">
          <span className="font-mono text-xs text-primary">{module.icon}</span><span className="min-w-0"><span className="block text-sm font-bold">{module.name}</span><span className="mt-1 block text-xs leading-5 text-muted-foreground">{module.summary}</span></span><FlaskConical size={14} className="ml-auto mt-1 shrink-0 text-muted-foreground transition-colors group-hover:text-foreground" />
        </Link>)}
      </div>
    </div>
    <div className="mt-6 flex flex-wrap items-center justify-between gap-2 border-t border-border pt-4 text-[11px] text-muted-foreground"><span>Authentication · validation · commerce · directory · responsive UI</span><span>Progress stored only in this browser</span></div>
  </section>;
}