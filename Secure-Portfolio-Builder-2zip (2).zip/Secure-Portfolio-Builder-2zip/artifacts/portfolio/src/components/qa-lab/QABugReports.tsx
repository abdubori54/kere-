import { useMemo, useState } from "react";
import { Download, FilePlus2, Pencil, Search, Trash2, X } from "lucide-react";
import { modules, sampleBugs, type BugReport, type BugStatus, type ModuleKey, type Priority, type QAState, type Severity } from "./qa-data";
import { QAButton, QASelect, QASection, QAKicker, StatusPill } from "./QASection";

type Draft = Omit<BugReport, "id" | "createdAt" | "updatedAt" | "sample">;
const blankDraft: Draft = { title: "", module: "Authentication", environment: "Browser demo · current device", steps: "", expected: "", actual: "", severity: "Medium", priority: "P2", status: "Open" };

function downloadFile(filename: string, content: string, mime: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url; link.download = filename; link.click();
  URL.revokeObjectURL(url);
}

export function QABugReports({ state, saveBug, deleteBug }: { state: QAState; saveBug: (bug: BugReport) => void; deleteBug: (id: string) => void }) {
  const [query, setQuery] = useState("");
  const [moduleFilter, setModuleFilter] = useState("All modules");
  const [statusFilter, setStatusFilter] = useState("All statuses");
  const [sort, setSort] = useState("Newest first");
  const [dialog, setDialog] = useState<"form" | "detail" | null>(null);
  const [current, setCurrent] = useState<BugReport | null>(null);
  const [draft, setDraft] = useState<Draft>(blankDraft);
  const [error, setError] = useState("");
  const reports = useMemo(() => [...sampleBugs, ...state.bugs].filter((bug) => `${bug.id} ${bug.title} ${bug.module} ${bug.actual}`.toLowerCase().includes(query.trim().toLowerCase())).filter((bug) => moduleFilter === "All modules" || bug.module === moduleFilter).filter((bug) => statusFilter === "All statuses" || bug.status === statusFilter).sort((a, b) => sort === "Newest first" ? b.createdAt.localeCompare(a.createdAt) : sort === "Oldest first" ? a.createdAt.localeCompare(b.createdAt) : sort === "Severity" ? ["Critical", "High", "Medium", "Low"].indexOf(a.severity) - ["Critical", "High", "Medium", "Low"].indexOf(b.severity) : a.title.localeCompare(b.title)), [state.bugs, query, moduleFilter, statusFilter, sort]);
  const exportRows = (format: "json" | "csv") => {
    if (format === "json") downloadFile("qa-bug-reports.json", JSON.stringify(reports, null, 2), "application/json");
    else {
      const cols: (keyof BugReport)[] = ["id", "title", "module", "environment", "steps", "expected", "actual", "severity", "priority", "status", "createdAt", "sample"];
      const cell = (value: unknown) => `"${String(value ?? "").replaceAll('"', '""')}"`;
      downloadFile("qa-bug-reports.csv", [cols.join(","), ...reports.map((bug) => cols.map((key) => cell(bug[key])).join(","))].join("\r\n"), "text/csv;charset=utf-8");
    }
  };
  const openNew = () => { setCurrent(null); setDraft(blankDraft); setError(""); setDialog("form"); };
  const openEdit = (bug: BugReport) => { setCurrent(bug); setDraft({ title: bug.title, module: bug.module, environment: bug.environment, steps: bug.steps, expected: bug.expected, actual: bug.actual, severity: bug.severity, priority: bug.priority, status: bug.status }); setError(""); setDialog("form"); };
  const showDetail = (bug: BugReport) => { setCurrent(bug); setDialog("detail"); };
  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    if (!draft.title.trim() || !draft.steps.trim() || !draft.expected.trim() || !draft.actual.trim()) { setError("Title, steps, expected and actual results are required."); return; }
    const now = new Date().toISOString();
    saveBug({ ...draft, title: draft.title.trim(), environment: draft.environment.trim(), id: current?.id || `BUG-${new Date().getFullYear()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`, createdAt: current?.createdAt || now, updatedAt: now });
    setDialog(null);
  };
  const erase = (bug: BugReport) => {
    if (bug.sample) return;
    if (window.confirm(`Delete ${bug.id} — ${bug.title}? This only removes this browser's local copy.`)) deleteBug(bug.id);
  };
  return <div className="space-y-5">
    <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><QAKicker>Defect notebook</QAKicker><h2 className="editorial-display text-3xl sm:text-4xl">Bug reports</h2><p className="mt-2 text-sm text-muted-foreground">Reports stay on this device. Sample portfolio examples are clearly marked.</p></div><QAButton onClick={openNew} data-testid="bug-create"><FilePlus2 size={16} /> New report</QAButton></div>
    <QASection className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <label className="relative sm:col-span-2"><span className="sr-only">Search bug reports</span><Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" /><input data-testid="bug-search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search reports…" className="min-h-10 w-full rounded-xl border border-input bg-background pl-9 pr-3 text-sm focus-visible:ring-2 focus-visible:ring-primary" /></label>
        <QASelect label="Module" value={moduleFilter} onChange={setModuleFilter} options={["All modules", ...modules.map((item) => item.name)]} testId="bug-module-filter" />
        <QASelect label="Status" value={statusFilter} onChange={setStatusFilter} options={["All statuses", "Open", "In Progress", "Fixed", "Re-tested", "Closed"]} testId="bug-status-filter" />
      </div>
      <div className="flex flex-wrap items-end justify-between gap-3 border-t border-border pt-4"><QASelect label="Sort reports" value={sort} onChange={setSort} options={["Newest first", "Oldest first", "Severity", "Title"]} /><div className="flex flex-wrap gap-2"><QAButton variant="line" className="min-h-9 px-3 text-xs" onClick={() => exportRows("csv")} data-testid="bugs-export-csv"><Download size={14} /> Export CSV</QAButton><QAButton variant="line" className="min-h-9 px-3 text-xs" onClick={() => exportRows("json")} data-testid="bugs-export-json"><Download size={14} /> Export JSON</QAButton></div></div>
      <div className="space-y-2">
        {reports.map((bug) => <article key={bug.id} data-testid={`bug-row-${bug.id}`} className="flex flex-col justify-between gap-4 rounded-xl border border-border p-4 sm:flex-row sm:items-center">
          <button onClick={() => showDetail(bug)} className="min-w-0 flex-1 text-left focus-visible:ring-2 focus-visible:ring-primary"><div className="flex flex-wrap items-center gap-2"><span className="font-mono text-[11px] text-muted-foreground">{bug.id}</span>{bug.sample && <span className="rounded-full border border-accent/40 bg-accent/10 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider">Sample material</span>}<StatusPill status={bug.status} /></div><h3 className="mt-2 font-bold">{bug.title}</h3><p className="mt-1 text-xs text-muted-foreground">{bug.module} · {bug.severity} severity · {bug.priority} priority</p></button>
          <div className="flex items-center gap-2"><QAButton variant="line" className="min-h-9 px-3 text-xs" onClick={() => showDetail(bug)}>Details</QAButton>{!bug.sample && <><QAButton variant="line" className="min-h-9 px-3 text-xs" onClick={() => openEdit(bug)} aria-label={`Edit ${bug.id}`}><Pencil size={14} /> Edit</QAButton><QAButton variant="danger" className="min-h-9 px-3 text-xs" onClick={() => erase(bug)} aria-label={`Delete ${bug.id}`}><Trash2 size={14} /></QAButton></>}</div>
        </article>)}
        {reports.length === 0 && <div className="rounded-xl bg-muted/70 p-10 text-center"><p className="font-bold">No reports found</p><p className="mt-1 text-sm text-muted-foreground">Try clearing a filter, or start a new local report.</p><QAButton variant="line" className="mt-4" onClick={openNew}>Create a report</QAButton></div>}
      </div>
    </QASection>
    {dialog === "form" && <div className="fixed inset-0 z-[90] flex items-center justify-center overflow-y-auto bg-foreground/55 p-3 sm:p-6" role="presentation" onMouseDown={(e) => { if (e.target === e.currentTarget) setDialog(null); }}><section role="dialog" aria-modal="true" aria-labelledby="bug-dialog-title" className="my-auto max-h-[94dvh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-border bg-card p-5 shadow-xl sm:p-7"><div className="flex justify-between"><div><QAKicker>Local report</QAKicker><h3 id="bug-dialog-title" className="editorial-display text-3xl">{current ? "Edit report" : "New bug report"}</h3></div><button onClick={() => setDialog(null)} aria-label="Close report form" className="h-10 w-10 rounded-full hover:bg-muted focus-visible:ring-2 focus-visible:ring-primary"><X size={18} className="mx-auto" /></button></div>
      <form onSubmit={submit} className="mt-5 grid gap-4 sm:grid-cols-2">
        <label className="grid gap-1.5 text-sm font-semibold sm:col-span-2">Title<input data-testid="bug-title" value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} className="min-h-10 rounded-xl border border-input bg-background px-3 font-normal focus-visible:ring-2 focus-visible:ring-primary" /></label>
        <QASelect label="Module" value={draft.module} onChange={(v) => setDraft({ ...draft, module: v as ModuleKey })} options={modules.map((item) => item.name)} />
        <label className="grid gap-1.5 text-xs font-semibold text-muted-foreground">Environment<input value={draft.environment} onChange={(e) => setDraft({ ...draft, environment: e.target.value })} className="min-h-10 rounded-xl border border-input bg-background px-3 text-sm font-normal text-foreground focus-visible:ring-2 focus-visible:ring-primary" /></label>
        <label className="grid gap-1.5 text-sm font-semibold sm:col-span-2">Steps to reproduce<textarea data-testid="bug-steps" rows={3} value={draft.steps} onChange={(e) => setDraft({ ...draft, steps: e.target.value })} className="rounded-xl border border-input bg-background p-3 font-normal focus-visible:ring-2 focus-visible:ring-primary" /></label>
        <label className="grid gap-1.5 text-sm font-semibold">Expected result<textarea value={draft.expected} onChange={(e) => setDraft({ ...draft, expected: e.target.value })} rows={3} className="rounded-xl border border-input bg-background p-3 font-normal focus-visible:ring-2 focus-visible:ring-primary" /></label>
        <label className="grid gap-1.5 text-sm font-semibold">Actual result<textarea value={draft.actual} onChange={(e) => setDraft({ ...draft, actual: e.target.value })} rows={3} className="rounded-xl border border-input bg-background p-3 font-normal focus-visible:ring-2 focus-visible:ring-primary" /></label>
        <QASelect label="Severity" value={draft.severity} onChange={(v) => setDraft({ ...draft, severity: v as Severity })} options={["Critical", "High", "Medium", "Low"]} />
        <QASelect label="Priority" value={draft.priority} onChange={(v) => setDraft({ ...draft, priority: v as Priority })} options={["P1", "P2", "P3", "P4"]} />
        <QASelect label="Status" value={draft.status} onChange={(v) => setDraft({ ...draft, status: v as BugStatus })} options={["Open", "In Progress", "Fixed", "Re-tested", "Closed"]} />
        {error && <p role="alert" className="text-sm text-destructive sm:col-span-2">{error}</p>}
        <div className="flex justify-end gap-2 pt-2 sm:col-span-2"><QAButton variant="line" onClick={() => setDialog(null)}>Cancel</QAButton><QAButton type="submit" data-testid="bug-save">{current ? "Save changes" : "Save locally"}</QAButton></div>
      </form></section></div>}
    {dialog === "detail" && current && <div className="fixed inset-0 z-[90] flex items-center justify-center overflow-y-auto bg-foreground/55 p-3 sm:p-6" onMouseDown={(e) => { if (e.target === e.currentTarget) setDialog(null); }}><section role="dialog" aria-modal="true" aria-labelledby="bug-detail-title" className="my-auto max-h-[90dvh] w-full max-w-xl overflow-y-auto rounded-2xl border border-border bg-card p-6 shadow-xl"><div className="flex justify-between"><div><QAKicker>{current.sample ? "Sample portfolio material · not verified client work" : "Browser-local report"} · {current.id}</QAKicker><h3 id="bug-detail-title" className="editorial-display text-3xl">{current.title}</h3></div><button onClick={() => setDialog(null)} aria-label="Close bug details" className="h-10 w-10 rounded-full hover:bg-muted focus-visible:ring-2 focus-visible:ring-primary"><X size={18} className="mx-auto" /></button></div>
      <div className="mt-4 flex flex-wrap gap-2"><StatusPill status={current.status} /><span className="rounded-full bg-muted px-3 py-1 text-xs">{current.module}</span><span className="rounded-full bg-muted px-3 py-1 text-xs">{current.severity} · {current.priority}</span></div>
      <div className="mt-5 space-y-4 text-sm"><Detail title="Environment" text={current.environment} /><Detail title="Steps to reproduce" text={current.steps} /><Detail title="Expected" text={current.expected} /><Detail title="Actual" text={current.actual} /></div>
      <div className="mt-6 flex justify-end gap-2">{!current.sample && <><QAButton variant="line" onClick={() => openEdit(current)}>Edit</QAButton><QAButton variant="danger" onClick={() => { erase(current); setDialog(null); }}>Delete</QAButton></>}<QAButton onClick={() => setDialog(null)}>Close</QAButton></div>
    </section></div>}
  </div>;
}

function Detail({ title, text }: { title: string; text: string }) {
  return <div><h4 className="editorial-kicker text-muted-foreground">{title}</h4><p className="mt-1 whitespace-pre-wrap leading-6">{text}</p></div>;
}