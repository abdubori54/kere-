import { useCallback, useEffect, useState } from "react";
import { defaultQAState, emptyTestRecord, modules, testCases, type BugReport, type QAState, type TestStatus } from "./qa-data";

const STORAGE_KEY = "secure-portfolio-qa-lab-v1";

function loadState(): QAState {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultQAState;
    const parsed: unknown = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return defaultQAState;
    const value = parsed as Partial<QAState>;
    const allowedModules = modules.map((item) => item.name);
    const allowedStatuses = ["Not Run", "Pass", "Fail", "Blocked"];
    const validTests: QAState["tests"] = {};
    if (value.tests && typeof value.tests === "object" && !Array.isArray(value.tests)) {
      for (const test of testCases) {
        const record = value.tests[test.id];
        if (!record || typeof record !== "object") continue;
        validTests[test.id] = {
          status: allowedStatuses.includes(record.status) ? record.status : "Not Run",
          notes: typeof record.notes === "string" ? record.notes.slice(0, 10000) : "",
          updatedAt: typeof record.updatedAt === "string" && !Number.isNaN(Date.parse(record.updatedAt)) ? record.updatedAt : undefined,
        };
      }
    }
    const validBugs = Array.isArray(value.bugs) ? value.bugs.filter((bug): bug is BugReport => {
      if (!bug || typeof bug !== "object" || bug.sample) return false;
      return typeof bug.id === "string" && typeof bug.title === "string" && typeof bug.environment === "string"
        && typeof bug.steps === "string" && typeof bug.expected === "string" && typeof bug.actual === "string"
        && allowedModules.includes(bug.module) && ["Critical", "High", "Medium", "Low"].includes(bug.severity)
        && ["P1", "P2", "P3", "P4"].includes(bug.priority)
        && ["Open", "In Progress", "Fixed", "Re-tested", "Closed"].includes(bug.status);
    }).map((bug) => ({ ...bug, title: bug.title.slice(0, 240), steps: bug.steps.slice(0, 10000), expected: bug.expected.slice(0, 5000), actual: bug.actual.slice(0, 5000) })) : [];
    return {
      tests: validTests,
      bugs: validBugs,
      preferences: {
        activeTab: typeof value.preferences?.activeTab === "string" ? value.preferences.activeTab : defaultQAState.preferences.activeTab,
        moduleFilter: typeof value.preferences?.moduleFilter === "string" ? value.preferences.moduleFilter : defaultQAState.preferences.moduleFilter,
        completedChallenges: Array.isArray(value.preferences?.completedChallenges) ? value.preferences.completedChallenges.filter((item): item is string => typeof item === "string").slice(0, 40) : [],
      },
      activity: Array.isArray(value.activity) ? value.activity.filter((item) => item && typeof item.id === "string" && typeof item.text === "string" && typeof item.at === "string").slice(0, 30) : [],
    };
  } catch {
    return defaultQAState;
  }
}

export function useQALab() {
  const [state, setState] = useState<QAState>(() => typeof window === "undefined" ? defaultQAState : loadState());
  const [storageMessage, setStorageMessage] = useState("");

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      setStorageMessage("");
    } catch {
      setStorageMessage("Browser storage is unavailable or full. Changes remain only until this page is closed.");
    }
  }, [state]);

  const recordActivity = useCallback((text: string, existing: QAState) => [
    { id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, text, at: new Date().toISOString() },
    ...existing.activity,
  ].slice(0, 30), []);

  const setTestResult = useCallback((id: string, status: TestStatus, notes?: string) => {
    setState((current) => {
      const previous = current.tests[id] || emptyTestRecord;
      const nextRecord = { ...previous, status, notes: notes ?? previous.notes, updatedAt: new Date().toISOString() };
      return { ...current, tests: { ...current.tests, [id]: nextRecord }, activity: recordActivity(`${id} marked ${status.toLowerCase()}`, current) };
    });
  }, [recordActivity]);

  const saveTestNotes = useCallback((id: string, notes: string) => {
    setState((current) => ({ ...current, tests: { ...current.tests, [id]: { ...(current.tests[id] || emptyTestRecord), notes } } }));
  }, []);

  const saveBug = useCallback((bug: BugReport) => {
    setState((current) => {
      const exists = current.bugs.some((item) => item.id === bug.id);
      const bugs = exists ? current.bugs.map((item) => item.id === bug.id ? bug : item) : [bug, ...current.bugs];
      return { ...current, bugs, activity: recordActivity(`${exists ? "Updated" : "Created"} ${bug.id}: ${bug.title}`, current) };
    });
  }, [recordActivity]);

  const deleteBug = useCallback((id: string) => setState((current) => {
    const bug = current.bugs.find((item) => item.id === id);
    return { ...current, bugs: current.bugs.filter((item) => item.id !== id), activity: recordActivity(`Deleted ${id}${bug ? `: ${bug.title}` : ""}`, current) };
  }), [recordActivity]);

  const updatePreferences = useCallback((preferences: Partial<QAState["preferences"]>) => {
    setState((current) => ({ ...current, preferences: { ...current.preferences, ...preferences } }));
  }, []);

  const reset = useCallback(() => {
    setState(defaultQAState);
    try {
      window.localStorage.removeItem(STORAGE_KEY);
      setStorageMessage("");
    } catch {
      setStorageMessage("Could not clear browser storage. Clear this site's storage in your browser settings.");
    }
  }, []);

  return { state, storageMessage, setTestResult, saveTestNotes, saveBug, deleteBug, updatePreferences, reset };
}