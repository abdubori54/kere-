import { useMemo, useState } from "react";
import { ArrowRight, RotateCcw } from "lucide-react";
import { emptyTestRecord, modules, testCases, type ModuleKey, type TestStatus } from "./qa-data";
import type { QAState } from "./qa-data";
import { QAButton, QASelect, QASection, QAKicker, StatusPill } from "./QASection";

export function QATestRunner({ state, setTestResult, saveTestNotes, onRunScenario }: {
  state: QAState;
  setTestResult: (id: string, status: TestStatus, notes?: string) => void;
  saveTestNotes: (id: string, notes: string) => void;
  onRunScenario: (module: ModuleKey) => void;
}) {
  const [moduleFilter, setModuleFilter] = useState("All modules");
  const [statusFilter, setStatusFilter] = useState("All statuses");
  const [openId, setOpenId] = useState<string | null>(testCases[0]?.id || null);
  const filtered = useMemo(() => testCases.filter((item) => (moduleFilter === "All modules" || item.module === moduleFilter) && (statusFilter === "All statuses" || (state.tests[item.id]?.status || "Not Run") === statusFilter)), [moduleFilter, statusFilter, state.tests]);
  const statuses: TestStatus[] = ["Not Run", "Pass", "Fail", "Blocked"];
  const complete = testCases.filter((item) => (state.tests[item.id]?.status || "Not Run") !== "Not Run").length;
  return <div className="space-y-5">
    <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><QAKicker>Execution log</QAKicker><h2 className="editorial-display text-3xl sm:text-4xl">Test case runner</h2><p className="mt-2 text-sm text-muted-foreground">Every result is yours to record. Nothing is auto-passed.</p></div><div className="min-w-56 rounded-xl bg-primary/20 p-4"><div className="flex items-baseline justify-between"><span className="text-sm font-semibold">Execution progress</span><span className="font-mono text-sm">{complete}/{testCases.length}</span></div><div className="mt-3 h-2 overflow-hidden rounded-full bg-background"><div className="h-full rounded-full bg-foreground transition-all" style={{ width: `${(complete / testCases.length) * 100}%` }} /></div><p className="mt-2 text-xs text-muted-foreground">Manually recorded results</p></div></div>
    <div className="grid gap-3 sm:grid-cols-2"><QASelect label="Filter by module" value={moduleFilter} onChange={setModuleFilter} options={["All modules", ...modules.map((item) => item.name)]} testId="test-module-filter" /><QASelect label="Filter by status" value={statusFilter} onChange={setStatusFilter} options={["All statuses", ...statuses]} testId="test-status-filter" /></div>
    <div className="space-y-3">{filtered.map((test) => {
      const record = state.tests[test.id] || emptyTestRecord;
      const isOpen = openId === test.id;
      return <QASection key={test.id} className="p-0">
        <button data-testid={`testcase-toggle-${test.id}`} aria-expanded={isOpen} onClick={() => setOpenId(isOpen ? null : test.id)} className="flex w-full flex-wrap items-center justify-between gap-3 p-5 text-left focus-visible:ring-2 focus-visible:ring-primary sm:p-6">
          <span className="flex min-w-0 items-start gap-3"><span className="font-mono text-xs text-muted-foreground">{test.id}</span><span><span className="block font-bold">{test.title}</span><span className="mt-1 block text-xs text-muted-foreground">{test.module} · {test.severity} severity · {test.priority}</span></span></span><StatusPill status={record.status} />
        </button>
        {isOpen && <div className="border-t border-border px-5 pb-5 pt-4 sm:px-6 sm:pb-6">
          <div className="grid gap-5 lg:grid-cols-[1fr_300px]">
            <div className="grid gap-4 text-sm sm:grid-cols-2">
              <div><p className="editorial-kicker text-muted-foreground">Preconditions</p><p className="mt-1 leading-6">{test.preconditions}</p></div>
              <div><p className="editorial-kicker text-muted-foreground">Test data</p><p className="mt-1 rounded-lg bg-muted p-3 font-mono text-xs">{test.testData}</p></div>
              <div><p className="editorial-kicker text-muted-foreground">Steps</p><ol className="mt-1 list-inside list-decimal space-y-1 text-muted-foreground">{test.steps.map((step) => <li key={step}>{step}</li>)}</ol></div>
              <div><p className="editorial-kicker text-muted-foreground">Expected result</p><p className="mt-1 leading-6 text-muted-foreground">{test.expected}</p></div>
            </div>
            <aside className="space-y-3 rounded-xl bg-muted/60 p-4">
              <QAButton variant="line" className="w-full" onClick={() => onRunScenario(test.module)}>Open matching demo <ArrowRight size={14} /></QAButton>
              <label className="grid gap-1.5 text-xs font-semibold text-muted-foreground">Actual result / tester notes<textarea data-testid={`test-notes-${test.id}`} value={record.notes} onChange={(e) => saveTestNotes(test.id, e.target.value)} rows={3} placeholder="Record what happened…" className="rounded-xl border border-input bg-background p-3 text-sm font-normal text-foreground focus-visible:ring-2 focus-visible:ring-primary" /></label>
              <div className="grid grid-cols-2 gap-2">{(["Pass", "Fail", "Blocked"] as TestStatus[]).map((status) => <QAButton key={status} data-testid={`test-status-${test.id}-${status.toLowerCase()}`} variant={record.status === status ? "solid" : "line"} className="min-h-9 px-3 text-xs" onClick={() => setTestResult(test.id, status)}>{status}</QAButton>)}</div>
              <QAButton variant="quiet" className="w-full min-h-8 text-xs" onClick={() => { setTestResult(test.id, "Not Run", ""); saveTestNotes(test.id, ""); }}><RotateCcw size={13} /> Reset / rerun</QAButton>
              {record.updatedAt && <p className="text-[10px] text-muted-foreground">Last status change {new Date(record.updatedAt).toLocaleString()}</p>}
            </aside>
          </div>
        </div>}
      </QASection>;
    })}{filtered.length === 0 && <QASection className="py-12 text-center"><p className="font-semibold">No test cases in this view</p><p className="mt-1 text-sm text-muted-foreground">Choose another module or status filter.</p></QASection>}</div>
  </div>;
}