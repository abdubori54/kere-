import { useMemo, useState } from "react";
import { Activity, ArrowRight, CheckCircle2, CircleDashed, CircleSlash, TriangleAlert } from "lucide-react";
import { modules, sampleBugs, testCases, type ModuleKey, type QAState, type TestStatus } from "./qa-data";
import { QAButton, QASelect, QASection, QAKicker, StatusPill } from "./QASection";

export function QAOverview({ state, onNavigate }: { state: QAState; onNavigate: (tab: string) => void }) {
  const [moduleFilter, setModuleFilter] = useState("All modules");
  const [statusFilter, setStatusFilter] = useState("All statuses");
  const filtered = useMemo(() => testCases.filter((test) => (moduleFilter === "All modules" || test.module === moduleFilter) && (statusFilter === "All statuses" || (state.tests[test.id]?.status || "Not Run") === statusFilter)), [moduleFilter, statusFilter, state.tests]);
  const totals = useMemo(() => {
    const result: Record<TestStatus, number> = { "Not Run": 0, Pass: 0, Fail: 0, Blocked: 0 };
    testCases.forEach((test) => { result[state.tests[test.id]?.status || "Not Run"] += 1; });
    return result;
  }, [state.tests]);
  const allBugs = [...sampleBugs, ...state.bugs];
  const severity = ["Critical", "High", "Medium", "Low"] as const;
  const severityCounts = severity.map((level) => ({ level, count: allBugs.filter((bug) => bug.severity === level).length }));
  const cards = [
    { label: "Test cases", value: testCases.length, detail: "in the static suite", icon: CircleDashed, accent: "bg-muted" },
    { label: "Passed", value: totals.Pass, detail: "manually recorded", icon: CheckCircle2, accent: "bg-primary/25" },
    { label: "Failed", value: totals.Fail, detail: "needs investigation", icon: TriangleAlert, accent: "bg-destructive/10" },
    { label: "Blocked", value: totals.Blocked, detail: "awaiting a condition", icon: CircleSlash, accent: "bg-accent/15" },
    { label: "Not run", value: totals["Not Run"], detail: "waiting for a manual run", icon: CircleDashed, accent: "bg-muted" },
  ];
  const progress = Math.round(((totals.Pass + totals.Fail + totals.Blocked) / testCases.length) * 100);
  return <div className="space-y-6">
    <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><QAKicker>At a glance · this browser</QAKicker><h2 className="editorial-display text-3xl sm:text-4xl">A clear view of the work.</h2><p className="mt-2 max-w-xl text-sm leading-6 text-muted-foreground">Execution stats are calculated from your current local test records. Sample defects are included in the bug breakdown and stay labeled as samples.</p></div><QAButton variant="line" onClick={() => onNavigate("tests")}>Open test runner <ArrowRight size={15} /></QAButton></div>
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-5">{cards.map(({ label, value, detail, icon: Icon, accent }) => <article key={label} data-testid={`stat-${label.toLowerCase().replaceAll(" ", "-")}`} className="rounded-2xl border border-border bg-card p-5"><div className="flex items-center justify-between"><span className="text-sm font-semibold text-muted-foreground">{label}</span><span className={`flex h-9 w-9 items-center justify-center rounded-xl ${accent}`}><Icon size={17} /></span></div><p className="mt-4 font-mono text-4xl">{value}</p><p className="mt-1 text-xs text-muted-foreground">{detail}</p></article>)}</div>
    <div className="grid gap-5 lg:grid-cols-[1.15fr_.85fr]">
      <QASection>
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><QAKicker>Run ledger</QAKicker><h3 className="text-xl font-bold">Test execution</h3></div><p className="font-mono text-sm">{progress}% recorded</p></div>
        <div className="mt-4 h-2 overflow-hidden rounded-full bg-muted"><div className="h-full rounded-full bg-primary transition-all" style={{ width: `${progress}%` }} /></div>
        <div className="mt-5 grid gap-3 sm:grid-cols-2"><QASelect label="Module filter" value={moduleFilter} onChange={setModuleFilter} options={["All modules", ...modules.map((item) => item.name)]} testId="dashboard-module-filter" /><QASelect label="Status filter" value={statusFilter} onChange={setStatusFilter} options={["All statuses", "Not Run", "Pass", "Fail", "Blocked"]} testId="dashboard-status-filter" /></div>
        <div className="mt-4 divide-y divide-border">{filtered.slice(0, 6).map((test) => <div key={test.id} className="flex items-center justify-between gap-3 py-3"><div className="min-w-0"><p className="truncate text-sm font-semibold">{test.title}</p><p className="mt-1 font-mono text-[10px] text-muted-foreground">{test.id} · {test.module}</p></div><StatusPill status={state.tests[test.id]?.status || "Not Run"} /></div>)}</div>
        {filtered.length === 0 && <p className="py-8 text-center text-sm text-muted-foreground">No scenarios match those filters.</p>}
        <button onClick={() => onNavigate("tests")} className="mt-3 text-sm font-semibold underline decoration-primary underline-offset-4 focus-visible:ring-2 focus-visible:ring-primary">View all {testCases.length} test cases</button>
      </QASection>
      <div className="space-y-5">
        <QASection><QAKicker>Defect landscape</QAKicker><div className="flex items-end justify-between"><h3 className="text-xl font-bold">Bug reports</h3><span className="font-mono text-2xl">{allBugs.length}</span></div><p className="mb-4 mt-1 text-xs text-muted-foreground">Includes {sampleBugs.length} labeled sample portfolio records</p><div className="space-y-3">{severityCounts.map(({ level, count }) => <div key={level}><div className="mb-1 flex justify-between text-xs"><span>{level}</span><span className="font-mono">{count}</span></div><div className="h-1.5 rounded-full bg-muted"><div className={`h-full rounded-full ${level === "Critical" || level === "High" ? "bg-accent" : "bg-primary"}`} style={{ width: `${allBugs.length ? Math.max(count / allBugs.length * 100, count ? 7 : 0) : 0}%` }} /></div></div>)}</div><QAButton variant="line" className="mt-5 min-h-9 w-full text-xs" onClick={() => onNavigate("bugs")}>Browse bug notebook <ArrowRight size={14} /></QAButton></QASection>
        <QASection><div className="flex items-center justify-between"><div><QAKicker>Recent activity</QAKicker><h3 className="text-lg font-bold">Latest updates</h3></div><Activity size={18} className="text-muted-foreground" /></div>{state.activity.length ? <ol className="mt-4 space-y-3">{state.activity.slice(0, 5).map((item) => <li key={item.id} className="border-l-2 border-primary pl-3"><p className="text-sm">{item.text}</p><time className="mt-1 block text-[10px] text-muted-foreground">{new Date(item.at).toLocaleString()}</time></li>)}</ol> : <p className="mt-3 rounded-xl bg-muted/70 p-4 text-sm text-muted-foreground">Nothing logged yet. Record a test result or create a report to start your local activity trail.</p>}</QASection>
      </div>
    </div>
  </div>;
}

export function QAPortfolio({ state, updatePreferences }: { state: QAState; updatePreferences: (value: Partial<QAState["preferences"]>) => void }) {
  const samples = [
    { id: "test-doc", eyebrow: "01 · Test documentation", title: "Scenario with a point of view", description: "A concise case has preconditions, steps, data and observable expected outcomes—then leaves the actual result to the tester.", details: "Example: QA-DIR-01 combines partial search, a role filter and bidirectional sorting to expose interaction defects." },
    { id: "boundary", eyebrow: "02 · Boundary-value analysis", title: "Test the edge, not just the middle", description: "For a 2–40 character name, probe 1, 2, 40 and 41 characters, plus trimmed whitespace.", details: "Each boundary tests both sides of the acceptance rule. Special characters and normalization are considered separately." },
    { id: "equivalence", eyebrow: "03 · Equivalence partitioning", title: "Group inputs by behavior", description: "Valid email, malformed email and empty email form distinct partitions with different expected feedback.", details: "A representative value from each partition gives useful coverage without testing every possible string." },
    { id: "positive-negative", eyebrow: "04 · Positive + negative", title: "Pair the happy path with rejection", description: "Use the documented demo login once successfully, then inspect malformed, empty and incorrect credentials.", details: "The UI is a local simulation. No real identity system is present and no password is persisted." },
    { id: "regression", eyebrow: "05 · Regression checklist", title: "Recheck adjacent behavior", description: "After a form change, rerun required/email validation, boundaries, double-submit, keyboard focus and success feedback.", details: "Regression is scoped to observable behavior, not a claim that a production release has been tested." },
    { id: "exploratory", eyebrow: "06 · Exploratory notes", title: "Follow a question", description: "What changes if search is whitespace? What if a filter is applied from page two? Can a keyboard user dismiss the dialog?", details: "Record the path, context and evidence before proposing a cause. These notes are practice prompts, not verified defects." },
  ];
  const completed = state.preferences.completedChallenges || [];
  const toggle = (id: string) => updatePreferences({ completedChallenges: completed.includes(id) ? completed.filter((item) => item !== id) : [...completed, id] });
  return <div className="space-y-5">
    <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><QAKicker>Practice notes · {completed.length}/{samples.length} reviewed</QAKicker><h2 className="editorial-display text-3xl sm:text-4xl">How I test the edges.</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">Sample portfolio materials only—not verified client work, production testing, or client outcomes. Check off a card to save your reading progress in this browser.</p></div></div>
    <div className="grid gap-3 md:grid-cols-2">{samples.map((sample, index) => {
      const done = completed.includes(sample.id);
      return <article key={sample.id} className={`rounded-2xl border border-border bg-card p-5 sm:p-6 ${index === 0 ? "md:row-span-2 md:flex md:flex-col md:justify-between md:bg-foreground md:text-background" : ""}`}>
        <div><p className={`editorial-kicker ${index === 0 ? "text-primary" : "text-muted-foreground"}`}>{sample.eyebrow}</p><h3 className="editorial-display mt-3 text-2xl">{sample.title}</h3><p className={`mt-3 text-sm leading-6 ${index === 0 ? "text-background/75" : "text-muted-foreground"}`}>{sample.description}</p><p className={`mt-4 border-l-2 border-primary pl-3 text-xs leading-5 ${index === 0 ? "text-background/65" : "text-muted-foreground"}`}>{sample.details}</p></div>
        <button data-testid={`challenge-${sample.id}`} aria-pressed={done} onClick={() => toggle(sample.id)} className={`mt-5 inline-flex items-center gap-2 text-xs font-bold focus-visible:ring-2 focus-visible:ring-primary ${index === 0 ? "text-primary" : "text-foreground"}`}><span className={`flex h-5 w-5 items-center justify-center rounded-full border ${done ? "border-primary bg-primary text-foreground" : "border-border"}`}>{done ? "✓" : ""}</span>{done ? "Reviewed · click to reset" : "Mark as reviewed"}</button>
      </article>;
    })}</div>
    <QASection className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center"><div><QAKicker>Be precise about evidence</QAKicker><h3 className="text-lg font-bold">Practice is not a client case study.</h3><p className="mt-1 text-sm text-muted-foreground">These interactive exercises run in your browser, with sample data and no external services.</p></div><span className="rounded-full border border-border px-3 py-2 text-[10px] font-bold uppercase tracking-[.14em]">Sample portfolio material</span></QASection>
  </div>;
}