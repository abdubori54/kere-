import type { Difficulty } from "./mission-data";

const STORAGE_KEY = "portfolio-hack-the-system-progress-v1";

export type SavedProgress = {
  bestScore: number;
  difficulty: Difficulty;
  score: number;
  currentMission: number;
  completed: number[];
  runCompleted: number[];
  unlocked: number;
  hintsUsed: number[];
  started: boolean;
  finished: boolean;
};

export const emptyProgress = (): SavedProgress => ({
  bestScore: 0,
  difficulty: "Analyst",
  score: 0,
  currentMission: 1,
  completed: [],
  runCompleted: [],
  unlocked: 1,
  hintsUsed: [],
  started: false,
  finished: false,
});

const isDifficulty = (value: unknown): value is Difficulty =>
  value === "Explorer" || value === "Analyst" || value === "Specialist";

export function readProgress(): SavedProgress {
  const fallback = emptyProgress();
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return fallback;
    const parsed: unknown = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object") return fallback;
    const data = parsed as Record<string, unknown>;
    const validIds = (value: unknown) =>
      Array.isArray(value) ? [...new Set(value.filter((id): id is number => Number.isInteger(id) && id >= 1 && id <= 5))] : [];
    const storedCompleted = validIds(data.completed).sort((a, b) => a - b);
    const completed: number[] = [];
    for (const id of storedCompleted) {
      if (id !== completed.length + 1) break;
      completed.push(id);
    }
    const unlocked = Math.min(6, completed.length + 1);
    const runCompleted = validIds(data.runCompleted).filter((id) => completed.includes(id));
    const hintsUsed = validIds(data.hintsUsed).filter((id) => id <= unlocked);
    const difficulty = isDifficulty(data.difficulty) ? data.difficulty : "Analyst";
    const score = typeof data.score === "number" && Number.isFinite(data.score) ? Math.max(0, Math.min(difficultySettingsMax(difficulty), Math.floor(data.score))) : 0;
    const bestScore = typeof data.bestScore === "number" && Number.isFinite(data.bestScore) ? Math.max(0, Math.min(600, Math.floor(data.bestScore))) : 0;
    const finished = runCompleted.length === 5;
    const started = data.started === true && !finished;
    const currentMission = typeof data.currentMission === "number"
      && Number.isInteger(data.currentMission)
      && data.currentMission >= 1
      && data.currentMission <= Math.min(unlocked, 5)
      ? data.currentMission
      : Math.min(5, completed.length + 1);
    return {
      bestScore,
      difficulty,
      score,
      currentMission,
      completed,
      runCompleted,
      unlocked,
      hintsUsed,
      started: started && !finished,
      finished,
    };
  } catch {
    return fallback;
  }
}

function difficultySettingsMax(difficulty: Difficulty): number {
  return ({ Explorer: 80, Analyst: 100, Specialist: 120 })[difficulty] * 5;
}

export function writeProgress(progress: SavedProgress): boolean {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
    return true;
  } catch {
    return false;
  }
}
