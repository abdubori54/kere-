export type Mission = {
  id: number;
  title: string;
  category: string;
  briefing: string;
  policy: string;
  evidenceTitle: string;
  evidence: Array<{ label: string; value: string; note?: string }>;
  question: string;
  choices: Array<{ id: string; label: string }>;
  answer: string;
  hint: string;
  feedback: string;
  success: string;
  inspect: string;
  clues: string;
};

export const missions: Mission[] = [
  {
    id: 1,
    title: "Password Audit",
    category: "Identity & access",
    briefing: "A routine access review has flagged one account for closer inspection. Compare each account with the written policy; report the single exception.",
    policy: "Passwords must be rotated every 90 days or less, and multi-factor authentication (MFA) must be enabled.",
    evidenceTitle: "Account register",
    evidence: [
      { label: "mira.chen", value: "Rotated 34 days ago · MFA enabled" },
      { label: "owen.kerr", value: "Rotated 88 days ago · MFA enabled" },
      { label: "talia.reed", value: "Rotated 96 days ago · MFA enabled" },
      { label: "noah.bell", value: "Rotated 12 days ago · MFA enabled" },
    ],
    question: "Which account violates the stated policy?",
    choices: [
      { id: "mira.chen", label: "mira.chen — 34 days · MFA on" },
      { id: "owen.kerr", label: "owen.kerr — 88 days · MFA on" },
      { id: "talia.reed", label: "talia.reed — 96 days · MFA on" },
      { id: "noah.bell", label: "noah.bell — 12 days · MFA on" },
    ],
    answer: "talia.reed",
    hint: "Check the rotation age against the 90-day limit. MFA is enabled for every account.",
    feedback: "That account meets both controls. Compare the rotation age and MFA status against the policy; only one record is outside the limit.",
    success: "Correct. Talia's password is 96 days old, beyond the 90-day rotation limit. MFA is enabled, so the age is the single failing control.",
    inspect: "The register shows four fictional accounts. One password age exceeds 90 days; all four have MFA enabled.",
    clues: "Policy: rotation ≤ 90 days and MFA enabled. Compare each age; MFA does not distinguish these records.",
  },
  {
    id: 2,
    title: "Log Investigator",
    category: "Event review",
    briefing: "A service owner reports a brief authentication spike. Review the event trail and identify the one event that breaks the normal pattern shown here.",
    policy: "Expected activity is one successful sign-in per account from the office network. Repeated failures in a short window are unusual and should be escalated for review.",
    evidenceTitle: "Authentication events · 09:00–09:05",
    evidence: [
      { label: "09:00:12", value: "success · account=river · source=192.0.2.18" },
      { label: "09:01:03", value: "success · account=park · source=192.0.2.21" },
      { label: "09:02:11", value: "failure · account=river · source=203.0.113.77" },
      { label: "09:02:14", value: "failure · account=river · source=203.0.113.77" },
      { label: "09:02:17", value: "failure · account=river · source=203.0.113.77" },
      { label: "09:04:08", value: "success · account=vale · source=192.0.2.24" },
    ],
    question: "Which event pattern is the clearest anomaly in this evidence?",
    choices: [
      { id: "office-success", label: "A single successful sign-in from 192.0.2.18" },
      { id: "repeated-failures", label: "Three failures for river in six seconds from 203.0.113.77" },
      { id: "different-accounts", label: "Three different accounts signing in during five minutes" },
      { id: "documentation-range", label: "An address from the 203.0.113.0/24 documentation range" },
    ],
    answer: "repeated-failures",
    hint: "Look for a short burst that conflicts with the written expectation. The displayed addresses are all documentation examples.",
    feedback: "That detail is not the unique anomaly described by the policy. Compare frequency, account, and timing across the log.",
    success: "Correct. Three failures for the same account arrive within six seconds, unlike the one-success-per-account pattern. The IPs are fictional documentation-only addresses.",
    inspect: "This fictional log uses only documentation-range addresses. The distinctive signal is repeated failure for one account in a six-second window.",
    clues: "Compare the log to the policy: one successful sign-in per account is expected; repeated failures close together are not.",
  },
  {
    id: 3,
    title: "Phishing Detection",
    category: "Message review",
    briefing: "The service desk received four reports of messages asking staff to review account activity. Inspect the visible sender, wording, and inert destination text.",
    policy: "Treat unexpected urgency, mismatched sender identity, and a destination unrelated to the claimed service as warning signs. Destinations below are plain text, not links.",
    evidenceTitle: "Reported messages",
    evidence: [
      { label: "Message A", value: "From: updates@northstar.example · Subject: Weekly product notes · Destination: portal.northstar.example", note: "Expected sender and routine wording." },
      { label: "Message B", value: "From: payroll-review@inbox.example · Subject: Action required in 20 minutes · Destination: payroll-check.invalid", note: "Unexpected deadline; sender does not match the payroll team." },
      { label: "Message C", value: "From: help@northstar.example · Subject: Your support ticket · Destination: support.northstar.example", note: "Matches an open support request." },
      { label: "Message D", value: "From: events@northstar.example · Subject: Registration confirmed · Destination: events.northstar.example", note: "Routine confirmation with matching destination." },
    ],
    question: "Which message has the strongest combination of phishing indicators?",
    choices: [
      { id: "message-a", label: "Message A — weekly product notes" },
      { id: "message-b", label: "Message B — urgent payroll review" },
      { id: "message-c", label: "Message C — support ticket update" },
      { id: "message-d", label: "Message D — event confirmation" },
    ],
    answer: "message-b",
    hint: "Find the message combining an unexpected deadline with a sender identity that does not match the claimed team.",
    feedback: "This message has a matching sender or routine context. Recheck the sender, urgency, and destination together.",
    success: "Correct. Message B combines an unfamiliar sender, an artificial deadline, and a destination unrelated to the claimed payroll team. All destinations are inert text.",
    inspect: "Four fictional messages are shown. Message B is the only one with both an urgent deadline and a mismatched sender identity.",
    clues: "Look for multiple indicators together: unexpected urgency, sender mismatch, and destination mismatch.",
  },
  {
    id: 4,
    title: "Access Control",
    category: "Least privilege",
    briefing: "A team lead asks for a quick review of role assignments before a quarterly access recertification. Compare each assignment with the least-privilege matrix.",
    policy: "Support may view tickets; Analysts may view and annotate reports; Editors may view and publish reports. Only the Records Custodian may export the full archive.",
    evidenceTitle: "Role assignment matrix",
    evidence: [
      { label: "Support · Eli", value: "View tickets" },
      { label: "Analyst · June", value: "View reports · annotate reports" },
      { label: "Editor · Sam", value: "View reports · publish reports" },
      { label: "Analyst · Ren", value: "View reports · export full archive" },
    ],
    question: "Which assignment exceeds the written role permissions?",
    choices: [
      { id: "support", label: "Support · Eli — view tickets" },
      { id: "analyst-june", label: "Analyst · June — view and annotate reports" },
      { id: "editor", label: "Editor · Sam — view and publish reports" },
      { id: "analyst-ren", label: "Analyst · Ren — export full archive" },
    ],
    answer: "analyst-ren",
    hint: "Only one role in the policy may export the full archive. Check whether that permission appears on an Analyst assignment.",
    feedback: "That assignment matches the listed role permissions. Compare each permission with the specific role in the matrix.",
    success: "Correct. Exporting the full archive is reserved for the Records Custodian, not an Analyst. Ren's assignment exceeds least privilege.",
    inspect: "Three assignments match their written role. The full archive export permission is reserved for the Records Custodian.",
    clues: "Support: view tickets. Analyst: view and annotate reports. Editor: view and publish. Full export: Records Custodian only.",
  },
  {
    id: 5,
    title: "Incident Response",
    category: "Response priorities",
    briefing: "A staff member reports an unexpected security alert on a shared workstation. The device is still powered on, and a response lead is available.",
    policy: "Follow the response plan: contain exposure using the approved process, preserve potential evidence, and notify the incident lead. Avoid unapproved changes to the device.",
    evidenceTitle: "Initial report",
    evidence: [
      { label: "Device", value: "Shared workstation · asset WS-204" },
      { label: "Observed", value: "Unexpected security alert at 14:18 local time" },
      { label: "Status", value: "Powered on · user has stopped interacting with it" },
      { label: "Response plan", value: "Contain exposure · preserve evidence · notify incident lead" },
    ],
    question: "What is the best immediate next step?",
    choices: [
      { id: "contain-preserve", label: "Use the approved process to isolate it from the network, preserve its current state, and notify the incident lead." },
      { id: "resume-work", label: "Dismiss the alert and let the user continue while the team reviews it later." },
      { id: "make-changes", label: "Delete unfamiliar files and change system settings before notifying anyone." },
      { id: "power-off", label: "Power off the workstation immediately and investigate it alone." },
    ],
    answer: "contain-preserve",
    hint: "Prioritize the response plan's first actions while avoiding changes that could discard useful evidence.",
    feedback: "That choice either delays containment, alters the device, or removes evidence. Follow the stated response plan and involve the incident lead.",
    success: "Correct. Approved network isolation contains exposure while preserving the current state; notifying the incident lead keeps response coordinated.",
    inspect: "The device is powered on and no longer in use. The written plan prioritizes containment, evidence preservation, and notification.",
    clues: "Do not troubleshoot or make changes. Contain exposure using the approved process, preserve the device state, and notify the response lead.",
  },
];

export type Difficulty = "Explorer" | "Analyst" | "Specialist";

export const difficultySettings: Record<Difficulty, { base: number; hintCost: number; description: string }> = {
  Explorer: { base: 80, hintCost: 10, description: "A generous score buffer for learning the evidence." },
  Analyst: { base: 100, hintCost: 20, description: "A balanced review with meaningful hint trade-offs." },
  Specialist: { base: 120, hintCost: 30, description: "The highest base award; hints carry a larger cost." },
};
