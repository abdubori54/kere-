import { useState } from "react";
import type { Difficulty, Mission } from "./mission-data";
import { difficultySettings } from "./mission-data";

export function DifficultyPicker({ value, onChange }: { value: Difficulty; onChange: (value: Difficulty) => void }) {
  return <fieldset className="mt-8">
    <legend className="editorial-kicker text-muted-foreground">Choose a scoring mode</legend>
    <div className="mt-3 grid gap-3 sm:grid-cols-3">
      {(["Explorer", "Analyst", "Specialist"] as Difficulty[]).map((difficulty) => {
        const settings = difficultySettings[difficulty];
        const selected = value === difficulty;
        return <label key={difficulty} className={`cursor-pointer rounded-2xl border p-4 transition-colors focus-within:ring-2 focus-within:ring-primary ${selected ? "border-foreground bg-foreground text-background" : "border-border bg-card hover:border-primary"}`}>
          <input className="sr-only" type="radio" name="difficulty" value={difficulty} checked={selected} onChange={() => onChange(difficulty)} data-testid={`difficulty-${difficulty.toLowerCase()}`} />
          <span className="flex items-center justify-between gap-2 text-sm font-bold">{difficulty}<span className={`font-mono text-xs ${selected ? "text-primary" : "text-muted-foreground"}`}>{settings.base} pts</span></span>
          <span className={`mt-2 block text-xs leading-5 ${selected ? "text-background/70" : "text-muted-foreground"}`}>{settings.description}</span>
          <span className={`mt-3 block font-mono text-[10px] uppercase tracking-wider ${selected ? "text-background/60" : "text-muted-foreground"}`}>Hint cost −{settings.hintCost}</span>
        </label>;
      })}
    </div>
  </fieldset>;
}

export function MissionRail({ missions, completed, unlocked, current, onSelect }: { missions: Mission[]; completed: number[]; unlocked: number; current: number; onSelect: (id: number) => void }) {
  return <nav aria-label="Mission progress" className="rounded-2xl border border-border bg-card/70 p-4 sm:p-5">
    <p className="editorial-kicker text-muted-foreground">Field sequence</p>
    <ol className="mt-4 grid grid-cols-5 gap-2">
      {missions.map((mission, index) => {
        const done = completed.includes(mission.id);
        const locked = mission.id > unlocked;
        return <li key={mission.id} className="min-w-0">
          <button type="button" onClick={() => !locked && onSelect(mission.id)} disabled={locked} aria-current={mission.id === current && !locked ? "step" : undefined} aria-label={`${mission.title}${locked ? ", locked" : done ? ", completed, replay" : ", available"}`} data-testid={`mission-progress-${mission.id}`} className={`flex min-h-[4.4rem] w-full flex-col justify-between rounded-xl border p-2.5 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary sm:p-3 ${done ? "border-primary bg-primary/20" : mission.id === current ? "border-foreground bg-foreground text-background" : "border-border bg-background/50 hover:border-primary"} ${locked ? "cursor-not-allowed opacity-50" : ""}`}>
            <span className={`font-mono text-[10px] ${mission.id === current && !done ? "text-primary" : "text-muted-foreground"}`}>0{mission.id}</span>
            <span className="truncate text-[10px] font-semibold sm:text-xs">{locked ? "Locked" : done ? "Complete" : index === current - 1 ? "Current" : "Open"}</span>
          </button>
        </li>;
      })}
    </ol>
    <p className="mt-3 text-xs leading-5 text-muted-foreground" data-testid="text-completed-count">{completed.length} of 5 missions completed this run · unlocked through {Math.min(unlocked, 5)} of 5</p>
  </nav>;
}

export function EvidenceCard({ mission }: { mission: Mission }) {
  return <section className="rounded-2xl border border-border bg-card p-5 sm:p-6" aria-labelledby="evidence-heading">
    <div className="flex items-center justify-between gap-3">
      <h3 id="evidence-heading" className="editorial-kicker text-muted-foreground">{mission.evidenceTitle}</h3>
      <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Evidence / 0{mission.id}</span>
    </div>
    <dl className="mt-4 divide-y divide-border/80">
      {mission.evidence.map((item) => <div key={item.label} className="grid gap-1 py-3 first:pt-0 last:pb-0 sm:grid-cols-[9rem_1fr] sm:gap-4">
        <dt className="font-mono text-[11px] font-medium text-muted-foreground">{item.label}</dt>
        <dd className="break-words text-sm leading-6">{item.value}{item.note && <span className="mt-1 block text-xs text-muted-foreground">{item.note}</span>}</dd>
      </div>)}
    </dl>
    <div className="mt-5 rounded-xl border-l-2 border-primary bg-background/70 px-4 py-3">
      <p className="editorial-kicker text-muted-foreground">Control / stated policy</p>
      <p className="mt-2 text-sm leading-6">{mission.policy}</p>
    </div>
  </section>;
}

export function TerminalPanel({ mission, status, hintUsed, onHint }: { mission: Mission; status: string; hintUsed: boolean; onHint: () => void }) {
  const [input, setInput] = useState("");
  const [lines, setLines] = useState<string[]>([
    "SAFE LOCAL SIMULATION · no shell, system access, or network connection",
    "Type help to view the fixed command list.",
  ]);
  const runCommand = () => {
    const command = input.trim().toLowerCase();
    if (!command) return;
    setInput("");
    if (command === "clear") {
      setLines([]);
      return;
    }
    let response = "Unknown command. This local terminal accepts only: help, status, inspect, clues, hint, clear.";
    if (command === "help") response = "Allowed commands: help · status · inspect · clues · hint · clear. All output is local and read-only.";
    if (command === "status") response = status;
    if (command === "inspect") response = mission.inspect;
    if (command === "clues") response = mission.clues;
    if (command === "hint") {
      if (hintUsed) response = "Hint already used for this mission. Its deduction is reflected in the mission award.";
      else {
        onHint();
        response = `Hint: ${mission.hint}`;
      }
    }
    setLines((current) => [...current.slice(-7), `> ${command}`, response]);
  };
  return <section className="overflow-hidden rounded-2xl border border-foreground/20 bg-[#17243a] text-[#f4f0e7]" aria-labelledby="terminal-heading">
    <div className="flex items-center justify-between gap-3 border-b border-white/10 px-4 py-3">
      <div><h3 id="terminal-heading" className="editorial-kicker text-primary">Local analysis console</h3><p className="mt-1 text-[10px] text-white/55">Read-only · browser simulation</p></div>
      <span className="rounded-full border border-white/20 px-2.5 py-1 font-mono text-[9px] uppercase tracking-wider text-white/70">Safe mode</span>
    </div>
    <div className="max-h-48 min-h-28 space-y-2 overflow-y-auto px-4 py-3 font-mono text-[11px] leading-5" aria-live="polite" aria-label="Terminal transcript" data-testid="terminal-transcript">
      {lines.map((line, index) => <p key={`${index}-${line}`} className={line.startsWith(">") ? "text-primary" : "text-white/75"}>{line}</p>)}
    </div>
    <div role="group" aria-label="Safe local command input" className="flex gap-2 border-t border-white/10 px-3 py-3">
      <label className="sr-only" htmlFor="terminal-input">Enter a safe local command</label>
      <span className="self-center pl-1 font-mono text-xs text-primary" aria-hidden="true">&gt;</span>
      <input id="terminal-input" value={input} onChange={(event) => setInput(event.target.value)} onKeyDown={(event) => {
        if (event.key === "Enter") {
          event.preventDefault();
          runCommand();
        }
      }} autoComplete="off" spellCheck={false} maxLength={32} placeholder="help" className="min-w-0 flex-1 bg-transparent font-mono text-xs text-white placeholder:text-white/35 focus-visible:outline-none" data-testid="input-terminal-command" />
      <button type="button" onClick={runCommand} className="rounded-full bg-primary px-3 py-1.5 text-[11px] font-bold text-foreground transition-colors hover:bg-primary/85 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-background" data-testid="button-terminal-run">Run</button>
    </div>
  </section>;
}

export function FeedbackNotice({ kind, children }: { kind: "success" | "error" | "info"; children: string }) {
  const styles = kind === "success" ? "border-primary/70 bg-primary/15" : kind === "error" ? "border-destructive/50 bg-destructive/10" : "border-border bg-muted/60";
  return <p role={kind === "error" ? "alert" : "status"} className={`rounded-xl border px-4 py-3 text-sm leading-6 ${styles}`} data-testid={`status-${kind}`}>{children}</p>;
}
