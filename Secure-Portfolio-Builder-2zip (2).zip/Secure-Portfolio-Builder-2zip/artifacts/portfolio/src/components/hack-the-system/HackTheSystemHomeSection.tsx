import { ArrowUpRight, ShieldCheck } from "lucide-react";
import { Link } from "wouter";

export function HackTheSystemHomeSection() {
  return <section className="mb-16 overflow-hidden rounded-[1.75rem] border border-border bg-card/80" data-testid="section-hack-the-system">
    <div className="grid gap-6 p-6 sm:p-8 md:grid-cols-[1fr_auto] md:items-center lg:p-10">
      <div className="flex items-start gap-4">
        <span className="mt-1 flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-primary text-foreground"><ShieldCheck size={20} aria-hidden="true" /></span>
        <div>
          <p className="editorial-kicker text-primary">A short security field exercise</p>
          <h2 className="editorial-display mt-2 text-4xl leading-none sm:text-5xl">Hack the <span className="italic">System.</span></h2>
          <p className="mt-3 max-w-2xl text-sm leading-6 text-muted-foreground">Five fictional evidence reviews, one safe local console, and no connection to real systems. Make the call from the clues in front of you.</p>
        </div>
      </div>
      <Link href="/hack-the-system" className="inline-flex min-h-11 items-center justify-center gap-2 self-start rounded-full bg-foreground px-5 py-3 text-sm font-semibold text-background transition-colors hover:bg-foreground/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary md:self-center" data-testid="link-play-hack-the-system">
        Play Game <ArrowUpRight size={15} aria-hidden="true" />
      </Link>
    </div>
  </section>;
}
