import { useState, useEffect, useRef } from "react";
import { Terminal as TerminalIcon, ChevronRight } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apiFetch, type TerminalCommand } from "@/lib/api";

interface OutputLine {
  type: "cmd" | "res" | "boot";
  text: string;
}

const BOOT_LINES = [
  "Initializing secure shell...",
  "Loading user environment...",
  "Access granted. Type a command.",
];

export function TerminalWidget() {
  const { data: commands, isLoading } = useQuery({
    queryKey: ["/api/terminal"],
    queryFn: () => apiFetch<TerminalCommand[]>("/api/terminal"),
  });
  const [output, setOutput] = useState<OutputLine[]>([]);
  const [booted, setBooted] = useState(false);
  const [inputVal, setInputVal] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Boot sequence
  useEffect(() => {
    let i = 0;
    const boot: OutputLine[] = [];
    const interval = setInterval(() => {
      if (i < BOOT_LINES.length) {
        boot.push({ type: "boot", text: BOOT_LINES[i] });
        setOutput([...boot]);
        i++;
      } else {
        clearInterval(interval);
        setBooted(true);
      }
    }, 320);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [output]);

  const runCommand = (cmd: string) => {
    const trimmed = cmd.trim().toLowerCase();
    if (!trimmed) return;

    const match = commands?.find(
      (c) => c.command.trim().toLowerCase() === trimmed
    );

    const response = match
       ? match.output
      : `command not found: ${trimmed}`;

    setOutput((prev) => [
      ...prev,
      { type: "cmd", text: trimmed },
      { type: "res", text: response },
    ]);
    setInputVal("");
  };

  const handleKey = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") runCommand(inputVal);
  };

  if (isLoading || !commands || commands.length === 0) return null;

  return (
    <section className="space-y-4">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="h-px flex-1 bg-gradient-to-r from-primary/50 to-transparent" />
        <span className="font-mono text-xs tracking-widest text-primary/80 flex items-center gap-1.5">
          <TerminalIcon className="w-3 h-3" />
          INTERACTIVE_SHELL
        </span>
        <div className="h-px flex-1 bg-gradient-to-l from-primary/50 to-transparent" />
      </div>

      {/* Terminal window */}
      <div
        className="relative overflow-hidden rounded-[1.5rem] border border-foreground/15 bg-[hsl(224_26%_15%)] font-mono text-sm shadow-[0_15px_50px_rgba(32,38,53,.14)]"
        onClick={() => inputRef.current?.focus()}
        data-testid="terminal-window"
      >
        {/* Title bar */}
        <div className="flex items-center gap-2 border-b border-primary/15 bg-[hsl(224_22%_19%)] px-4 py-3">
          <span className="w-2.5 h-2.5 rounded-full bg-destructive/70" />
          <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/70" />
          <span className="w-2.5 h-2.5 rounded-full bg-primary/70" />
          <span className="ml-3 text-xs text-muted-foreground tracking-widest">
            user@vault:~$
          </span>
        </div>

        {/* Output area */}
        <div className="p-4 min-h-[160px] max-h-[260px] overflow-y-auto space-y-0.5 scrollbar-thin">
          {output.map((line, i) => (
            <div key={i} className="flex items-start gap-2 leading-relaxed">
              {line.type === "cmd" ? (
                <>
                  <span className="text-primary/60 select-none flex-none">$</span>
                  <span className="text-primary">{line.text}</span>
                </>
              ) : line.type === "res" ? (
                <>
                  <span className="text-primary/60 select-none flex-none opacity-0">$</span>
                  <span className="text-cyan-300/90">{line.text}</span>
                </>
              ) : (
                <>
                  <span className="text-primary/60 select-none flex-none">&gt;</span>
                  <span className="text-muted-foreground/80 text-xs">{line.text}</span>
                </>
              )}
            </div>
          ))}
          <div ref={bottomRef} />
        </div>

        {/* Input row */}
        {booted && (
          <div className="flex items-center gap-2 px-4 py-3 border-t border-primary/15">
            <span className="text-primary/70 select-none">$</span>
            <input
              ref={inputRef}
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              onKeyDown={handleKey}
              className="flex-1 bg-transparent outline-none text-primary placeholder:text-muted-foreground/40 caret-primary text-sm font-mono"
              placeholder="type a command..."
              autoComplete="off"
              spellCheck={false}
              data-testid="terminal-input"
            />
            <span className="animate-pulse text-primary/50">▋</span>
          </div>
        )}
      </div>

      {/* Command chips */}
      {booted && (
        <div className="flex flex-wrap gap-2">
          {commands.map((c) => (
            <button
              key={c.id}
              onClick={() => runCommand(c.command)}
               className="flex items-center gap-1.5 rounded-full border border-primary/35 bg-primary/10 px-3 py-1.5 font-mono text-xs text-primary transition-all duration-150 hover:border-primary/70 hover:bg-primary/20 active:scale-95 focus-visible:ring-2 focus-visible:ring-primary"
              data-testid={`cmd-chip-${c.id}`}
            >
              <ChevronRight className="w-3 h-3 opacity-60" />
              {c.command}
            </button>
          ))}
        </div>
      )}
    </section>
  );
}
