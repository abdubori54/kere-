import { useEffect, useRef } from "react";

interface Star {
  x: number;
  y: number;
  z: number;
  px: number;
  py: number;
}

export function Starfield() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const NUM_STARS = 180;
    const SPEED = 0.4;
    let width = window.innerWidth;
    let height = window.innerHeight;
    let animId: number;

    canvas.width = width;
    canvas.height = height;

    const stars: Star[] = Array.from({ length: NUM_STARS }, () => ({
      x: Math.random() * width - width / 2,
      y: Math.random() * height - height / 2,
      z: Math.random() * width,
      px: 0,
      py: 0,
    }));

    function resetStar(star: Star) {
      star.x = Math.random() * width - width / 2;
      star.y = Math.random() * height - height / 2;
      star.z = width;
      star.px = 0;
      star.py = 0;
    }

    function draw() {
      ctx!.fillStyle = "rgba(10, 12, 20, 0)";
      ctx!.clearRect(0, 0, width, height);

      const cx = width / 2;
      const cy = height / 2;

      for (const star of stars) {
        star.z -= SPEED * 1.6;
        if (star.z <= 0) {
          resetStar(star);
          continue;
        }

        const sx = (star.x / star.z) * width + cx;
        const sy = (star.y / star.z) * height + cy;

        if (sx < 0 || sx > width || sy < 0 || sy > height) {
          resetStar(star);
          continue;
        }

        const size = Math.max(0.3, (1 - star.z / width) * 2.8);
        const opacity = Math.min(1, (1 - star.z / width) * 1.4);

        // tail line from previous position
        if (star.px !== 0 || star.py !== 0) {
          ctx!.beginPath();
          ctx!.moveTo(star.px, star.py);
          ctx!.lineTo(sx, sy);

          // alternate between neon-green and cyan tails
          const hue = (star.x + star.y) % 2 === 0 ? "0,255,180" : "0,200,255";
          ctx!.strokeStyle = `rgba(${hue},${opacity * 0.55})`;
          ctx!.lineWidth = size * 0.7;
          ctx!.stroke();
        }

        star.px = sx;
        star.py = sy;

        // draw the star dot
        ctx!.beginPath();
        ctx!.arc(sx, sy, size, 0, Math.PI * 2);
        const bright = size > 1.5;
        if (bright) {
          const g = ctx!.createRadialGradient(sx, sy, 0, sx, sy, size * 3);
          g.addColorStop(0, `rgba(180,255,220,${opacity})`);
          g.addColorStop(1, "rgba(0,255,180,0)");
          ctx!.fillStyle = g;
          ctx!.arc(sx, sy, size * 3, 0, Math.PI * 2);
        } else {
          ctx!.fillStyle = `rgba(140,240,200,${opacity})`;
        }
        ctx!.fill();
      }

      animId = requestAnimationFrame(draw);
    }

    draw();

    const onResize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width;
      canvas.height = height;
      for (const s of stars) resetStar(s);
    };
    window.addEventListener("resize", onResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", onResize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none"
      style={{ zIndex: 0, opacity: 0.75 }}
    />
  );
}
