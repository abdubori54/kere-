import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { ArrowUpRight, LogOut, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Shell({ children }: { children: ReactNode }) {
  const [location, setLocation] = useLocation();
  const isLocalGameRoute = location === "/hack-the-system" || location === "/logic-breach";
  const { isAdmin, logout } = useAuth({ enabled: !isLocalGameRoute });

  return (
    <div className="min-h-[100dvh] flex flex-col bg-background grid-bg relative">
      
      <header className="sticky top-0 z-40 border-b border-border/70 bg-background/90 backdrop-blur-xl">
        <div className="mx-auto flex h-[4.5rem] max-w-7xl items-center justify-between px-4 sm:px-8 lg:px-12">
          <Link href="/" className="group flex items-center gap-3 focus-visible:ring-2 focus-visible:ring-primary">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-foreground text-background transition-transform group-hover:rotate-6">
              <ShieldCheck className="h-4 w-4 text-primary" />
            </span>
            <span className="font-semibold tracking-[-.03em]">
              Security archive<span className="text-primary">.</span>
            </span>
          </Link>

          <nav className="flex items-center gap-2 sm:gap-5">
            <Link href="/#archive" className="hidden text-xs font-semibold text-muted-foreground transition-colors hover:text-foreground focus-visible:ring-2 focus-visible:ring-primary sm:block">Archive</Link>
            <Link href="/security-lab" className="hidden text-xs font-semibold text-muted-foreground transition-colors hover:text-foreground focus-visible:ring-2 focus-visible:ring-primary sm:block">Security Lab</Link>
            <Link href="/qa-lab" className="hidden text-xs font-semibold text-muted-foreground transition-colors hover:text-foreground focus-visible:ring-2 focus-visible:ring-primary sm:block">QA Lab</Link>
            <Link href="/hack-the-system" data-testid="link-hack-the-system-nav" className="hidden text-xs font-semibold text-muted-foreground transition-colors hover:text-foreground focus-visible:ring-2 focus-visible:ring-primary sm:block">Hack the System</Link>
            <Link href="/logic-breach" data-testid="link-logic-breach-nav" className="hidden text-xs font-semibold text-muted-foreground transition-colors hover:text-foreground focus-visible:ring-2 focus-visible:ring-primary sm:block">Logic Breach</Link>
            {isAdmin ? (
              <>
                <Link href="/admin/dashboard" className="inline-flex items-center gap-1.5 rounded-full border border-border px-4 py-2 text-xs font-semibold transition-colors hover:border-primary hover:text-primary focus-visible:ring-2 focus-visible:ring-primary">
                  Dashboard <ArrowUpRight className="h-3 w-3" />
                </Link>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={async () => {
                    await logout();
                    setLocation("/");
                  }}
                   className="gap-2 rounded-full text-xs text-muted-foreground hover:text-destructive"
                >
                  <LogOut className="h-3.5 w-3.5" />
                  Log out
                </Button>
              </>
            ) : (
                <Link href="/admin" aria-label="Open admin access" className="flex h-9 w-9 items-center justify-center rounded-full border border-border text-muted-foreground transition-colors hover:border-primary hover:text-primary focus-visible:ring-2 focus-visible:ring-primary">
                   <ShieldCheck className="h-4 w-4" />
              </Link>
            )}
          </nav>
        </div>
      </header>

      <main className="flex-1 relative z-10">
        {children}
      </main>

      <footer className="relative z-10 border-t border-border/70 bg-background/90 py-8">
        <div className="mx-auto flex max-w-7xl flex-col gap-2 px-4 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between sm:px-8 lg:px-12">
          <p className="font-mono uppercase tracking-[.16em]">
            Personal security archive
          </p>
          <p>Built around the work, not the interface.</p>
        </div>
      </footer>
    </div>
  );
}
