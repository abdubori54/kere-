import { ArrowUpRight, FlaskConical, RefreshCw } from "lucide-react";
import { Link } from "wouter";
import { useSecurityLabs } from "@/hooks/use-security-labs";
import { useLabProgress } from "@/hooks/use-lab-progress";
import { CompletionMark, DifficultyBadge, FeaturedMark } from "@/components/security-lab/LabBadge";
import { Skeleton } from "@/components/ui/skeleton";

export function SecurityLabHomeSection() {
  const { data: labs, isLoading, isError, refetch } = useSecurityLabs();
  const { progress } = useLabProgress();
  const completedCount = labs?.filter((lab) => progress[lab.slug]).length ?? 0;

  return (
    <section id="security-lab" className="mt-20 scroll-mt-24 space-y-8" aria-labelledby="security-lab-heading">
      <div className="flex flex-col gap-5 border-b border-border pb-6 md:flex-row md:items-end md:justify-between">
        <div className="max-w-2xl">
          <p className="editorial-kicker text-primary">Safe simulations / practical index</p>
          <h2 id="security-lab-heading" className="editorial-display mt-2 text-5xl leading-none sm:text-6xl">Security Lab</h2>
          <p className="mt-4 max-w-xl text-sm leading-7 text-muted-foreground">
            Explore interactive cybersecurity challenges and test your security knowledge.
          </p>
        </div>
        <Link
          href="/security-lab"
          className="inline-flex w-fit items-center gap-2 rounded-full bg-foreground px-5 py-3 text-sm font-semibold text-background transition-transform hover:-translate-y-1 focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2"
        >
          View All Labs <ArrowUpRight className="h-4 w-4" />
        </Link>
      </div>

      {isLoading ? (
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3" aria-label="Loading Security Lab">
          {[1, 2, 3, 4, 5, 6].map((item) => <Skeleton key={item} className="h-80 rounded-[2rem]" />)}
        </div>
      ) : isError ? (
        <div className="soft-card rounded-[2rem] px-6 py-16 text-center">
          <FlaskConical className="mx-auto h-8 w-8 text-destructive" />
          <p className="mt-4 text-sm text-muted-foreground">The lab index is temporarily unavailable.</p>
          <button
            type="button"
            onClick={() => void refetch()}
            className="mt-5 inline-flex items-center gap-2 rounded-full border border-border px-4 py-2.5 text-xs font-semibold transition-colors hover:border-primary hover:text-primary"
          >
            <RefreshCw className="h-3.5 w-3.5" /> Try again
          </button>
        </div>
      ) : !labs?.length ? (
        <div className="soft-card rounded-[2rem] px-6 py-16 text-center">
          <FlaskConical className="mx-auto h-8 w-8 text-muted-foreground" />
          <p className="mt-4 text-sm text-muted-foreground">No simulations are published yet.</p>
        </div>
      ) : (
        <>
          <div className="flex items-center justify-between gap-4 border-l-2 border-primary pl-4">
            <p className="font-mono text-[10px] uppercase tracking-[.16em] text-muted-foreground">
              {completedCount} of {labs.length} labs completed locally
            </p>
            <Link href="/security-lab" className="hidden text-xs font-semibold text-primary hover:text-foreground sm:inline-flex">
              Open the index <ArrowUpRight className="ml-1 h-3.5 w-3.5" />
            </Link>
          </div>
          <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {labs.slice(0, 6).map((lab, index) => {
              const complete = Boolean(progress[lab.slug]);
              return (
                <article key={lab.id} className="soft-card group flex min-h-80 flex-col rounded-[2rem] p-6 transition-transform duration-500 hover:-translate-y-1" data-testid={`home-lab-card-${lab.slug}`}>
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <span className="font-mono text-[10px] text-muted-foreground">LAB_{String(index + 1).padStart(2, "0")}</span>
                      <span className="h-px w-6 bg-border" />
                      <span className="editorial-kicker text-primary">{lab.category}</span>
                    </div>
                    {lab.featured && <FeaturedMark />}
                  </div>
                  <div className="mt-8">
                    <h3 className="editorial-display text-3xl leading-[.94] transition-colors group-hover:text-primary">{lab.title}</h3>
                    <p className="mt-3 text-sm leading-6 text-muted-foreground">{lab.shortDescription}</p>
                  </div>
                  <div className="mt-auto pt-8">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <DifficultyBadge difficulty={lab.difficulty} />
                      <CompletionMark complete={complete} />
                    </div>
                    <Link
                      href={`/security-lab/${lab.slug}`}
                      className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full border border-border px-4 py-3 text-xs font-semibold transition-colors hover:border-primary hover:bg-primary hover:text-foreground focus-visible:ring-2 focus-visible:ring-primary"
                    >
                      {complete ? "Review Lab" : "Start Lab"} <ArrowUpRight className="h-3.5 w-3.5" />
                    </Link>
                  </div>
                </article>
              );
            })}
          </div>
          {labs.length > 6 && (
            <p className="text-center text-xs text-muted-foreground">
              Showing six featured surfaces. <Link href="/security-lab" className="font-semibold text-primary hover:text-foreground">View all {labs.length} labs.</Link>
            </p>
          )}
        </>
      )}
    </section>
  );
}