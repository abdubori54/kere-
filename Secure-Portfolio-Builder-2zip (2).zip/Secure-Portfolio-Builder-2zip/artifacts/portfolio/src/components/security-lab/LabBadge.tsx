import { Check, Clock3, Gauge, LockKeyhole, Sparkles } from "lucide-react";

export function DifficultyBadge({ difficulty }: { difficulty: string }) {
  const level = difficulty.toLowerCase();
  const tone = level.includes("advanced") ? "text-accent" : level.includes("intermediate") ? "text-primary" : "text-[#8292cc]";
  return <span className={`inline-flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[.14em] ${tone}`}><Gauge className="h-3 w-3" /> {difficulty}</span>;
}

export function LabMeta({ difficulty, minutes }: { difficulty: string; minutes: number }) {
  return <div className="flex flex-wrap items-center gap-4 text-muted-foreground"><DifficultyBadge difficulty={difficulty} /><span className="inline-flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[.14em]"><Clock3 className="h-3 w-3" /> {minutes} min</span></div>;
}

export function CompletionMark({ complete }: { complete: boolean }) {
  return complete ? <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/15 px-2.5 py-1 font-mono text-[10px] uppercase tracking-[.12em] text-foreground"><Check className="h-3 w-3 text-primary" /> Complete</span> : <span className="inline-flex items-center gap-1.5 rounded-full border border-border/80 px-2.5 py-1 font-mono text-[10px] uppercase tracking-[.12em] text-muted-foreground"><LockKeyhole className="h-3 w-3" /> Open lab</span>;
}

export function FeaturedMark() {
  return <span className="inline-flex items-center gap-1 font-mono text-[10px] uppercase tracking-[.14em] text-primary"><Sparkles className="h-3 w-3" /> Featured</span>;
}