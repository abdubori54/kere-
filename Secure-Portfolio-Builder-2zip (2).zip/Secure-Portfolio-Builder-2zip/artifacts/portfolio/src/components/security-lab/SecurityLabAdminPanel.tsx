import { useEffect, useMemo, useState } from "react";
import type { FormEvent, ReactNode } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Check, Edit3, Eye, EyeOff, FlaskConical, Plus, Save, Star, Trash2, X } from "lucide-react";
import { apiFetch } from "@/lib/api";
import { securityLabTypesQueryKey, securityLabsQueryKey, useSecurityLabTypes, useSecurityLabs, type SecurityLab } from "@/hooks/use-security-labs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

type LabForm = Omit<SecurityLab, "id" | "createdAt" | "updatedAt">;

const emptyForm: LabForm = {
  slug: "", title: "", shortDescription: "", category: "Web Security", difficulty: "Beginner", estimatedMinutes: 10,
  learningObjective: "", challengeDescription: "", task: "", hints: [], expectedResult: "", explanation: "",
  demoType: "generic", published: false, enabled: true, featured: false, sortOrder: 0,
};

function formFromLab(lab: SecurityLab): LabForm {
  return {
    slug: lab.slug, title: lab.title, shortDescription: lab.shortDescription, category: lab.category, difficulty: lab.difficulty,
    estimatedMinutes: lab.estimatedMinutes, learningObjective: lab.learningObjective, challengeDescription: lab.challengeDescription,
    task: lab.task, hints: lab.hints || [], expectedResult: lab.expectedResult, explanation: lab.explanation, demoType: lab.demoType,
    published: lab.published, enabled: lab.enabled, featured: lab.featured, sortOrder: lab.sortOrder,
  };
}

function Toggle({ label, active, onClick, icon }: { label: string; active: boolean; onClick: () => void; icon?: ReactNode }) {
  return <button type="button" onClick={onClick} className={`inline-flex items-center gap-2 rounded-full border px-3 py-2 text-xs font-semibold transition ${active ? "border-primary bg-primary/15 text-foreground" : "border-border text-muted-foreground hover:border-primary"}`}>{icon}{active ? <Check className="h-3 w-3 text-primary" /> : <X className="h-3 w-3" />}{label}</button>;
}

export function SecurityLabAdminPanel() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { data: labs, isLoading, isError } = useSecurityLabs(true);
  const { data: types } = useSecurityLabTypes(true);
  const [form, setForm] = useState<LabForm>(emptyForm);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [showEditor, setShowEditor] = useState(false);
  const [saving, setSaving] = useState(false);
  const sortedLabs = useMemo(() => [...(labs || [])].sort((a, b) => a.sortOrder - b.sortOrder || a.title.localeCompare(b.title)), [labs]);

  useEffect(() => {
    if (!editingId && labs?.length && !showEditor) return;
    if (editingId && labs) {
      const current = labs.find((lab) => lab.id === editingId);
      if (current) setForm(formFromLab(current));
    }
  }, [editingId, labs, showEditor]);

  const refresh = async () => {
    await queryClient.invalidateQueries({ queryKey: securityLabsQueryKey(true) });
    await queryClient.invalidateQueries({ queryKey: ["/api/security-labs"] });
  };
  const save = async (event: FormEvent) => {
    event.preventDefault();
    setSaving(true);
    try {
      const payload = { ...form, estimatedMinutes: Number(form.estimatedMinutes), sortOrder: Number(form.sortOrder), hints: form.hints };
      if (editingId) {
        await apiFetch(`/api/security-labs/${editingId}`, { method: "PUT", body: JSON.stringify(payload) });
        toast({ title: "Lab updated", description: "The management record has been saved." });
      } else {
        await apiFetch("/api/security-labs", { method: "POST", body: JSON.stringify(payload) });
        toast({ title: "Lab created", description: "The lab is ready for review." });
      }
      await refresh();
      setForm(emptyForm);
      setEditingId(null);
      setShowEditor(false);
    } catch (error) {
      toast({ title: "Could not save lab", description: error instanceof Error ? error.message : "Try again.", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };
  const patchLab = async (lab: SecurityLab, patch: Partial<SecurityLab>) => {
    try {
      await apiFetch(`/api/security-labs/${lab.id}`, { method: "PUT", body: JSON.stringify({ ...formFromLab(lab), ...patch }) });
      await refresh();
    } catch (error) {
      toast({ title: "Could not update lab", description: error instanceof Error ? error.message : "Try again.", variant: "destructive" });
    }
  };
  const remove = async (lab: SecurityLab) => {
    if (!window.confirm(`Delete “${lab.title}”? This cannot be undone.`)) return;
    try {
      await apiFetch(`/api/security-labs/${lab.id}`, { method: "DELETE" });
      await refresh();
      toast({ title: "Lab deleted" });
    } catch (error) {
      toast({ title: "Could not delete lab", description: error instanceof Error ? error.message : "Try again.", variant: "destructive" });
    }
  };
  const toggleType = async (id: number, enabled: boolean) => {
    try {
      await apiFetch(`/api/security-labs/types/${id}`, { method: "PATCH", body: JSON.stringify({ enabled }) });
      await queryClient.invalidateQueries({ queryKey: securityLabTypesQueryKey(true) });
      await queryClient.invalidateQueries({ queryKey: securityLabTypesQueryKey(false) });
    } catch (error) {
      toast({ title: "Could not update category type", description: error instanceof Error ? error.message : "Try again.", variant: "destructive" });
    }
  };
  const openNew = () => { setEditingId(null); setForm({ ...emptyForm, sortOrder: (labs?.length || 0) + 1 }); setShowEditor(true); };
  const openEdit = (lab: SecurityLab) => { setEditingId(lab.id); setForm(formFromLab(lab)); setShowEditor(true); };
  const update = <K extends keyof LabForm>(key: K, value: LabForm[K]) => setForm((current) => ({ ...current, [key]: value }));
  const field = (key: keyof LabForm, label: string, multiline = false) => <div className={multiline ? "sm:col-span-2" : ""}><Label className="editorial-kicker text-muted-foreground">{label}</Label>{multiline ? <Textarea value={key === "hints" ? (form.hints || []).join("\n") : String(form[key] ?? "")} onChange={(event) => update(key, key === "hints" ? event.target.value.split("\n") : event.target.value as LabForm[typeof key])} className="mt-2 min-h-24 bg-background/60" /> : <Input value={String(form[key] ?? "")} type={key === "estimatedMinutes" || key === "sortOrder" ? "number" : "text"} onChange={(event) => update(key, (key === "estimatedMinutes" || key === "sortOrder" ? Number(event.target.value) : event.target.value) as LabForm[typeof key])} className="mt-2 bg-background/60" />}</div>;

  return <section className="space-y-6">
    <div className="flex flex-col gap-4 border-b border-border pb-6 sm:flex-row sm:items-end sm:justify-between"><div><p className="editorial-kicker text-primary">Safe simulations</p><h2 className="editorial-display mt-2 text-5xl leading-none">Security Lab</h2><p className="mt-3 max-w-2xl text-sm leading-6 text-muted-foreground">Publish carefully scoped learning surfaces without exposing visitor answers or connecting demos to real systems.</p></div><Button onClick={openNew} className="gap-2 rounded-full"><Plus className="h-4 w-4" /> New lab</Button></div>
    {showEditor && <form onSubmit={save} className="soft-card space-y-6 rounded-2xl p-5 sm:p-6"><div className="flex items-center justify-between border-b border-border/60 pb-4"><div><p className="editorial-kicker text-primary">{editingId ? "Edit record" : "New record"}</p><h3 className="mt-1 text-lg font-semibold">{editingId ? "Revise simulation" : "Draft a simulation"}</h3></div><button type="button" onClick={() => setShowEditor(false)} aria-label="Close editor" className="text-muted-foreground hover:text-foreground"><X className="h-4 w-4" /></button></div><div className="grid gap-4 sm:grid-cols-2">{field("title", "TITLE")}{field("slug", "SLUG")}{field("shortDescription", "SHORT DESCRIPTION", true)}{field("category", "CATEGORY")}{field("difficulty", "DIFFICULTY")}{field("demoType", "DEMO TYPE")}{field("estimatedMinutes", "MINUTES")}{field("sortOrder", "SORT ORDER")}{field("learningObjective", "LEARNING OBJECTIVE", true)}{field("challengeDescription", "CHALLENGE DESCRIPTION", true)}{field("task", "TASK", true)}{field("hints", "HINTS · ONE PER LINE", true)}{field("expectedResult", "EXPECTED RESULT", true)}{field("explanation", "EXPLANATION", true)}</div><div className="flex flex-wrap gap-2 border-t border-border/60 pt-5"><Toggle label="Published" active={form.published} onClick={() => update("published", !form.published)} icon={form.published ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />} /><Toggle label="Enabled" active={form.enabled} onClick={() => update("enabled", !form.enabled)} /><Toggle label="Featured" active={form.featured} onClick={() => update("featured", !form.featured)} icon={<Star className="h-3 w-3" />} /></div><div className="flex gap-2"><Button disabled={saving} type="submit" className="gap-2"><Save className="h-4 w-4" /> {saving ? "Saving..." : editingId ? "Save changes" : "Create lab"}</Button><Button type="button" variant="outline" onClick={() => setShowEditor(false)}>Cancel</Button></div></form>}
    <div className="soft-card overflow-hidden rounded-2xl"><div className="flex items-center justify-between border-b border-border/60 px-5 py-4"><span className="font-mono text-xs text-primary">LAB_REGISTRY</span><span className="font-mono text-[10px] text-muted-foreground">{labs?.length || 0} records</span></div>{isLoading ? <p className="p-5 text-sm text-muted-foreground">Loading lab records...</p> : isError ? <p className="p-5 text-sm text-destructive">The lab registry could not be loaded.</p> : sortedLabs.length ? <div className="divide-y divide-border/60">{sortedLabs.map((lab) => <div key={lab.id} className="flex flex-col gap-4 p-4 lg:flex-row lg:items-center"><div className="flex min-w-0 flex-1 items-start gap-3"><span className={`mt-1 h-2 w-2 shrink-0 rounded-full ${lab.enabled && lab.published ? "bg-primary" : "bg-border"}`} /><div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><p className="truncate text-sm font-semibold">{lab.title}</p><span className="font-mono text-[10px] text-muted-foreground">{lab.category}</span></div><p className="mt-1 line-clamp-1 text-xs text-muted-foreground">{lab.slug} · {lab.difficulty} · {lab.demoType}</p></div></div><div className="flex flex-wrap items-center gap-2"><Toggle label={lab.published ? "Published" : "Draft"} active={lab.published} onClick={() => void patchLab(lab, { published: !lab.published })} icon={lab.published ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />} /><Toggle label={lab.enabled ? "Enabled" : "Disabled"} active={lab.enabled} onClick={() => void patchLab(lab, { enabled: !lab.enabled })} /><button title="Toggle featured" onClick={() => void patchLab(lab, { featured: !lab.featured })} className={lab.featured ? "rounded-full p-2 text-primary" : "rounded-full p-2 text-muted-foreground hover:text-primary"}><Star className="h-4 w-4" fill={lab.featured ? "currentColor" : "none"} /></button><button title="Edit lab" onClick={() => openEdit(lab)} className="rounded-full p-2 text-muted-foreground hover:text-primary"><Edit3 className="h-4 w-4" /></button><button title="Delete lab" onClick={() => void remove(lab)} className="rounded-full p-2 text-muted-foreground hover:text-destructive"><Trash2 className="h-4 w-4" /></button></div></div>)}</div> : <div className="p-10 text-center"><FlaskConical className="mx-auto h-7 w-7 text-muted-foreground" /><p className="mt-3 text-sm text-muted-foreground">No lab records yet. Start with a small safe simulation.</p></div>}</div>
    <div className="soft-card rounded-2xl p-5"><div className="flex items-center justify-between"><div><p className="editorial-kicker text-primary">Taxonomy controls</p><h3 className="mt-1 text-lg font-semibold">Enabled demo types</h3></div><span className="font-mono text-[10px] text-muted-foreground">PUBLIC FILTERS</span></div><p className="mt-3 text-sm leading-6 text-muted-foreground">Disable a type to remove it from the public lab categories while preserving its existing records.</p><div className="mt-5 flex flex-wrap gap-2">{types?.map((type) => <Toggle key={type.id} label={type.label} active={type.enabled} onClick={() => void toggleType(type.id, !type.enabled)} />)}</div></div>
  </section>;
}