import { challenges, storyMissions } from "./data";

const STORAGE_KEY = "portfolio-logic-breach-progress-v1";

export type LogicBreachProgress = {
  storyBest: number;
  storyCompleted: string[];
  storyCurrentMission: number;
  storyRunCompleted: string[];
  storyRunHints: string[];
  storyScore: number;
  storyStarted: boolean;
  challengeBest: Record<string, number>;
  challengeCompleted: string[];
};

export const emptyLogicBreachProgress = (): LogicBreachProgress => ({
  storyBest: 0,
  storyCompleted: [],
  storyCurrentMission: 1,
  storyRunCompleted: [],
  storyRunHints: [],
  storyScore: 0,
  storyStarted: false,
  challengeBest: {},
  challengeCompleted: [],
});

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function validIds(value: unknown, allowed: Set<string>): string[] {
  if (!Array.isArray(value)) return [];
  return [...new Set(value.filter((item): item is string => typeof item === "string" && allowed.has(item)))];
}

function score(value: unknown, max: number): number {
  return typeof value === "number" && Number.isFinite(value) ? Math.max(0, Math.min(max, Math.floor(value))) : 0;
}

export function validateStoredProgress(value: unknown): LogicBreachProgress {
  const fallback = emptyLogicBreachProgress();
  if (!isRecord(value)) return fallback;
  const storyIds = new Set(storyMissions.map((puzzle) => puzzle.id));
  const challengeIds = new Set(challenges.map((puzzle) => puzzle.id));
  const storyCompleted = validIds(value.storyCompleted, storyIds);
  const storyRunIds = validIds(value.storyRunCompleted, storyIds).filter((id) => storyCompleted.includes(id));
  const storyRunCompleted: string[] = [];
  for (const mission of storyMissions) {
    if (!storyRunIds.includes(mission.id)) break;
    storyRunCompleted.push(mission.id);
  }
  const storyStarted = value.storyStarted === true;
  const storyUnlocked = Math.min(storyMissions.length, storyRunCompleted.length + 1);
  const storyCurrentMission = typeof value.storyCurrentMission === "number"
    && Number.isInteger(value.storyCurrentMission)
    && value.storyCurrentMission >= 1
    && value.storyCurrentMission <= storyUnlocked
    ? value.storyCurrentMission
    : storyUnlocked;
  const storyRunHints = validIds(value.storyRunHints, new Set(storyMissions.slice(0, storyUnlocked).map((puzzle) => puzzle.id)));
  const challengeBest: Record<string, number> = {};
  if (isRecord(value.challengeBest)) {
    for (const [id, best] of Object.entries(value.challengeBest)) {
      if (challengeIds.has(id)) challengeBest[id] = score(best, 1000);
    }
  }
  return {
    storyBest: score(value.storyBest, storyMissions.reduce((total, puzzle) => total + puzzle.baseScore, 0)),
    storyCompleted,
    storyCurrentMission: storyStarted ? storyCurrentMission : 1,
    storyRunCompleted: storyStarted ? storyRunCompleted : [],
    storyRunHints: storyStarted ? storyRunHints : [],
    storyScore: storyStarted ? score(value.storyScore, storyMissions.reduce((total, puzzle) => total + puzzle.baseScore, 0)) : 0,
    storyStarted,
    challengeBest,
    challengeCompleted: validIds(value.challengeCompleted, challengeIds),
  };
}

export function readLogicBreachProgress(): LogicBreachProgress {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return emptyLogicBreachProgress();
    return validateStoredProgress(JSON.parse(raw) as unknown);
  } catch {
    return emptyLogicBreachProgress();
  }
}

export function writeLogicBreachProgress(progress: LogicBreachProgress): boolean {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(validateStoredProgress(progress)));
    return true;
  } catch {
    return false;
  }
}

export function resetLogicBreachProgress(): boolean {
  try {
    window.localStorage.removeItem(STORAGE_KEY);
    return true;
  } catch {
    return false;
  }
}

export const logicBreachStorageKey = STORAGE_KEY;
