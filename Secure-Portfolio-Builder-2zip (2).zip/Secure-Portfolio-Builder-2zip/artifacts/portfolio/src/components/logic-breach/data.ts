export type Difficulty = "Easy" | "Medium" | "Hard";
export type Choice = { id: string; label: string };
export type Puzzle = {
  id: string;
  title: string;
  category: string;
  difficulty: Difficulty;
  instructions: string;
  prompt: string;
  evidence: string[];
  choices?: Choice[];
  answer: string;
  acceptedAnswers?: string[];
  hint: string;
  explanation: string;
  baseScore: number;
  narrative?: string;
  truthTable?: Array<{ a: string; b: string; output: string }>;
};

export const storyMissions: Puzzle[] = [
  {
    id: "story-01", title: "The First Pattern", category: "Sequence analysis", difficulty: "Easy",
    instructions: "Identify the rule, then select the next archive pulse.",
    prompt: "3, 6, 12, 24, 48, ?",
    evidence: ["Each pulse is recorded as a whole number.", "The archive repeats one consistent operation between pulses."],
    choices: [{ id: "72", label: "72" }, { id: "96", label: "96" }, { id: "51", label: "51" }, { id: "84", label: "84" }],
    answer: "96", hint: "Compare each pulse with the one immediately before it.",
    explanation: "Every pulse doubles. 48 × 2 gives 96, revealing the archive's repeating heartbeat.",
    baseScore: 100, narrative: "The signal is not random. A repeating heartbeat survived the interruption.",
  },
  {
    id: "story-02", title: "Cipher Fragment", category: "Caesar cipher", difficulty: "Easy",
    instructions: "Decode the short note using the shift clue. Enter the phrase.",
    prompt: "Encrypted note: FKHFN WKH OLEUDUB",
    evidence: ["The archive's note card says: “Three steps backward.”", "The original message uses ordinary English words."],
    answer: "check the library", hint: "Move each letter three places back in the alphabet; preserve spaces.",
    explanation: "A Caesar shift of three backward turns FKHFN into CHECK, WKH into THE, and OLEUDUB into LIBRARY.",
    baseScore: 120, narrative: "A note points to the library index. Someone left a route through the archive.",
  },
  {
    id: "story-03", title: "The Log Puzzle", category: "Timestamp ordering", difficulty: "Medium",
    instructions: "Select the only sequence consistent with the recorded dependencies.",
    prompt: "Which event order is possible?",
    evidence: ["09:14:02 — index sealed (shown first in the copied view).", "09:13:11 — catalog copied.", "09:13:19 — checksum written.", "The event cards were copied from a shuffled index, so their displayed order is not chronological.", "The checksum is written after the catalog copy.", "The index is sealed after the checksum."],
    choices: [
      { id: "copy-checksum-seal", label: "Copy → checksum → seal" },
      { id: "seal-copy-checksum", label: "Seal → copy → checksum" },
      { id: "checksum-copy-seal", label: "Checksum → copy → seal" },
      { id: "copy-seal-checksum", label: "Copy → seal → checksum" },
    ],
    answer: "copy-checksum-seal", hint: "The written times are shuffled. Follow the dependency sentences, not the display order.",
    explanation: "The copy must precede the checksum, and the checksum must precede the seal. Only copy → checksum → seal satisfies both clues.",
    baseScore: 140, narrative: "The timestamps were presented out of order, but the dependencies restore a coherent record.",
  },
  {
    id: "story-04", title: "Logic Gate", category: "Boolean logic", difficulty: "Medium",
    instructions: "Apply the stated rule to the two archive flags.",
    prompt: "The review gate opens only when exactly one flag is ON. What is the output?",
    evidence: ["Flag A: ON", "Flag B: ON", "The gate uses XOR: ON when inputs differ; OFF when they match."],
    choices: [{ id: "on", label: "ON" }, { id: "off", label: "OFF" }, { id: "unknown", label: "Cannot be determined" }, { id: "both", label: "Both outputs" }],
    answer: "off", hint: "XOR checks whether the two inputs are different.",
    explanation: "Both flags are ON, so they match. XOR is OFF when inputs match.",
    baseScore: 150, narrative: "The review gate was configured as a parity check, not a simple all-clear.",
    truthTable: [
      { a: "OFF", b: "OFF", output: "OFF" },
      { a: "OFF", b: "ON", output: "ON" },
      { a: "ON", b: "OFF", output: "ON" },
      { a: "ON", b: "ON", output: "OFF" },
    ],
  },
  {
    id: "story-05", title: "The Final Breach", category: "Multi-clue deduction", difficulty: "Hard",
    instructions: "Use all three clues to identify the archive entry that was moved.",
    prompt: "Which record was moved from its original shelf?",
    evidence: ["The missing record is the only one tagged SIGNAL.", "The moved record was last verified after 16:00.", "Only one entry matches both clues.", "Aster: BOTANY · 16:22. Beacon: SIGNAL · 15:48. Chorus: SIGNAL · 16:17. Drift: MAPS · 16:31."],
    choices: [{ id: "aster", label: "Aster" }, { id: "beacon", label: "Beacon" }, { id: "chorus", label: "Chorus" }, { id: "drift", label: "Drift" }],
    answer: "chorus", hint: "First keep only SIGNAL records, then compare their verification times with 16:00.",
    explanation: "Beacon has the SIGNAL tag but was verified before 16:00. Chorus is tagged SIGNAL and verified at 16:17, so it is the only record matching both clues.",
    baseScore: 200, narrative: "Chorus was moved, not erased. The archive is whole again; the interruption was a routing error, not a disappearance.",
  },
];

export const challenges: Puzzle[] = [
  { id: "ch-sequence-01", title: "Steady Cadence", category: "Number and sequence patterns", difficulty: "Easy", instructions: "Choose the next value in the sequence.", prompt: "5, 9, 13, 17, ?", evidence: ["The same amount is added each time."], choices: [{ id: "20", label: "20" }, { id: "21", label: "21" }, { id: "22", label: "22" }, { id: "25", label: "25" }], answer: "21", hint: "Subtract adjacent values to find the step.", explanation: "The sequence increases by 4 each time, so 17 + 4 = 21.", baseScore: 80 },
  { id: "ch-caesar-02", title: "A Quiet Reminder", category: "Caesar cipher decoding", difficulty: "Easy", instructions: "Decode the message with the supplied shift.", prompt: "Encrypted: UHWXUQ WKH NHB", evidence: ["Shift each letter three places backward.", "Spaces stay in place."], answer: "return the key", hint: "R becomes O when shifted three places backward.", explanation: "Applying a Caesar shift of −3 to every letter yields RETURN THE KEY.", baseScore: 90 },
  { id: "ch-symbol-03", title: "Glyph Index", category: "Simple substitution / symbol mapping", difficulty: "Medium", instructions: "Use the mapping to read the marked sequence.", prompt: "Read: △ ○ □", evidence: ["△ = C", "○ = A", "□ = T"], choices: [{ id: "cat", label: "CAT" }, { id: "cap", label: "CAP" }, { id: "act", label: "ACT" }, { id: "tac", label: "TAC" }], answer: "cat", hint: "Translate each symbol in order; keep the order exactly as shown.", explanation: "△ ○ □ maps to C-A-T, so the label reads CAT.", baseScore: 110 },
  { id: "ch-deduction-04", title: "Three Desk Notes", category: "Logical deduction", difficulty: "Medium", instructions: "Identify who filed the sealed folder.", prompt: "Who filed the folder?", evidence: ["Mina: “I did not file it.”", "Oren: “Pia filed it.”", "Pia: “Oren is not telling the truth.”", "Exactly one note is true."], choices: [{ id: "mina", label: "Mina" }, { id: "oren", label: "Oren" }, { id: "pia", label: "Pia" }, { id: "cannot", label: "Not enough evidence" }], answer: "mina", hint: "Test each possible filer and count which statements become true.", explanation: "If Mina filed it: Mina's note is false, Oren's note is false, and Pia's note is true—exactly one true statement.", baseScore: 120 },
  { id: "ch-boolean-05", title: "Paired Lamps", category: "Boolean logic", difficulty: "Easy", instructions: "Evaluate the rule exactly as written.", prompt: "A lamp is ON only if both switches are ON. Switch A is ON; Switch B is OFF. What is the lamp state?", evidence: ["Rule: A AND B.", "AND is ON only when both inputs are ON."], choices: [{ id: "on", label: "ON" }, { id: "off", label: "OFF" }, { id: "unknown", label: "Unknown" }], answer: "off", hint: "One OFF input is enough to make an AND output OFF.", explanation: "The second switch is OFF, so both are not ON. The AND result is OFF.", baseScore: 80 },
  { id: "ch-truth-06", title: "Truth Table Row", category: "Truth-table reasoning", difficulty: "Medium", instructions: "Select the output for the specified row.", prompt: "For OR, what is the output when A = OFF and B = ON?", evidence: ["OR is ON if at least one input is ON.", "Both inputs must be OFF for an OR output of OFF."], choices: [{ id: "on", label: "ON" }, { id: "off", label: "OFF" }, { id: "both", label: "ON and OFF" }], answer: "on", hint: "At least one input is ON.", explanation: "B is ON, which is sufficient for an OR output of ON.", baseScore: 110 },
  { id: "ch-time-07", title: "Restore the Timeline", category: "Timestamp ordering", difficulty: "Easy", instructions: "Select the chronological event order.", prompt: "Which sequence runs earliest to latest?", evidence: ["A — 10:42 record indexed", "B — 10:18 note received", "C — 10:31 checksum logged"], choices: [{ id: "bca", label: "B → C → A" }, { id: "abc", label: "A → B → C" }, { id: "cab", label: "C → A → B" }, { id: "bac", label: "B → A → C" }], answer: "bca", hint: "Compare the minutes: 18, 31, then 42.", explanation: "10:18 comes first, then 10:31, then 10:42: B → C → A.", baseScore: 80 },
  { id: "ch-evidence-08", title: "The Seal That Changed", category: "Evidence analysis", difficulty: "Hard", instructions: "Choose the conclusion supported by every stated fact.", prompt: "What can the review team conclude?", evidence: ["At 14:00, card 27 is listed as sealed.", "At 14:10, card 27 is listed as open.", "No opening event appears in the displayed record.", "The record excerpt may be incomplete."], choices: [{ id: "tamper", label: "Someone definitely tampered with the card." }, { id: "gap", label: "The excerpt does not explain the change; more evidence is needed." }, { id: "never", label: "The 14:00 entry is definitely false." }, { id: "system", label: "The archive system caused the change." }], answer: "gap", hint: "Separate what the excerpt shows from what it does not prove.", explanation: "The entries conflict, but an incomplete excerpt cannot identify a cause or prove tampering. The defensible conclusion is that more evidence is needed.", baseScore: 160 },
  { id: "ch-pattern-09", title: "Index Marks", category: "Pattern recognition", difficulty: "Medium", instructions: "Find the next mark in the repeating sequence.", prompt: "○, △, △, □, ○, △, △, ?", evidence: ["The four-mark group repeats without changing."], choices: [{ id: "circle", label: "○" }, { id: "triangle", label: "△" }, { id: "square", label: "□" }, { id: "diamond", label: "◇" }], answer: "square", hint: "Split the sequence into groups of four.", explanation: "The repeating group is ○, △, △, □. The eighth mark is □.", baseScore: 110 },
  { id: "ch-word-10", title: "Letter Ledger", category: "Word and symbol puzzles", difficulty: "Hard", instructions: "Use the letter positions to decode the label.", prompt: "The archive uses A=1, B=2 … Z=26. Decode 3–1–20.", evidence: ["Each number maps to one letter.", "Read left to right."], choices: [{ id: "cat", label: "CAT" }, { id: "cab", label: "CAB" }, { id: "act", label: "ACT" }, { id: "car", label: "CAR" }], answer: "cat", hint: "Convert 3, 1, and 20 separately.", explanation: "3 = C, 1 = A, and 20 = T. The label reads CAT.", baseScore: 140 },
  { id: "ch-policy-11", title: "Two-Key Policy", category: "Access-policy reasoning", difficulty: "Medium", instructions: "Apply the fictional policy to the request.", prompt: "May Leena approve the sealed bundle alone?", evidence: ["Policy: opening requires one curator AND one archivist.", "Leena is a curator.", "No archivist is present."], choices: [{ id: "yes", label: "Yes, her curator role is enough." }, { id: "no", label: "No, the archivist role is also required." }, { id: "maybe", label: "Only if the bundle is sealed." }], answer: "no", hint: "The policy uses AND, so both roles must be present.", explanation: "Leena satisfies the curator requirement, but there is no archivist. Both are required, so she cannot approve alone.", baseScore: 120 },
  { id: "ch-multiclue-12", title: "The Unlisted Copy", category: "Multi-clue deduction", difficulty: "Hard", instructions: "Identify which copy matches both conditions.", prompt: "Which copy is the likely unlisted duplicate?", evidence: ["It is marked amber.", "It was made before 12:00.", "North: amber · 11:42 · listed", "East: blue · 11:35 · unlisted", "South: amber · 12:08 · unlisted", "West: amber · 11:51 · unlisted"], choices: [{ id: "north", label: "North" }, { id: "east", label: "East" }, { id: "south", label: "South" }, { id: "west", label: "West" }], answer: "west", hint: "Filter by amber and before noon, then check which remaining copy is unlisted.", explanation: "West is amber, timestamped 11:51, and unlisted. North is listed; East is blue; South is after noon.", baseScore: 180 },
];

export function normalizeAnswer(value: string): string {
  return value.trim().toLocaleLowerCase().replace(/\s+/g, " ");
}

export function validateAnswer(puzzle: Pick<Puzzle, "answer" | "acceptedAnswers">, submitted: string): boolean {
  const answer = normalizeAnswer(submitted);
  if (!answer) return false;
  return [puzzle.answer, ...(puzzle.acceptedAnswers ?? [])].some((candidate) => normalizeAnswer(candidate) === answer);
}

export const validatePuzzleAnswer = validateAnswer;
