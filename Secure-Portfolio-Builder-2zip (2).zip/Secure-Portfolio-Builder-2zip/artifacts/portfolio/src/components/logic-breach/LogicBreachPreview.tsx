import { ArrowRight, ArrowUpRight, Check, LockKeyhole, ScanLine } from "lucide-react";
import { Link } from "wouter";

export function LogicBreachPreview() {
  return (
    <section className="relative mb-16 overflow-hidden rounded-[1.75rem] border border-border bg-card/80" data-testid="section-logic-breach">
      <div className="absolute -right-12 -top-20 hidden h-72 w-72 rounded-full border border-foreground/10 md:block" aria-hidden="true" />
      <div className="grid gap-8 p-6 sm:p-8 lg:grid-cols-[1fr_310px] lg:items-center lg:p-10">
        <div className="relative">
          <p className="editorial-kicker text-primary">A new archive investigation</p>
          <h2 className="editorial-display mt-2 text-5xl leading-none sm:text-6xl">Logic <span className="italic">Breach.</span></h2>
          <p className="mt-4 max-w-2xl text-sm leading-6 text-muted-foreground">Think clearly. Break the pattern. Solve the breach. Join a junior analyst tracing an interrupted archive through fair, fictional logic puzzles.</p>
          <ul className="mt-5 flex flex-wrap gap-x-5 gap-y-2 text-xs text-muted-foreground">
            {["Five connected story missions", "12 independent challenges", "Local-only progress"].map((item) => (
              <li key={item} className="inline-flex items-center gap-2"><Check size={13} className="text-primary" aria-hidden="true" />{item}</li>
            ))}
          </ul>
          <div className="mt-7 flex flex-wrap gap-3">
            <Link href="/logic-breach" className="inline-flex min-h-11 items-center gap-2 rounded-full bg-foreground px-5 py-3 text-sm font-semibold text-background transition-colors hover:bg-foreground/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary" data-testid="link-play-logic-breach">
              Play Logic Breach <ArrowRight size={15} aria-hidden="true" />
            </Link>
            <Link href="/logic-breach?mode=challenges" className="inline-flex min-h-11 items-center gap-2 rounded-full border border-border px-5 py-3 text-sm font-semibold transition-colors hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary" data-testid="link-explore-logic-challenges">
              Explore challenges <ArrowUpRight size={15} aria-hidden="true" />
            </Link>
          </div>
          <p className="mt-4 inline-flex items-center gap-2 text-[11px] text-muted-foreground"><LockKeyhole size={12} aria-hidden="true" /> A safe, offline-ready browser simulation. No real systems involved.</p>
        </div>
        <div className="relative rounded-2xl bg-foreground p-5 text-background shadow-[0_18px_45px_hsl(224_26%_15%/.12)]" aria-label="Decorative puzzle preview">
          <div className="flex items-center justify-between border-b border-background/15 pb-3">
            <span className="editorial-kicker text-primary">Signal fragment / 01</span>
            <ScanLine size={16} className="text-primary" aria-hidden="true" />
          </div>
          <p className="mt-5 font-mono text-xs text-background/55">ARCHIVE PULSE</p>
          <p className="mt-2 font-mono text-2xl tracking-[.18em] sm:text-3xl">03 · 06 · 12 · 24 · <span className="text-primary">?</span></p>
          <div className="mt-5 grid grid-cols-4 gap-2" aria-hidden="true">
            {["36", "48", "51", "96"].map((value, index) => <span key={value} className={`rounded-lg border px-2 py-2.5 text-center font-mono text-xs ${index === 3 ? "border-primary bg-primary text-foreground" : "border-background/15 bg-background/[.05] text-background/75"}`}>{value}</span>)}
          </div>
          <div className="mt-5 flex items-center gap-2 text-[10px] uppercase tracking-[.14em] text-background/45"><span className="h-1.5 w-1.5 rounded-full bg-primary" /> Evidence-led · no guessing required</div>
        </div>
      </div>
    </section>
  );
}
