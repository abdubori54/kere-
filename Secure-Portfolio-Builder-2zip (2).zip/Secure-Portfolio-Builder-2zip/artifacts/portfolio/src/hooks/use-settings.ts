import { useQuery } from "@tanstack/react-query";
import { apiFetch, type SiteSettings } from "@/lib/api";

export function useSettings() {
  return useQuery({
    queryKey: ["/api/settings"],
    queryFn: () => apiFetch<SiteSettings>("/api/settings"),
    staleTime: 30_000,
  });
}