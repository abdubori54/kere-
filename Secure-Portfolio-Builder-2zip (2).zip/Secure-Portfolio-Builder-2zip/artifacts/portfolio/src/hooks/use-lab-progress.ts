import { useCallback, useState } from "react";

const STORAGE_KEY = "security-archive:lab-progress";
type ProgressMap = Record<string, boolean>;

function readProgress(): ProgressMap {
  if (typeof window === "undefined") return {};
  try {
    const value = JSON.parse(window.localStorage.getItem(STORAGE_KEY) || "{}");
    return value && typeof value === "object" ? value : {};
  } catch {
    return {};
  }
}

export function useLabProgress() {
  const [progress, setProgress] = useState<ProgressMap>(readProgress);
  const setComplete = useCallback((slug: string, complete: boolean) => {
    setProgress((current) => {
      const next = { ...current, [slug]: complete };
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      return next;
    });
  }, []);
  const reset = useCallback((slug: string) => setComplete(slug, false), [setComplete]);
  return { progress, setComplete, reset };
}