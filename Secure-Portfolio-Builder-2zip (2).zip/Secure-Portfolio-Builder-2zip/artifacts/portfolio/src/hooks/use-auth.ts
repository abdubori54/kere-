import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";

export function useAuth({ enabled = true }: { enabled?: boolean } = {}) {
  const queryClient = useQueryClient();
  const status = useQuery({
    queryKey: ["/api/admin/me"],
    queryFn: () => apiFetch<{ isAdmin: boolean }>("/api/admin/me"),
    retry: false,
    enabled,
  });

  return {
    isAdmin: status.data?.isAdmin === true,
    isLoading: status.isLoading,
    login: async (data: { username: string; password: string }) => {
      const result = await apiFetch<{ isAdmin: boolean }>("/api/admin/login", { method: "POST", body: JSON.stringify(data) });
      await queryClient.invalidateQueries({ queryKey: ["/api/admin/me"] });
      return result;
    },
    logout: async () => {
      const result = await apiFetch("/api/admin/logout", { method: "POST" });
      await queryClient.invalidateQueries({ queryKey: ["/api/admin/me"] });
      return result;
    },
    isLoggingIn: false,
    isLoggingOut: false,
  };
}
