import { useQuery } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";

export type SecurityLab = {
  id: number;
  slug: string;
  title: string;
  shortDescription: string;
  category: string;
  difficulty: string;
  estimatedMinutes: number;
  learningObjective: string;
  challengeDescription: string;
  task: string;
  hints: string[];
  expectedResult: string;
  explanation: string;
  demoType: string;
  published: boolean;
  enabled: boolean;
  featured: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
};

export type SecurityLabType = {
  id: number;
  slug: string;
  label: string;
  enabled: boolean;
  sortOrder: number;
};

export const securityLabsQueryKey = (admin = false) => ["/api/security-labs", admin ? "admin" : "public"];
export const securityLabQueryKey = (slug: string, admin = false) => ["/api/security-labs", slug, admin ? "admin" : "public"];
export const securityLabTypesQueryKey = (admin = false) => ["/api/security-labs/types", admin ? "admin" : "public"];

export function useSecurityLabs(admin = false) {
  return useQuery({
    queryKey: securityLabsQueryKey(admin),
    queryFn: () => apiFetch<SecurityLab[]>(`/api/security-labs${admin ? "?admin=1" : ""}`),
  });
}

export function useSecurityLab(slug: string, admin = false) {
  return useQuery({
    queryKey: securityLabQueryKey(slug, admin),
    queryFn: () => apiFetch<SecurityLab>(`/api/security-labs/${encodeURIComponent(slug)}${admin ? "?admin=1" : ""}`),
    enabled: Boolean(slug),
  });
}

export function useSecurityLabTypes(admin = false) {
  return useQuery({
    queryKey: securityLabTypesQueryKey(admin),
    queryFn: () => apiFetch<SecurityLabType[]>(`/api/security-labs/types${admin ? "?admin=1" : ""}`),
  });
}