import { useQueryClient } from "@tanstack/react-query";
import { 
  useGetCertificates, 
  getGetCertificatesQueryKey,
  useGetCertificateStats,
  getGetCertificateStatsQueryKey,
  useGetCertificate,
  getGetCertificateQueryKey,
  useDeleteCertificate
} from "@workspace/api-client-react";

export function useCertificatesData() {
  return useGetCertificates({
    query: {
      queryKey: getGetCertificatesQueryKey()
    }
  });
}

export function useCertificateStatsData() {
  return useGetCertificateStats({
    query: {
      queryKey: getGetCertificateStatsQueryKey()
    }
  });
}

export function useCertificateData(id: number) {
  return useGetCertificate(id, {
    query: {
      queryKey: getGetCertificateQueryKey(id),
      enabled: !!id
    }
  });
}

export function useDeleteCert() {
  const queryClient = useQueryClient();
  
  return useDeleteCertificate({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetCertificatesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetCertificateStatsQueryKey() });
      }
    }
  });
}

export const uploadCertificateFetch = async (formData: FormData) => {
  const res = await fetch('/api/certificates', { 
    method: 'POST', 
    body: formData, 
    credentials: 'include' 
  });
  if (!res.ok) throw new Error('Upload failed');
  return res.json();
};
