import { useMemo, useState } from "react";
import { ArrowUpRight, FlaskConical, Search, ShieldCheck } from "lucide-react";
import { Link } from "wouter";
import { useSecurityLabTypes, useSecurityLabs } from "@/hooks/use-security-labs";
import { useLabProgress } from "@/hooks/use-lab-progress";
import { CompletionMark, FeaturedMark, LabMeta } from "@/components/security-lab/LabBadge";
import { Skeleton } from "@/components/ui/skeleton";

export default function SecurityLabIndex() {
  const { data: labs, isLoading, isError, refetch } = useSecurityLabs();
  const { data: types } = useSecurityLabTypes();
  const { progress } = useLabProgress();
  const [category, setCategory] = useState("All labs");
  const [query, setQuery] = useState("");
  const [onlyOpen, setOnlyOpen] = useState(false);
  const categories = useMemo(() => ["All labs", ...Array.from(new Set([...(types || []).map((type) => type.label), ...(labs || []).map((lab) => lab.category).filter(Boolean)]))], [labs, types]);
  const filteredLabs = useMemo(() => (labs || []).filter((lab) => {
    const matchCategory = category === "All labs" || lab.category === category;
    const matchQuery = !query.trim() || `${lab.title} ${lab.shortDescription} ${lab.category}`.toLowerCase().includes(query.toLowerCase());
    const matchOpen = !onlyOpen || !progress[lab.slug];
    return matchCategory && matchQuery && matchOpen;
  }), [labs, category, query, onlyOpen, progress]);
  const completedCount = labs?.filter((lab) => progress[lab.slug]).length || 0;
  const percent = labs?.length ? Math.round((completedCount / labs.length) * 100) : 0;

  return <div className="mx-auto max-w-7xl px-4 pb-20 pt-8 sm:px-8 lg:px-12">
    <section className="relative overflow-hidden rounded-[2.2rem] bg-foreground px-6 py-12 text-background sm:px-12 lg:px-16 lg:py-16">
      <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full border-[3rem] border-primary/20" />
      <div className="absolute bottom-0 right-16 h-32 w-32 rounded-full bg-accent/15 blur-2xl" />
      <div className="relative z-10 max-w-3xl">
        <div className="mb-8 flex items-center gap-3"><span className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-foreground"><FlaskConical className="h-5 w-5" /></span><span className="editorial-kicker text-background/55">Safe simulations / 01</span></div>
        <h1 className="editorial-display text-[4.3rem] leading-[.86] tracking-[-.04em] sm:text-[6.2rem]">Security Lab</h1>
        <p className="mt-7 max-w-md text-sm leading-7 text-background/65">Learn security by interacting with safe simulations.</p>
        <div className="mt-10 flex flex-wrap items-end gap-8">
          <div><p className="font-mono text-[10px] uppercase tracking-[.16em] text-background/45">Local progress</p><p className="mt-2 text-3xl font-semibold">{completedCount}<span className="text-background/35"> / {labs?.length || 0}</span></p></div>
          <div className="w-44"><div className="mb-2 flex justify-between font-mono text-[10px] uppercase tracking-[.12em] text-background/45"><span>Archive signal</span><span>{percent}%</span></div><div className="h-1.5 overflow-hidden rounded-full bg-background/15"><div className="h-full rounded-full bg-primary transition-[width] duration-500" style={{ width: `${percent}%` }} /></div></div>
        </div>
      </div>
    </section>

    <section className="mt-14 space-y-7" aria-label="Security lab filters">
      <div className="flex flex-col gap-5 border-b border-border pb-6 lg:flex-row lg:items-end lg:justify-between">
        <div><p className="editorial-kicker text-primary">The practical index</p><h2 className="editorial-display mt-2 text-5xl leading-none">Choose a surface.</h2></div>
        <div className="flex w-full flex-col gap-3 sm:flex-row lg:w-auto">
          <label className="relative block"><span className="sr-only">Search labs</span><Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search labs" className="h-11 w-full rounded-full border border-border bg-card pl-11 pr-4 text-sm outline-none transition focus:border-primary sm:w-56" /></label>
          <button onClick={() => setOnlyOpen(!onlyOpen)} className={`h-11 rounded-full px-4 text-xs font-semibold transition ${onlyOpen ? "bg-foreground text-background" : "border border-border text-muted-foreground hover:border-primary hover:text-foreground"}`}>{onlyOpen ? "Showing open" : "Show open only"}</button>
        </div>
      </div>
      <div className="flex gap-2 overflow-x-auto pb-1">{categories.map((item) => <button key={item} onClick={() => setCategory(item)} className={`whitespace-nowrap rounded-full px-4 py-2 text-xs font-semibold transition ${category === item ? "bg-foreground text-background" : "border border-border text-muted-foreground hover:border-primary hover:text-foreground"}`}>{item}</button>)}</div>
      {isLoading ? <div className="grid gap-5 md:grid-cols-2">{[1, 2, 3, 4].map((item) => <Skeleton key={item} className="h-64 rounded-[1.7rem]" />)}</div> : isError ? <div className="soft-card rounded-[1.7rem] p-10 text-center"><ShieldCheck className="mx-auto h-7 w-7 text-destructive" /><p className="mt-4 text-sm text-muted-foreground">The lab index is temporarily unavailable.</p><button onClick={() => void refetch()} className="mt-5 rounded-full bg-foreground px-4 py-2 text-xs font-semibold text-background">Try again</button></div> : filteredLabs.length === 0 ? <div className="soft-card rounded-[1.7rem] p-14 text-center"><FlaskConical className="mx-auto h-7 w-7 text-muted-foreground" /><p className="mt-4 text-sm text-muted-foreground">No simulations match this view.</p><button onClick={() => { setCategory("All labs"); setQuery(""); setOnlyOpen(false); }} className="mt-5 text-xs font-semibold text-primary">Clear filters</button></div> :
        <div className="grid gap-5 md:grid-cols-2">{filteredLabs.map((lab, index) => <Link key={lab.id} href={`/security-lab/${lab.slug}`} className="group soft-card relative flex min-h-64 flex-col overflow-hidden rounded-[1.7rem] p-6 transition-transform duration-500 hover:-translate-y-1 focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-4">
          <div className="absolute right-6 top-6 flex items-center gap-3">{lab.featured && <FeaturedMark />}<CompletionMark complete={Boolean(progress[lab.slug])} /></div>
          <div className="flex items-center gap-3"><span className="font-mono text-[10px] text-muted-foreground">LAB_{String(index + 1).padStart(2, "0")}</span><span className="h-px w-8 bg-border" /><span className="editorial-kicker text-primary">{lab.category}</span></div>
          <h3 className="editorial-display mt-9 max-w-sm pr-8 text-4xl leading-[.92] transition-colors group-hover:text-primary">{lab.title}</h3>
          <p className="mt-3 max-w-md text-sm leading-6 text-muted-foreground">{lab.shortDescription}</p>
          <div className="mt-auto flex items-end justify-between gap-4 pt-8"><LabMeta difficulty={lab.difficulty} minutes={lab.estimatedMinutes} /><span className="flex h-10 w-10 items-center justify-center rounded-full border border-border transition-colors group-hover:border-primary group-hover:bg-primary"><ArrowUpRight className="h-4 w-4" /></span></div>
        </Link>)}</div>}
    </section>
  </div>;
}