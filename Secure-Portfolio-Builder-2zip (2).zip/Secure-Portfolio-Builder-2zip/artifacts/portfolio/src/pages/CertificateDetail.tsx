import { useRoute } from "wouter";
import { Link } from "wouter";
import { useCertificateData } from "@/hooks/use-certificates-data";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, ExternalLink, Calendar, Building, FileText, Download } from "lucide-react";
import { format } from "date-fns";

export default function CertificateDetail() {
  const [, params] = useRoute("/certificates/:id");
  const id = parseInt(params?.id || "0");
  
  const { data: cert, isLoading } = useCertificateData(id);

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-5xl space-y-8">
        <Skeleton className="h-8 w-24 bg-muted/50 rounded-none" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Skeleton className="w-full aspect-video bg-muted/50 rounded-none" />
          </div>
          <div className="space-y-6">
            <Skeleton className="h-12 w-3/4 bg-muted/50 rounded-none" />
            <Skeleton className="h-6 w-1/2 bg-muted/50 rounded-none" />
            <Skeleton className="h-32 w-full bg-muted/50 rounded-none" />
          </div>
        </div>
      </div>
    );
  }

  if (!cert) {
    return (
      <div className="container mx-auto px-4 py-24 text-center">
        <div className="font-mono text-destructive text-xl mb-4">[ERROR: 404] RECORD NOT FOUND</div>
        <Link href="/">
          <Button variant="outline" className="font-mono rounded-none">RETURN TO REGISTRY</Button>
        </Link>
      </div>
    );
  }

  const isPdf = cert.fileUrl.toLowerCase().endsWith('.pdf');

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8">
        <Link href="/">
          <Button variant="ghost" className="font-mono text-muted-foreground hover:text-primary pl-0 gap-2 rounded-none">
            <ArrowLeft className="w-4 h-4" />
            BACK_TO_REGISTRY
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
        {/* Preview Area */}
        <div className="lg:col-span-8 border border-border/50 bg-card/20 p-2 lg:p-4 backdrop-blur relative group">
          <div className="absolute top-0 left-0 w-3 h-3 border-t border-l border-primary/50" />
          <div className="absolute top-0 right-0 w-3 h-3 border-t border-r border-primary/50" />
          <div className="absolute bottom-0 left-0 w-3 h-3 border-b border-l border-primary/50" />
          <div className="absolute bottom-0 right-0 w-3 h-3 border-b border-r border-primary/50" />
          
          <div className="bg-background relative w-full h-[50vh] lg:h-[70vh] flex items-center justify-center overflow-hidden border border-border/30">
            {isPdf ? (
              <iframe 
                src={`${cert.fileUrl}#toolbar=0`} 
                className="w-full h-full border-none bg-white"
                title={cert.title}
              />
            ) : (
              <img 
                src={cert.fileUrl} 
                alt={cert.title}
                className="max-w-full max-h-full object-contain mix-blend-screen opacity-90 hover:opacity-100 transition-opacity"
              />
            )}
            {!isPdf && <div className="absolute inset-0 bg-primary/5 pointer-events-none mix-blend-overlay" />}
          </div>
        </div>

        {/* Details Area */}
        <div className="lg:col-span-4 space-y-8 flex flex-col">
          <div className="space-y-4">
            {cert.category && (
              <Badge variant="outline" className="font-mono rounded-none text-primary border-primary/50 bg-primary/5">
                {cert.category}
              </Badge>
            )}
            <h1 className="text-3xl lg:text-4xl font-sans font-bold leading-tight text-foreground">
              {cert.title}
            </h1>
          </div>

          <div className="space-y-4 font-mono text-sm border-y border-border/50 py-6">
            <div className="flex items-start gap-3">
              <Building className="w-5 h-5 text-muted-foreground shrink-0 mt-0.5" />
              <div>
                <p className="text-muted-foreground text-xs">ISSUING AUTHORITY</p>
                <p className="text-foreground text-base mt-1">{cert.issuer}</p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <Calendar className="w-5 h-5 text-muted-foreground shrink-0 mt-0.5" />
              <div>
                <p className="text-muted-foreground text-xs">ISSUED DATE</p>
                <p className="text-foreground text-base mt-1">
                  {cert.issuedDate ? format(new Date(cert.issuedDate), 'MMMM dd, yyyy') : 'UNSPECIFIED'}
                </p>
              </div>
            </div>
          </div>

          {cert.description && (
            <div className="space-y-2 flex-1">
              <p className="font-mono text-xs text-primary/70 flex items-center gap-2">
                <FileText className="w-4 h-4" />
                RECORD_DETAILS
              </p>
              <div className="font-sans text-muted-foreground leading-relaxed">
                {cert.description}
              </div>
            </div>
          )}

          <div className="pt-6 mt-auto">
            <a href={cert.fileUrl} target="_blank" rel="noopener noreferrer" className="block">
              <Button className="w-full font-mono tracking-wider gap-2 rounded-none hover-glow transition-all" size="lg">
                {isPdf ? <Download className="w-4 h-4" /> : <ExternalLink className="w-4 h-4" />}
                ACCESS_ORIGINAL_FILE
              </Button>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
