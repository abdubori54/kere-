import { useState, useEffect, useCallback } from "react";
import { Link } from "wouter";
import { useCertificatesData, useCertificateStatsData } from "@/hooks/use-certificates-data";
import { useGetProfile, getGetProfileQueryKey } from "@workspace/api-client-react";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  type CarouselApi,
} from "@/components/ui/carousel";
import {
  Search,
  Database,
  Fingerprint,
  Activity,
  ChevronLeft,
  ChevronRight,
  FileText,
  Clock,
  Phone,
  Mail,
} from "lucide-react";
import { TerminalWidget } from "@/components/layout/Terminal";

function TerminalTyping({ text }: { text: string }) {
  const [displayed, setDisplayed] = useState("");
  const [index, setIndex] = useState(0);

  useEffect(() => {
    if (index < text.length) {
      const timer = setTimeout(() => {
        setDisplayed((prev) => prev + text[index]);
        setIndex((prev) => prev + 1);
      }, 48);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, [index, text]);

  return (
    <div className="font-mono text-xl md:text-3xl text-primary font-bold min-h-[40px] neon-text">
      {displayed}
      <span className="animate-pulse ml-1">_</span>
    </div>
  );
}

const CARD_COLORS = [
  { border: "#00ffcc", glow: "rgba(0,255,204,0.35)" },
  { border: "#7c3aed", glow: "rgba(124,58,237,0.35)" },
  { border: "#06b6d4", glow: "rgba(6,182,212,0.35)" },
  { border: "#f59e0b", glow: "rgba(245,158,11,0.35)" },
  { border: "#ec4899", glow: "rgba(236,72,153,0.35)" },
  { border: "#10b981", glow: "rgba(16,185,129,0.35)" },
];

function LinkedInIcon({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
    </svg>
  );
}

function InstagramIcon({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
    </svg>
  );
}

function TelegramIcon({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
      <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
    </svg>
  );
}

function ContactSection() {
  const { data: profile, isLoading } = useGetProfile({
    query: { queryKey: getGetProfileQueryKey() },
  });

  const hasAnyContact =
    profile?.phone ||
    profile?.email ||
    profile?.linkedin ||
    profile?.instagram ||
    profile?.telegram;

  if (isLoading) {
    return (
      <section className="space-y-4">
        <Skeleton className="h-6 w-40 bg-muted/40" />
        <Skeleton className="h-32 bg-muted/40" />
      </section>
    );
  }

  if (!profile || (!hasAnyContact && !profile.bio && !profile.name)) return null;

  return (
    <section className="space-y-8 border-t border-border/40 pt-12">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="h-px flex-1 bg-gradient-to-r from-primary/50 to-transparent" />
        <span className="font-mono text-xs tracking-widest text-primary/80">CONTACT_INFO</span>
        <div className="h-px flex-1 bg-gradient-to-l from-primary/50 to-transparent" />
      </div>

      {/* Name & Bio */}
      {(profile.name || profile.bio) && (
        <div className="space-y-3 max-w-2xl">
          {profile.name && (
            <h2 className="font-mono text-2xl font-bold text-foreground neon-text">
              {profile.name}
            </h2>
          )}
          {profile.bio && (
            <p className="text-muted-foreground leading-relaxed text-sm font-mono whitespace-pre-wrap border-l-2 border-primary/40 pl-4">
              {profile.bio}
            </p>
          )}
        </div>
      )}

      {/* Contact links */}
      {hasAnyContact && (
        <div className="flex flex-wrap gap-3">
          {profile.phone && (
            <a
              href={`tel:${profile.phone}`}
              className="contact-link group flex items-center gap-3 px-4 py-3 border border-border/50 bg-card/40 hover:border-primary/60 hover:bg-primary/5 transition-all duration-200"
              data-testid="link-phone"
            >
              <span className="text-primary group-hover:scale-110 transition-transform">
                <Phone size={18} />
              </span>
              <span className="font-mono text-sm text-foreground/80 group-hover:text-foreground">
                {profile.phone}
              </span>
            </a>
          )}

          {profile.email && (
            <a
              href={`mailto:${profile.email}`}
              className="contact-link group flex items-center gap-3 px-4 py-3 border border-border/50 bg-card/40 hover:border-[#ea4335]/60 hover:bg-[#ea4335]/5 transition-all duration-200"
              data-testid="link-email"
            >
              <span className="text-[#ea4335] group-hover:scale-110 transition-transform">
                <Mail size={18} />
              </span>
              <span className="font-mono text-sm text-foreground/80 group-hover:text-foreground">
                {profile.email}
              </span>
            </a>
          )}

          {profile.linkedin && (
            <a
              href={profile.linkedin.startsWith("http") ? profile.linkedin : `https://linkedin.com/in/${profile.linkedin}`}
              target="_blank"
              rel="noopener noreferrer"
              className="contact-link group flex items-center gap-3 px-4 py-3 border border-border/50 bg-card/40 hover:border-[#0077b5]/60 hover:bg-[#0077b5]/10 transition-all duration-200"
              data-testid="link-linkedin"
            >
              <span className="text-[#0077b5] group-hover:scale-110 transition-transform">
                <LinkedInIcon size={18} />
              </span>
              <span className="font-mono text-sm text-foreground/80 group-hover:text-foreground">
                LinkedIn
              </span>
            </a>
          )}

          {profile.instagram && (
            <a
              href={profile.instagram.startsWith("http") ? profile.instagram : `https://instagram.com/${profile.instagram}`}
              target="_blank"
              rel="noopener noreferrer"
              className="contact-link group flex items-center gap-3 px-4 py-3 border border-border/50 bg-card/40 hover:border-[#e1306c]/60 hover:bg-[#e1306c]/10 transition-all duration-200"
              data-testid="link-instagram"
            >
              <span className="text-[#e1306c] group-hover:scale-110 transition-transform">
                <InstagramIcon size={18} />
              </span>
              <span className="font-mono text-sm text-foreground/80 group-hover:text-foreground">
                Instagram
              </span>
            </a>
          )}

          {profile.telegram && (
            <a
              href={profile.telegram.startsWith("http") ? profile.telegram : `https://t.me/${profile.telegram}`}
              target="_blank"
              rel="noopener noreferrer"
              className="contact-link group flex items-center gap-3 px-4 py-3 border border-border/50 bg-card/40 hover:border-[#26a5e4]/60 hover:bg-[#26a5e4]/10 transition-all duration-200"
              data-testid="link-telegram"
            >
              <span className="text-[#26a5e4] group-hover:scale-110 transition-transform">
                <TelegramIcon size={18} />
              </span>
              <span className="font-mono text-sm text-foreground/80 group-hover:text-foreground">
                Telegram
              </span>
            </a>
          )}
        </div>
      )}
    </section>
  );
}

export default function Home() {
  const { data: certs, isLoading: loadingCerts } = useCertificatesData();
  const { data: stats, isLoading: loadingStats } = useCertificateStatsData();
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [api, setApi] = useState<CarouselApi>();
  const [current, setCurrent] = useState(0);
  const [isCarouselPaused, setIsCarouselPaused] = useState(false);

  const filteredCerts = certs?.filter((c) => {
    const matchesSearch =
      c.title.toLowerCase().includes(search.toLowerCase()) ||
      c.issuer.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = activeCategory ? c.category === activeCategory : true;
    return matchesSearch && matchesCategory;
  });

  useEffect(() => {
    if (!api) return;
    const handleSelect = () => setCurrent(api.selectedScrollSnap());
    handleSelect();
    api.on("select", handleSelect);

    return () => {
      api.off("select", handleSelect);
    };
  }, [api]);

  useEffect(() => {
    if (api) {
      api.scrollTo(0, true);
      setCurrent(0);
    }
  }, [api, search, activeCategory]);

  useEffect(() => {
    if (!api || (filteredCerts?.length ?? 0) < 2 || isCarouselPaused) return;

    const autoScroll = window.setInterval(() => {
      if (document.visibilityState === "visible") {
        api.scrollNext();
      }
    }, 5200);

    return () => window.clearInterval(autoScroll);
  }, [api, filteredCerts?.length, isCarouselPaused]);

  const scrollPrev = useCallback(() => api?.scrollPrev(), [api]);
  const scrollNext = useCallback(() => api?.scrollNext(), [api]);

  return (
    <div className="container mx-auto px-4 py-12 max-w-6xl space-y-16">
      {/* Hero */}
      <section className="space-y-6">
        <TerminalTyping text="> INITIALIZING SECURE CERTIFICATE VAULT..." />
        <p className="text-muted-foreground font-mono max-w-2xl border-l-2 border-primary/60 pl-4 py-1 text-[12px] ml-[-2px]">Protect. Analyze. Secure.

        Passionate about cybersecurity, ethical hacking, and digital defense.

        Turning curiosity into expertise, one challenge at a time.
</p>

        {loadingStats ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-8">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-24 bg-muted/50 border-border/50" />
            ))}
          </div>
        ) : stats ? (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-8">
            <div className="p-5 flex items-center gap-4 border border-primary/40 bg-primary/5 backdrop-blur relative overflow-hidden">
              <div className="absolute inset-x-0 top-0 h-[2px] bg-gradient-to-r from-transparent via-primary to-transparent opacity-80" />
              <div className="p-3 bg-primary/15 text-primary rounded-lg">
                <Database className="w-6 h-6" />
              </div>
              <div>
                <p className="text-xs font-mono text-muted-foreground tracking-widest">TOTAL RECORDS</p>
                <p className="text-3xl font-bold font-mono text-primary">{stats.total}</p>
              </div>
            </div>

            <div className="p-5 flex items-center gap-4 border border-cyan-400/40 bg-cyan-400/5 backdrop-blur relative overflow-hidden">
              <div className="absolute inset-x-0 top-0 h-[2px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent opacity-80" />
              <div className="p-3 bg-cyan-400/15 text-cyan-400 rounded-lg">
                <Fingerprint className="w-6 h-6" />
              </div>
              <div>
                <p className="text-xs font-mono text-muted-foreground tracking-widest">CATEGORIES</p>
                <p className="text-3xl font-bold font-mono text-cyan-400">{stats.byCategory.length}</p>
              </div>
            </div>

            <div className="p-5 flex items-center gap-4 border border-violet-400/40 bg-violet-400/5 backdrop-blur relative overflow-hidden">
              <div className="absolute inset-x-0 top-0 h-[2px] bg-gradient-to-r from-transparent via-violet-400 to-transparent opacity-80" />
              <div className="p-3 bg-violet-400/15 text-violet-400 rounded-lg">
                <Activity className="w-6 h-6" />
              </div>
              <div>
                <p className="text-xs font-mono text-muted-foreground tracking-widest">SYSTEM STATUS</p>
                <p className="text-xl font-bold font-mono text-violet-400 flex items-center gap-2">
                  ONLINE <span className="w-2.5 h-2.5 rounded-full bg-violet-400 animate-pulse shadow-[0_0_8px_#7c3aed]" />
                </p>
              </div>
            </div>
          </div>
        ) : null}
      </section>
      {/* Certificates Carousel */}
      <section className="space-y-6">
        <div className="flex flex-col sm:flex-row gap-3 justify-between items-start sm:items-center">
          <div className="relative w-full max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              className="pl-10 font-mono bg-background/60 border-border focus:border-primary transition-colors rounded-none text-foreground placeholder:text-muted-foreground/60"
              placeholder="Query records..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              data-testid="input-search"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            <Badge
              variant={activeCategory === null ? "default" : "outline"}
              className="cursor-pointer font-mono rounded-none text-xs px-3 py-1"
              onClick={() => setActiveCategory(null)}
              data-testid="badge-all"
            >
              ALL
            </Badge>
            {stats?.byCategory.map((cat) => (
              <Badge
                key={cat.category}
                variant={activeCategory === cat.category ? "default" : "outline"}
                className="cursor-pointer font-mono rounded-none text-xs px-3 py-1"
                onClick={() => setActiveCategory(cat.category)}
                data-testid={`badge-${cat.category}`}
              >
                {cat.category} ({cat.count})
              </Badge>
            ))}
          </div>
        </div>

        {loadingCerts ? (
          <div className="flex gap-4 overflow-hidden">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-80 flex-none w-[80vw] max-w-sm bg-muted/40 rounded-none" />
            ))}
          </div>
        ) : filteredCerts?.length === 0 ? (
          <div className="py-24 text-center border border-dashed border-border/60 bg-background/50 backdrop-blur">
            <p className="font-mono text-muted-foreground tracking-widest text-sm">NO RECORDS FOUND MATCHING QUERY.</p>
          </div>
        ) : (
          <div className="relative text-[15px]">
            <Carousel
              setApi={setApi}
              opts={{ align: "start", loop: true, dragFree: false, duration: 40 }}
              className="w-full"
              onMouseEnter={() => setIsCarouselPaused(true)}
              onMouseLeave={() => setIsCarouselPaused(false)}
              onFocus={() => setIsCarouselPaused(true)}
              onBlur={() => setIsCarouselPaused(false)}
              onPointerDown={() => setIsCarouselPaused(true)}
              onPointerUp={() => setIsCarouselPaused(false)}
              data-testid="carousel-certificates"
            >
              <CarouselContent className="-ml-4">
                {filteredCerts?.map((cert, i) => {
                  const color = CARD_COLORS[i % CARD_COLORS.length];
                  const isImage = cert.thumbnailUrl || cert.fileUrl.match(/\.(jpeg|jpg|gif|png|webp)$/i);
                  return (
                    <CarouselItem
                      key={cert.id}
                      className="pl-4 basis-[85%] sm:basis-[55%] md:basis-[40%] lg:basis-[33%]"
                      data-testid={`carousel-item-${cert.id}`}
                    >
                      <Link href={`/certificates/${cert.id}`}>
                        <div
                          className="h-full flex flex-col overflow-hidden cursor-pointer select-none"
                          style={{
                            border: `1px solid ${color.border}55`,
                            background: "linear-gradient(145deg, hsl(220 25% 9% / 0.62), hsl(220 25% 5% / 0.42))",
                            backdropFilter: "blur(14px)",
                            WebkitBackdropFilter: "blur(14px)",
                            transition: "box-shadow 0.45s cubic-bezier(0.22, 1, 0.36, 1), transform 0.45s cubic-bezier(0.22, 1, 0.36, 1)",
                            willChange: "transform",
                          }}
                          onMouseEnter={(e) => {
                            (e.currentTarget as HTMLDivElement).style.boxShadow = `0 0 20px ${color.glow}, 0 0 40px ${color.glow}`;
                            (e.currentTarget as HTMLDivElement).style.transform = "translateY(-4px)";
                          }}
                          onMouseLeave={(e) => {
                            (e.currentTarget as HTMLDivElement).style.boxShadow = "none";
                            (e.currentTarget as HTMLDivElement).style.transform = "translateY(0)";
                          }}
                        >
                          <div
                            className="h-[3px] w-full flex-none"
                            style={{ background: `linear-gradient(90deg, transparent, ${color.border}, transparent)` }}
                          />
                          <div
                            className="aspect-[4/3] flex-none relative overflow-hidden flex items-center justify-center"
                            style={{
                              background: "hsl(220 25% 5% / 0.48)",
                              backdropFilter: "blur(8px)",
                              WebkitBackdropFilter: "blur(8px)",
                            }}
                          >
                            {isImage ? (
                              <img
                                src={cert.thumbnailUrl || cert.fileUrl}
                                alt={cert.title}
                                className="object-contain w-full h-full p-3 opacity-90 hover:opacity-100 transition-opacity"
                                draggable={false}
                              />
                            ) : (
                              <div className="flex flex-col items-center gap-3" style={{ color: color.border }}>
                                <FileText className="w-12 h-12 opacity-70" />
                                <span className="font-mono text-xs opacity-60 tracking-widest">PDF_DOCUMENT</span>
                              </div>
                            )}
                            <div
                              className="absolute top-0 right-0 w-8 h-8"
                              style={{ background: `linear-gradient(225deg, ${color.border}40, transparent 60%)` }}
                            />
                          </div>
                          <div className="p-4 flex flex-col gap-2 flex-1">
                            <h3 className="font-semibold text-foreground text-base leading-snug line-clamp-2">
                              {cert.title}
                            </h3>
                            <p className="font-mono text-xs line-clamp-1" style={{ color: color.border + "cc" }}>
                              ISS: {cert.issuer}
                            </p>
                            <div className="mt-auto flex items-center justify-between pt-2">
                              <span className="flex items-center gap-1 font-mono text-xs text-muted-foreground">
                                <Clock className="w-3 h-3" />
                                {cert.issuedDate
                                  ? new Date(cert.issuedDate).getFullYear()
                                  : new Date(cert.createdAt).getFullYear()}
                              </span>
                              {cert.category && (
                                <span
                                  className="font-mono text-[10px] px-2 py-0.5 border tracking-wider"
                                  style={{ borderColor: color.border + "66", color: color.border }}
                                >
                                  {cert.category.toUpperCase()}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </Link>
                    </CarouselItem>
                  );
                })}
              </CarouselContent>
            </Carousel>

            <div className="flex items-center justify-between mt-5">
              <div className="flex gap-2 items-center">
                {filteredCerts?.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => api?.scrollTo(i)}
                    className="transition-all duration-300 rounded-none focus:outline-none"
                    style={{
                      width: i === current ? "20px" : "6px",
                      height: "4px",
                      background: i === current ? "hsl(var(--primary))" : "hsl(var(--border))",
                      opacity: i === current ? 1 : 0.5,
                    }}
                    data-testid={`dot-${i}`}
                    aria-label={`Slide ${i + 1}`}
                  />
                ))}
              </div>
              <div className="flex gap-2">
                <button
                  onClick={scrollPrev}
                  className="w-10 h-10 border border-border/60 flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary/60 transition-all active:scale-95"
                  data-testid="button-prev"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  onClick={scrollNext}
                  className="w-10 h-10 border border-border/60 flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary/60 transition-all active:scale-95"
                  data-testid="button-next"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        )}
      </section>
      {/* Terminal Widget */}
      <TerminalWidget />
      {/* Contact / Profile Section */}
      <ContactSection />
    </div>
  );
}
