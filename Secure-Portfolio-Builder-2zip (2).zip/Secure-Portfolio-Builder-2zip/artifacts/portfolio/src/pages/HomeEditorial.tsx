import { useCallback, useEffect, useState } from "react";
import { Link } from "wouter";
import {
  ArrowDownRight,
  ArrowUpRight,
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  FileText,
  Layers3,
  Link2,
  Mail,
  Phone,
  Search,
  Send,
} from "lucide-react";
import { useCertificatesData, useCertificateStatsData } from "@/hooks/use-certificates-data";
import { useSettings } from "@/hooks/use-settings";
import { apiFetch } from "@/lib/api";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Carousel, CarouselContent, CarouselItem, type CarouselApi } from "@/components/ui/carousel";
import { TerminalWidget } from "@/components/layout/Terminal";
import { SecurityLabHomeSection } from "@/components/security-lab/SecurityLabHomeSection";
import { QAHomeSection } from "@/components/qa-lab/QAHomeSection";
import { HackTheSystemHomeSection } from "@/components/hack-the-system/HackTheSystemHomeSection";
import { LogicBreachPreview } from "@/components/logic-breach/LogicBreachPreview";

const accents = ["#c2d62e", "#e8785e", "#8292cc", "#d4a755", "#89aaa0", "#c87e94"];

function TypedIntro({ text }: { text: string }) {
  const [displayed, setDisplayed] = useState("");
  useEffect(() => {
    if (displayed.length >= text.length) return;
    const timer = window.setTimeout(() => setDisplayed(text.slice(0, displayed.length + 1)), 42);
    return () => window.clearTimeout(timer);
  }, [displayed, text]);

  return (
    <span className="font-mono text-xs text-muted-foreground">
      {displayed}<span className="ml-1 text-primary animate-pulse">▌</span>
    </span>
  );
}

function ContactStrip() {
  const { data: settings, isLoading } = useSettings();
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "", website: "" });
  const [state, setState] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [error, setError] = useState("");
  if (isLoading) return <Skeleton className="h-28 w-full rounded-3xl" />;
  if (!settings) return null;
  const socialLinks = [
    ["GitHub", settings.githubUrl],
    ["LinkedIn", settings.linkedinUrl],
    ["Telegram", settings.telegramUrl],
  ].filter(([, href]) => href);
  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setState("sending");
    setError("");
    try {
      await apiFetch("/api/contact", { method: "POST", body: JSON.stringify(form) });
      setForm({ name: "", email: "", subject: "", message: "", website: "" });
      setState("sent");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to send your message.");
      setState("error");
    }
  };

  return (
    <section id="contact" className="soft-card rounded-[2rem] p-6 sm:p-8 reveal reveal-delay-2" data-testid="section-contact">
      <div className="grid gap-8 lg:grid-cols-[.75fr_1.25fr]">
        <div>
          <p className="editorial-kicker text-primary">Open channel</p>
          <h2 className="editorial-display mt-2 text-4xl leading-none sm:text-5xl">{settings.fullName || ""}</h2>
          <p className="mt-4 max-w-lg text-sm leading-7 text-muted-foreground">{settings.contactText || settings.shortBio || ""}</p>
          <div className="mt-6 flex flex-wrap gap-2">
            {settings.email && <a href={`mailto:${settings.email}`} className="inline-flex items-center gap-2 rounded-full bg-foreground px-4 py-2.5 text-xs font-semibold text-background"><Mail className="h-3.5 w-3.5" /> Email</a>}
            {settings.phone && <a href={`tel:${settings.phone}`} className="inline-flex items-center gap-2 rounded-full border border-border px-4 py-2.5 text-xs font-semibold hover:border-primary"><Phone className="h-3.5 w-3.5" /> Call</a>}
            {socialLinks.map(([label, href]) => <a key={label} href={href!} target="_blank" rel="noopener noreferrer" className="rounded-full border border-border px-4 py-2.5 text-xs font-semibold hover:border-primary">{label}</a>)}
          </div>
        </div>
        <form onSubmit={submit} className="grid gap-3 sm:grid-cols-2">
          <input tabIndex={-1} aria-hidden="true" className="hidden" value={form.website} onChange={(e) => setForm({ ...form, website: e.target.value })} />
          <Input required maxLength={80} placeholder="Your name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <Input required type="email" maxLength={160} placeholder="Email address" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          <Input required maxLength={160} placeholder="Subject" className="sm:col-span-2" value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} />
          <textarea required maxLength={4000} minLength={10} placeholder="Write your message..." className="min-h-32 rounded-2xl border border-border bg-background/60 px-4 py-3 text-sm outline-none transition focus:border-primary sm:col-span-2" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
          <div className="flex items-center justify-between gap-3 sm:col-span-2">
            <p className={`text-xs ${state === "error" ? "text-destructive" : "text-muted-foreground"}`}>{state === "sent" ? "Message received. Thank you." : state === "error" ? error : "Your message is private and goes directly to the inbox."}</p>
            <button disabled={state === "sending"} className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-semibold text-foreground disabled:opacity-60">{state === "sending" ? "Sending..." : "Send message"} <Send className="h-4 w-4" /></button>
          </div>
        </form>
      </div>
    </section>
  );
}

export default function HomeEditorial() {
  const { data: certs, isLoading: loadingCerts } = useCertificatesData();
  const { data: stats } = useCertificateStatsData();
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [api, setApi] = useState<CarouselApi>();
  const [current, setCurrent] = useState(0);
  const [paused, setPaused] = useState(false);

  const filteredCerts = certs?.filter((cert) => {
    const query = search.toLowerCase();
    return (
      (!query || cert.title.toLowerCase().includes(query) || cert.issuer.toLowerCase().includes(query)) &&
      (!activeCategory || cert.category === activeCategory)
    );
  });

  useEffect(() => {
    if (!api) return;
    const onSelect = () => setCurrent(api.selectedScrollSnap());
    onSelect();
    api.on("select", onSelect);
    return () => {
      api.off("select", onSelect);
    };
  }, [api]);

  useEffect(() => {
    if (!api || !filteredCerts?.length) return;
    api.scrollTo(0, true);
    setCurrent(0);
  }, [api, search, activeCategory, filteredCerts?.length]);

  useEffect(() => {
    if (!api || (filteredCerts?.length ?? 0) < 2 || paused) return;
    const timer = window.setInterval(() => {
      if (document.visibilityState === "visible") api.scrollNext();
    }, 5200);
    return () => window.clearInterval(timer);
  }, [api, filteredCerts?.length, paused]);

  const previous = useCallback(() => api?.scrollPrev(), [api]);
  const next = useCallback(() => api?.scrollNext(), [api]);

  return (
    <div className="mx-auto max-w-7xl px-4 pb-20 pt-8 sm:px-8 lg:px-12">
      <SecurityLabHomeSection />

      <div className="mt-20">
        <HackTheSystemHomeSection />
      </div>

      <div className="mt-20">
        <LogicBreachPreview />
      </div>

      <section id="archive" className="scroll-mt-24 space-y-8">
        <div className="flex flex-col gap-5 border-b border-border pb-6 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="editorial-kicker text-primary">Selected evidence</p>
            <h2 className="editorial-display mt-2 text-5xl leading-none sm:text-6xl">The archive</h2>
          </div>
          <div className="flex w-full flex-col gap-3 sm:flex-row md:w-auto">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input data-testid="input-search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search records" className="h-11 w-full rounded-full border-border bg-card pl-11 pr-5 text-sm focus-visible:ring-primary sm:w-56" />
            </div>
            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              <button data-testid="badge-all" onClick={() => setActiveCategory(null)} className={`whitespace-nowrap rounded-full px-4 py-2 text-xs font-semibold transition-colors focus-visible:ring-2 focus-visible:ring-primary ${!activeCategory ? "bg-foreground text-background" : "border border-border text-muted-foreground hover:border-primary hover:text-foreground"}`}>All work</button>
              {stats?.byCategory.map((cat) => (
                <button data-testid={`badge-${cat.category}`} key={cat.category} onClick={() => setActiveCategory(cat.category)} className={`whitespace-nowrap rounded-full px-4 py-2 text-xs font-semibold transition-colors focus-visible:ring-2 focus-visible:ring-primary ${activeCategory === cat.category ? "bg-foreground text-background" : "border border-border text-muted-foreground hover:border-primary hover:text-foreground"}`}>
                  {cat.category} · {cat.count}
                </button>
              ))}
            </div>
          </div>
        </div>

        {loadingCerts ? (
          <div className="grid gap-5 md:grid-cols-3">{[1, 2, 3].map((item) => <Skeleton key={item} className="h-[28rem] rounded-[2rem]" />)}</div>
        ) : filteredCerts?.length === 0 ? (
          <div className="soft-card rounded-[2rem] px-6 py-20 text-center"><Layers3 className="mx-auto h-8 w-8 text-muted-foreground" /><p className="mt-4 text-sm text-muted-foreground">No records match this view.</p></div>
        ) : (
          <div onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)} onFocus={() => setPaused(true)} onBlur={() => setPaused(false)}>
            <Carousel setApi={setApi} opts={{ align: "start", loop: true, duration: 40 }} className="w-full" data-testid="carousel-certificates">
              <CarouselContent className="-ml-5">
                {filteredCerts?.map((cert, index) => {
                  const accent = accents[index % accents.length];
                  const image = Boolean(cert.thumbnailUrl || /\.(jpeg|jpg|gif|png|webp)$/i.test(cert.fileUrl));
                  const year = cert.issuedDate ? new Date(cert.issuedDate).getFullYear() : new Date(cert.createdAt).getFullYear();
                  return (
                    <CarouselItem key={cert.id} className="basis-[88%] pl-5 sm:basis-[58%] lg:basis-[34%]" data-testid={`carousel-item-${cert.id}`}>
                      <Link href={`/certificates/${cert.id}`} className="group block h-full focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-4">
                        <article className="soft-card flex h-full min-h-[28rem] flex-col overflow-hidden rounded-[2rem] transition-transform duration-500 group-hover:-translate-y-2">
                          <div className="relative flex aspect-[1.08] items-center justify-center overflow-hidden" style={{ backgroundColor: `${accent}2b` }}>
                            <div className="absolute left-5 top-5 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.15em] text-foreground/55"><span className="h-2 w-2 rounded-full" style={{ backgroundColor: accent }} /> Record {String(index + 1).padStart(2, "0")}</div>
                            {image ? <img src={cert.thumbnailUrl || cert.fileUrl} alt={cert.title} className="h-full w-full object-contain p-7 transition-transform duration-700 group-hover:scale-[1.04]" draggable={false} /> : <div className="flex flex-col items-center gap-4"><FileText className="h-16 w-16" strokeWidth={1} style={{ color: accent }} /><span className="editorial-kicker text-muted-foreground">Document preview</span></div>}
                            <span className="absolute bottom-5 right-5 flex h-11 w-11 items-center justify-center rounded-full bg-card text-foreground shadow-sm transition-colors group-hover:bg-foreground group-hover:text-background"><ArrowUpRight className="h-4 w-4" /></span>
                          </div>
                          <div className="flex flex-1 flex-col p-6">
                            <div className="mb-4 flex items-center justify-between gap-3"><span className="editorial-kicker text-muted-foreground">{cert.category || "Certificate"}</span><span className="font-mono text-[11px] text-muted-foreground">{year}</span></div>
                            <h3 className="editorial-display text-3xl leading-[.95] transition-colors group-hover:text-primary">{cert.title}</h3>
                            <p className="mt-3 line-clamp-2 text-sm leading-6 text-muted-foreground">{cert.issuer}</p>
                            <div className="mt-auto flex items-center gap-2 pt-6 font-mono text-[10px] uppercase tracking-[.14em] text-muted-foreground"><CalendarDays className="h-3.5 w-3.5" /> Verified entry <span className="ml-auto h-px w-8 bg-border" /></div>
                          </div>
                        </article>
                      </Link>
                    </CarouselItem>
                  );
                })}
              </CarouselContent>
            </Carousel>
            <div className="mt-6 flex items-center justify-between">
              <div className="flex gap-2">
                {filteredCerts?.map((cert, index) => <button key={cert.id} data-testid={`dot-${index}`} onClick={() => api?.scrollTo(index)} aria-label={`Go to certificate ${index + 1}`} className={`h-1.5 rounded-full transition-all focus-visible:ring-2 focus-visible:ring-primary ${index === current ? "w-8 bg-foreground" : "w-2 bg-border"}`} />)}
              </div>
              <div className="flex gap-2">
                <button data-testid="button-prev" onClick={previous} aria-label="Previous certificates" className="flex h-11 w-11 items-center justify-center rounded-full border border-border transition-colors hover:border-primary hover:text-primary focus-visible:ring-2 focus-visible:ring-primary"><ChevronLeft className="h-4 w-4" /></button>
                <button data-testid="button-next" onClick={next} aria-label="Next certificates" className="flex h-11 w-11 items-center justify-center rounded-full border border-border transition-colors hover:border-primary hover:text-primary focus-visible:ring-2 focus-visible:ring-primary"><ChevronRight className="h-4 w-4" /></button>
              </div>
            </div>
          </div>
        )}
      </section>

      <section className="mt-20 grid gap-8 lg:grid-cols-[.7fr_1.3fr] lg:items-end">
        <div className="reveal">
          <p className="editorial-kicker text-primary">A working note</p>
          <h2 className="editorial-display mt-3 text-5xl leading-[.92] sm:text-6xl">Curiosity is a security tool.</h2>
          <p className="mt-5 max-w-sm text-sm leading-7 text-muted-foreground">Use the shell to surface the small details that do not fit on a certificate.</p>
          <a href="#terminal" className="mt-7 inline-flex items-center gap-2 text-sm font-semibold transition-colors hover:text-primary focus-visible:ring-2 focus-visible:ring-primary">Open the terminal <ArrowDownRight className="h-4 w-4" /></a>
        </div>
        <div id="terminal" className="reveal reveal-delay-1"><TerminalWidget /></div>
      </section>

      <div className="mt-20">
        <QAHomeSection />
      </div>

      <div className="mt-20"><ContactStrip /></div>
    </div>
  );
}