import { useEffect, useMemo, useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, ArrowRight, Check, LockKeyhole, RotateCcw, ShieldCheck } from "lucide-react";
import { DifficultyPicker, EvidenceCard, FeedbackNotice, MissionRail, TerminalPanel } from "@/components/hack-the-system/GamePanels";
import { difficultySettings, missions, type Difficulty } from "@/components/hack-the-system/mission-data";
import { readProgress, writeProgress, type SavedProgress } from "@/components/hack-the-system/progress-storage";

type Feedback = { missionId: number; kind: "success" | "error" | "info"; message: string } | null;

function PortfolioLink({ className = "" }: { className?: string }) {
  return <Link href="/" data-testid="link-back-portfolio" className={`inline-flex min-h-10 items-center gap-2 rounded-full border border-border px-4 py-2 text-xs font-semibold transition-colors hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary ${className}`}>
    <ArrowLeft size={14} aria-hidden="true" /> Back to portfolio
  </Link>;
}

export default function HackTheSystemPage() {
  const [progress, setProgress] = useState<SavedProgress>(() => readProgress());
  const selectedMission = progress.currentMission;
  const [selectedAnswer, setSelectedAnswer] = useState("");
  const [feedback, setFeedback] = useState<Feedback>(null);
  const [storageUnavailable, setStorageUnavailable] = useState(false);
  const currentMission = missions[selectedMission - 1];
  const settings = difficultySettings[progress.difficulty];
  const hintUsed = progress.hintsUsed.includes(selectedMission);
  const unlocked = Math.min(6, progress.unlocked);
  const missionDone = progress.runCompleted.includes(selectedMission);
  const currentFeedback = feedback?.missionId === selectedMission ? feedback : null;
  const firstIncomplete = missions.find((mission) => !progress.runCompleted.includes(mission.id))?.id ?? 6;

  useEffect(() => {
    const saved = writeProgress(progress);
    setStorageUnavailable((wasUnavailable) => wasUnavailable === !saved ? wasUnavailable : !saved);
  }, [progress]);

  const statusSummary = useMemo(
    () => `Mission ${selectedMission} of 5 · Difficulty ${progress.difficulty} · Score ${progress.score} · Hint ${hintUsed ? "used" : "available"}`,
    [selectedMission, progress.difficulty, progress.score, hintUsed],
  );

  const chooseDifficulty = (difficulty: Difficulty) => setProgress((current) => ({ ...current, difficulty }));
  const startRun = () => {
    setFeedback(null);
    setSelectedAnswer("");
    setProgress((current) => ({
      ...current,
      score: 0,
      currentMission: 1,
      runCompleted: [],
      hintsUsed: [],
      started: true,
      finished: false,
    }));
  };

  const useHint = () => {
    if (missionDone) {
      setFeedback({ missionId: selectedMission, kind: "info", message: "This mission is already complete for this run; its score is fixed." });
      return;
    }
    setProgress((current) => current.hintsUsed.includes(selectedMission)
      ? current
      : { ...current, hintsUsed: [...current.hintsUsed, selectedMission] });
    setFeedback({ missionId: selectedMission, kind: "info", message: `Hint: ${currentMission.hint}` });
  };

  const submitAnswer = (choiceId: string) => {
    if (missionDone) return;
    if (choiceId !== currentMission.answer) {
      setFeedback({ missionId: selectedMission, kind: "error", message: currentMission.feedback });
      return;
    }
    const award = Math.max(0, settings.base - (hintUsed ? settings.hintCost : 0));
    setProgress((current) => {
      if (current.runCompleted.includes(selectedMission)) return current;
      const runCompleted = [...current.runCompleted, selectedMission].sort((a, b) => a - b);
      const completed = [...new Set([...current.completed, selectedMission])].sort((a, b) => a - b);
      const score = current.score + award;
      const finished = runCompleted.length === missions.length;
      return {
        ...current,
        completed,
        runCompleted,
        unlocked: Math.min(6, completed.length + 1),
        score,
        bestScore: finished ? Math.max(current.bestScore, score) : current.bestScore,
        finished,
      };
    });
    setSelectedAnswer("");
    setFeedback({
      missionId: selectedMission,
      kind: "success",
      message: `${currentMission.success} ${award} points ${hintUsed ? "awarded after the hint deduction" : "awarded"}.`,
    });
  };

  const selectMission = (missionId: number) => {
    if (missionId > unlocked || missionId < 1 || missionId > 5) return;
    setSelectedAnswer("");
    setProgress((current) => ({ ...current, currentMission: missionId }));
    setFeedback(null);
  };

  const continueSequence = () => {
    if (firstIncomplete > 5) return;
    selectMission(firstIncomplete);
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    document.getElementById("mission-workspace")?.scrollIntoView({ behavior: reducedMotion ? "auto" : "smooth", block: "start" });
  };

  if (!progress.started && !progress.finished) {
    return <div className="mx-auto w-full max-w-7xl px-4 pb-16 pt-8 sm:px-8 sm:pt-12 lg:px-12">
      <div className="mb-7"><PortfolioLink /></div>
      <section className="relative overflow-hidden rounded-[1.75rem] bg-foreground px-6 py-9 text-background sm:px-10 sm:py-12 lg:px-14 lg:py-14" data-testid="game-start-screen">
        <div className="absolute -right-16 -top-20 h-72 w-72 rounded-full border border-background/10 sm:h-96 sm:w-96" aria-hidden="true" />
        <div className="absolute right-12 top-12 hidden h-24 w-24 rotate-12 border border-primary/50 lg:block" aria-hidden="true" />
        <div className="relative grid gap-9 lg:grid-cols-[1fr_330px] lg:items-end">
          <div className="max-w-3xl">
            <p className="editorial-kicker mb-4 text-primary">Browser-only security field exercise · 01—05</p>
            <h1 className="editorial-display text-6xl leading-[.91] sm:text-7xl lg:text-8xl">Hack the<br /><span className="italic text-primary">System.</span></h1>
            <p className="mt-6 max-w-xl text-sm leading-7 text-background/75 sm:text-base">Five evidence-led missions. Read the record, apply the written control, and make a defensible call. This is a fictional, safe local simulation: it never connects to real systems.</p>
            <DifficultyPicker value={progress.difficulty} onChange={chooseDifficulty} />
            <button type="button" onClick={startRun} className="mt-7 inline-flex min-h-12 items-center gap-3 rounded-full bg-primary px-6 py-3 text-sm font-bold text-foreground transition-colors hover:bg-primary/85 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-background focus-visible:ring-offset-2 focus-visible:ring-offset-foreground" data-testid="button-play">
              Play <ArrowRight size={16} aria-hidden="true" />
            </button>
          </div>
          <aside className="rounded-2xl border border-background/15 bg-background/[.06] p-5 backdrop-blur-sm">
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-foreground"><ShieldCheck size={19} aria-hidden="true" /></span>
              <div><p className="text-sm font-bold">Scoring, in the open</p><p className="text-xs text-background/60">One award per mission.</p></div>
            </div>
            <div className="mt-5 space-y-3 border-t border-background/15 pt-4 text-xs">
              {(["Explorer", "Analyst", "Specialist"] as Difficulty[]).map((level) => <div key={level} className="flex justify-between gap-3"><span className="text-background/75">{level}</span><span className="font-mono">{difficultySettings[level].base} pts · hint −{difficultySettings[level].hintCost}</span></div>)}
              <p className="pt-1 leading-5 text-background/55">A mission hint is available once. Its deduction cannot reduce that mission's award below zero.</p>
            </div>
             <p className="mt-5 border-t border-background/15 pt-4 text-xs leading-5 text-background/65" data-testid="text-best-score">Personal best on this device: {progress.bestScore} points</p>
             <p className="mt-2 text-xs leading-5 text-background/65" data-testid="text-lifetime-completed">Missions completed on this device: {progress.completed.length} / 5</p>
          </aside>
        </div>
      </section>
      <div className="mt-5 flex flex-col gap-3 rounded-2xl border border-border bg-card/70 px-5 py-4 sm:flex-row sm:items-center">
        <LockKeyhole size={16} className="shrink-0 text-primary" aria-hidden="true" />
        <p className="text-xs leading-5 text-muted-foreground"><strong className="text-foreground">Safety boundary:</strong> The console is a fixed local text simulation. No shell, commands, scanning, credentials, network requests, or external systems are involved.</p>
      </div>
    </div>;
  }

  if (progress.finished) {
    return <div className="mx-auto w-full max-w-7xl px-4 pb-16 pt-8 sm:px-8 sm:pt-12 lg:px-12">
      <div className="mb-7"><PortfolioLink /></div>
      <section className="mx-auto max-w-4xl rounded-[1.75rem] bg-foreground px-6 py-10 text-background sm:px-10 sm:py-14" data-testid="game-results">
        <p className="editorial-kicker text-primary">Sequence complete · local result</p>
        <h1 className="editorial-display mt-3 text-6xl leading-none sm:text-7xl">Good work.<br /><span className="italic text-primary">Clear evidence.</span></h1>
        {currentFeedback && <div className="mt-6"><FeedbackNotice kind="success">{currentFeedback.message}</FeedbackNotice></div>}
        <div className="mt-9 grid gap-3 sm:grid-cols-3">
          <div className="rounded-2xl border border-background/15 bg-background/[.06] p-5"><p className="editorial-kicker text-background/50">Final score</p><p className="mt-2 font-mono text-4xl" data-testid="result-score">{progress.score}<span className="text-base text-background/50"> / {settings.base * 5}</span></p></div>
           <div className="rounded-2xl border border-background/15 bg-background/[.06] p-5"><p className="editorial-kicker text-background/50">Missions complete</p><p className="mt-2 font-mono text-4xl" data-testid="result-missions">{progress.runCompleted.length}<span className="text-base text-background/50"> / 5</span></p></div>
          <div className="rounded-2xl border border-background/15 bg-background/[.06] p-5"><p className="editorial-kicker text-background/50">Personal best</p><p className="mt-2 font-mono text-4xl" data-testid="result-best-score">{progress.bestScore}</p></div>
        </div>
        <p className="mt-5 text-sm text-background/65">Difficulty: {progress.difficulty} · Hints used: {progress.hintsUsed.length}</p>
        <div className="mt-8 flex flex-wrap gap-3">
          <button type="button" onClick={startRun} className="inline-flex min-h-11 items-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-bold text-foreground transition-colors hover:bg-primary/85 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-background" data-testid="button-replay"><RotateCcw size={15} aria-hidden="true" /> Replay</button>
          <PortfolioLink className="border-background/25 text-background hover:border-primary" />
        </div>
        {storageUnavailable && <p role="status" className="mt-6 text-xs text-background/65" data-testid="status-storage">Browser storage is unavailable. This result remains available in memory until you leave this page.</p>}
      </section>
    </div>;
  }

  return <div className="mx-auto w-full max-w-7xl px-4 pb-16 pt-8 sm:px-8 sm:pt-12 lg:px-12">
    <div className="mb-7 flex flex-wrap items-center justify-between gap-3">
      <PortfolioLink />
      <p className="editorial-kicker text-muted-foreground">Safe local simulation · no external systems</p>
    </div>
    <section className="relative overflow-hidden rounded-[1.75rem] bg-foreground px-6 py-8 text-background sm:px-10 sm:py-10" data-testid="game-header">
      <div className="relative grid gap-6 md:grid-cols-[1fr_auto] md:items-end">
        <div><p className="editorial-kicker text-primary">Security field exercise / 01—05</p><h1 className="editorial-display mt-2 text-5xl leading-none sm:text-6xl">Hack the <span className="italic text-primary">System.</span></h1><p className="mt-3 max-w-2xl text-sm leading-6 text-background/65">Read what is shown. Apply the policy. Record the answer you can support.</p></div>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {[["Mission", `${selectedMission} / 5`], ["Difficulty", progress.difficulty], ["Score", `${progress.score}`], ["Hint", hintUsed ? "Used" : "Ready"]].map(([label, value]) => <div key={label} className="rounded-xl border border-background/15 bg-background/[.06] px-3 py-2.5"><p className="editorial-kicker text-[9px] text-background/45">{label}</p><p className="mt-1 text-sm font-semibold" data-testid={`status-${label.toLowerCase()}`}>{value}</p></div>)}
        </div>
      </div>
    </section>
    <div className="mt-5">
      <MissionRail missions={missions} completed={progress.runCompleted} unlocked={unlocked} current={selectedMission} onSelect={selectMission} />
    </div>
    <div className="mt-6 grid items-start gap-6 lg:grid-cols-[minmax(0,1.35fr)_minmax(18rem,.65fr)]">
      <section id="mission-workspace" className="scroll-mt-24 space-y-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div><p className="editorial-kicker text-primary">Mission 0{currentMission.id} · {currentMission.category}</p><h2 className="editorial-display mt-1 text-4xl leading-none sm:text-5xl">{currentMission.title}</h2></div>
          <span className="rounded-full border border-border px-3 py-1.5 font-mono text-[10px] text-muted-foreground">{missionDone ? "Previously completed · replay" : `Award up to ${settings.base} points`}</span>
        </div>
        <p className="max-w-3xl text-sm leading-7 text-muted-foreground">{currentMission.briefing}</p>
        <EvidenceCard mission={currentMission} />
        <section className="rounded-2xl border border-border bg-card/70 p-5 sm:p-6" aria-labelledby="question-heading">
          <h3 id="question-heading" className="text-base font-bold leading-6">{currentMission.question}</h3>
          <div className="mt-4 grid gap-2">
            {currentMission.choices.map((choice, index) => <button key={choice.id} type="button" onClick={() => {
              setSelectedAnswer(choice.id);
              setFeedback(null);
            }} aria-pressed={selectedAnswer === choice.id} disabled={missionDone} aria-label={`Answer ${String.fromCharCode(65 + index)}: ${choice.label}`} className={`group flex min-h-12 items-start gap-3 rounded-xl border px-4 py-3 text-left transition-colors hover:border-primary hover:bg-primary/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary disabled:cursor-not-allowed disabled:opacity-65 ${selectedAnswer === choice.id ? "border-primary bg-primary/10" : "border-border bg-background/70"}`} data-testid={`answer-${choice.id}`}>
              <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-border font-mono text-[10px] text-muted-foreground group-hover:border-primary group-hover:text-foreground">{String.fromCharCode(65 + index)}</span>
              <span className="text-sm leading-6">{choice.label}</span>
            </button>)}
          </div>
          <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
            <button type="button" onClick={useHint} disabled={hintUsed || missionDone} className="inline-flex min-h-10 items-center gap-2 rounded-full border border-border px-4 py-2 text-xs font-semibold transition-colors hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary disabled:cursor-not-allowed disabled:opacity-55" data-testid="button-hint">
              {hintUsed ? <Check size={14} aria-hidden="true" /> : <span className="font-mono">?</span>}{hintUsed ? "Hint used" : `Reveal hint · −${settings.hintCost} points`}
            </button>
            <span className="text-xs text-muted-foreground" data-testid="text-award-preview">Correct answer: +{Math.max(0, settings.base - (hintUsed ? settings.hintCost : 0))} points</span>
          </div>
          <button type="button" onClick={() => submitAnswer(selectedAnswer)} disabled={!selectedAnswer || missionDone} className="mt-4 inline-flex min-h-11 items-center gap-2 rounded-full bg-foreground px-5 py-3 text-sm font-semibold text-background transition-colors hover:bg-foreground/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary disabled:cursor-not-allowed disabled:opacity-45" data-testid="button-submit-answer">
            Submit answer <ArrowRight size={15} aria-hidden="true" />
          </button>
        </section>
        {currentFeedback && <FeedbackNotice kind={currentFeedback.kind}>{currentFeedback.message}</FeedbackNotice>}
        {missionDone && !progress.finished && firstIncomplete <= 5 && <button type="button" onClick={continueSequence} className="inline-flex min-h-11 items-center gap-2 rounded-full bg-foreground px-5 py-3 text-sm font-semibold text-background transition-colors hover:bg-foreground/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary" data-testid="button-next-mission">Continue to mission 0{firstIncomplete} <ArrowRight size={15} aria-hidden="true" /></button>}
      </section>
      <aside className="space-y-5 lg:sticky lg:top-24">
        <TerminalPanel mission={currentMission} status={statusSummary} hintUsed={hintUsed} onHint={useHint} />
        <div className="rounded-2xl border border-border bg-card/65 p-5">
          <p className="editorial-kicker text-muted-foreground">Session ledger</p>
          <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-3 text-xs">
            <div><dt className="text-muted-foreground">Award / mission</dt><dd className="mt-1 font-mono font-medium">{settings.base} pts</dd></div>
            <div><dt className="text-muted-foreground">Hint deduction</dt><dd className="mt-1 font-mono font-medium">−{settings.hintCost} pts</dd></div>
            <div><dt className="text-muted-foreground">Completed this run</dt><dd className="mt-1 font-mono font-medium" data-testid="text-progress-completed">{progress.runCompleted.length} / 5</dd></div>
            <div><dt className="text-muted-foreground">Completed on this device</dt><dd className="mt-1 font-mono font-medium" data-testid="text-progress-lifetime">{progress.completed.length} / 5</dd></div>
            <div><dt className="text-muted-foreground">Unlocked through</dt><dd className="mt-1 font-mono font-medium" data-testid="text-progress-unlocked">{Math.min(unlocked, 5)} / 5</dd></div>
          </dl>
        </div>
        {storageUnavailable && <p role="status" className="rounded-xl border border-accent/40 bg-accent/10 px-4 py-3 text-xs leading-5" data-testid="status-storage">Browser storage is unavailable. Progress will work in memory for this visit only.</p>}
      </aside>
    </div>
  </div>;
}
