import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { ShieldCheck } from "lucide-react";

export default function AdminLogin() {
  const [, setLocation] = useLocation();
  const { login, isAdmin } = useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  useEffect(() => { if (isAdmin) setLocation("/admin/dashboard"); }, [isAdmin, setLocation]);
  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    try {
      await login({ username, password });
      setLocation("/admin/dashboard");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to sign in");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex min-h-[calc(100dvh-140px)] items-center justify-center px-6">
      <div className="soft-card w-full max-w-md rounded-[2rem] p-8 text-center">
        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-foreground text-primary"><ShieldCheck className="h-5 w-5" /></div>
        <p className="editorial-kicker mt-6 text-muted-foreground">Restricted workspace</p>
        <h1 className="editorial-display mt-3 text-5xl leading-none">Admin access</h1>
        <form onSubmit={submit} className="mt-8 space-y-4 text-left">
          <div><Label className="editorial-kicker text-muted-foreground">USERNAME</Label><Input value={username} onChange={(e) => setUsername(e.target.value)} className="mt-2 bg-background/70" autoComplete="username" required /></div>
          <div><Label className="editorial-kicker text-muted-foreground">PASSWORD</Label><Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="mt-2 bg-background/70" autoComplete="current-password" required /></div>
          {error && <p className="text-sm text-destructive">{error}</p>}
          <Button className="w-full rounded-full" disabled={submitting}>{submitting ? "CHECKING..." : "SIGN IN"}</Button>
        </form>
      </div>
    </div>
  );
}
