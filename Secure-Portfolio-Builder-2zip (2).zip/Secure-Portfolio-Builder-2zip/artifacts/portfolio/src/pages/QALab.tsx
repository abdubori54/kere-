import { useState } from "react";
import { ArrowDownRight, BookOpen, Bug, ClipboardCheck, FlaskConical, LayoutDashboard, RotateCcw, ShieldCheck } from "lucide-react";
import { QAOverview, QAPortfolio } from "@/components/qa-lab/QAOverview";
import { QABugReports } from "@/components/qa-lab/QABugReports";
import { QADemos } from "@/components/qa-lab/QADemos";
import { QATestRunner } from "@/components/qa-lab/QATestRunner";
import { QAButton, QAKicker } from "@/components/qa-lab/QASection";
import { modules, type ModuleKey } from "@/components/qa-lab/qa-data";
import { useQALab } from "@/components/qa-lab/use-qa-lab";

const tabs = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "scenarios", label: "Try scenarios", icon: FlaskConical },
  { id: "tests", label: "Test runner", icon: ClipboardCheck },
  { id: "bugs", label: "Bug reports", icon: Bug },
  { id: "methods", label: "QA methods", icon: BookOpen },
];

export function QALabPage() {
  const { state, storageMessage, setTestResult, saveTestNotes, saveBug, deleteBug, updatePreferences, reset } = useQALab();
  const [selectedModule, setSelectedModule] = useState<ModuleKey>("Authentication");
  const activeTab = tabs.some((tab) => tab.id === state.preferences.activeTab) ? state.preferences.activeTab : "overview";
  const navigate = (tab: string) => {
    updatePreferences({ activeTab: tab });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const openScenario = (module: ModuleKey) => {
    setSelectedModule(module);
    updatePreferences({ activeTab: "scenarios" });
    window.setTimeout(() => document.getElementById("qa-demos")?.scrollIntoView({ behavior: "smooth", block: "start" }), 40);
  };
  const clearProgress = () => {
    if (window.confirm("Reset all QA progress, local bug reports and reviewed materials in this browser? Sample portfolio materials remain available.")) reset();
  };
  const activeModuleCount = modules.length;
  return <div className="mx-auto w-full max-w-7xl px-4 pb-16 pt-8 sm:px-8 sm:pt-12 lg:px-12">
    <section className="relative overflow-hidden rounded-[1.75rem] bg-foreground px-6 py-8 text-background sm:px-10 sm:py-12 lg:px-14 lg:py-14">
      <div className="absolute -right-10 -top-12 h-56 w-56 rounded-full border border-background/10 sm:h-80 sm:w-80" aria-hidden="true" />
      <div className="absolute right-9 top-10 hidden h-24 w-24 rotate-12 border border-primary/60 sm:block" aria-hidden="true" />
      <div className="relative grid gap-8 lg:grid-cols-[1fr_310px] lg:items-end">
        <div className="max-w-3xl"><QAKicker>Browser-only practice environment</QAKicker><p className="editorial-kicker mb-4 text-primary">Quality assurance · field notes 01—05</p><h1 className="editorial-display max-w-3xl text-5xl leading-[.97] sm:text-6xl lg:text-7xl">QA Testing<br /><span className="italic text-primary">Lab</span></h1><p className="mt-5 max-w-xl text-sm leading-6 text-background/75 sm:text-base">Explore realistic interface scenarios, probe the edges, and record test craft clearly. No account, external services, or backend—just deliberate practice in your browser.</p>
           <div className="mt-6 flex flex-wrap gap-3"><QAButton onClick={() => navigate("scenarios")} className="bg-primary text-foreground hover:bg-primary/90" data-testid="hero-try-scenarios">Explore scenarios <ArrowDownRight size={15} /></QAButton><QAButton variant="line" onClick={() => navigate("tests")} className="!border-background/30 !bg-transparent !text-background hover:!border-primary hover:!bg-background/10">Open test runner</QAButton></div>
        </div>
        <aside className="rounded-2xl border border-background/15 bg-background/[.06] p-5 backdrop-blur-sm">
          <div className="flex items-center gap-3"><span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-foreground"><ShieldCheck size={19} /></span><div><p className="text-sm font-bold">Practice, not production</p><p className="text-xs text-background/60">All activity stays on this device.</p></div></div>
          <div className="mt-5 grid grid-cols-2 gap-3 border-t border-background/15 pt-4"><div><p className="font-mono text-2xl">{activeModuleCount}</p><p className="text-[10px] uppercase tracking-wider text-background/55">Interactive modules</p></div><div><p className="font-mono text-2xl">{state.preferences.completedChallenges.length}</p><p className="text-[10px] uppercase tracking-wider text-background/55">Notes reviewed</p></div></div>
        </aside>
      </div>
    </section>

    <div className="sticky top-[4.5rem] z-30 -mx-4 mt-5 border-b border-border/70 bg-background/95 px-4 py-2 backdrop-blur-xl sm:-mx-8 sm:px-8 lg:-mx-12 lg:px-12">
      <div className="flex items-center justify-between gap-3">
        <nav aria-label="QA Lab sections" className="flex min-w-0 flex-1 gap-1 overflow-x-auto py-1">
          {tabs.map(({ id, label, icon: Icon }) => <button key={id} data-testid={`qa-tab-${id}`} aria-current={activeTab === id ? "page" : undefined} onClick={() => navigate(id)} className={`flex shrink-0 items-center gap-2 rounded-full px-3 py-2 text-xs font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary sm:px-4 sm:text-sm ${activeTab === id ? "bg-foreground text-background" : "text-muted-foreground hover:bg-muted hover:text-foreground"}`}><Icon size={14} />{label}</button>)}
        </nav>
        <QAButton variant="quiet" className="hidden min-h-9 shrink-0 px-3 text-xs text-muted-foreground sm:inline-flex" onClick={clearProgress} data-testid="reset-progress"><RotateCcw size={13} /> Reset local data</QAButton>
        <button aria-label="Reset local QA data" className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-muted-foreground hover:bg-muted sm:hidden" onClick={clearProgress}><RotateCcw size={15} /></button>
      </div>
    </div>
    <p className="my-4 flex items-start gap-2 rounded-xl border border-border bg-card/70 px-4 py-3 text-xs leading-5 text-muted-foreground"><span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-primary" aria-hidden="true" />Your test progress, notes, bug reports and reading preferences are stored only in this browser using local storage. They are not synchronized or sent anywhere.{storageMessage && <strong role="alert" className="ml-1 text-destructive">{storageMessage}</strong>}</p>

    <div className="min-h-[50vh] pt-4">
      {activeTab === "overview" && <QAOverview state={state} onNavigate={navigate} />}
      {activeTab === "scenarios" && <QADemos initialModule={selectedModule} onSelected={setSelectedModule} />}
      {activeTab === "tests" && <div className="space-y-10"><QATestRunner state={state} setTestResult={setTestResult} saveTestNotes={saveTestNotes} onRunScenario={openScenario} /><section className="scroll-mt-28"><QADemos initialModule={selectedModule} onSelected={setSelectedModule} /></section></div>}
      {activeTab === "bugs" && <QABugReports state={state} saveBug={saveBug} deleteBug={deleteBug} />}
      {activeTab === "methods" && <QAPortfolio state={state} updatePreferences={updatePreferences} />}
    </div>
    <footer className="mt-12 flex flex-col justify-between gap-3 border-t border-border pt-5 text-xs text-muted-foreground sm:flex-row sm:items-center"><p className="editorial-kicker">Secure Portfolio Builder / QA practice lab</p><p>Local browser demo · no external systems connected</p></footer>
  </div>;
}

export default QALabPage;