import { useRoute, Link } from "wouter";
import { ArrowLeft, ArrowUpRight, Building2, CalendarDays, Download, FileText, ShieldCheck } from "lucide-react";
import { format } from "date-fns";
import { useCertificateData } from "@/hooks/use-certificates-data";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

export default function CertificateDetailEditorial() {
  const [, params] = useRoute("/certificates/:id");
  const id = parseInt(params?.id || "0");
  const { data: cert, isLoading } = useCertificateData(id);

  if (isLoading) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-8 lg:px-12">
        <Skeleton className="h-5 w-32 rounded-full" />
        <div className="mt-10 grid gap-10 lg:grid-cols-[1.4fr_.6fr]">
          <Skeleton className="aspect-[1.15] rounded-[2rem]" />
          <div className="space-y-5"><Skeleton className="h-16 w-4/5 rounded-2xl" /><Skeleton className="h-28 w-full rounded-2xl" /><Skeleton className="h-44 w-full rounded-2xl" /></div>
        </div>
      </div>
    );
  }

  if (!cert) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-28 text-center">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-accent/20 text-accent"><FileText className="h-7 w-7" /></div>
        <h1 className="editorial-display mt-6 text-5xl">This record is missing.</h1>
        <p className="mt-3 text-sm text-muted-foreground">The archive could not find certificate #{id}.</p>
        <Link href="/" className="mt-8 inline-flex items-center gap-2 rounded-full bg-foreground px-5 py-3 text-sm font-semibold text-background transition-transform hover:-translate-y-1 focus-visible:ring-2 focus-visible:ring-primary"><ArrowLeft className="h-4 w-4" /> Return to archive</Link>
      </div>
    );
  }

  const isPdf = cert.fileUrl.toLowerCase().endsWith(".pdf");
  const issued = cert.issuedDate ? format(new Date(cert.issuedDate), "MMMM d, yyyy") : "Date not specified";

  return (
    <div className="mx-auto max-w-7xl px-4 pb-20 pt-8 sm:px-8 lg:px-12">
      <Link href="/" className="editorial-kicker inline-flex items-center gap-2 text-muted-foreground transition-colors hover:text-foreground focus-visible:ring-2 focus-visible:ring-primary"><ArrowLeft className="h-3.5 w-3.5" /> Back to archive</Link>
      <div className="mt-10 grid gap-10 lg:grid-cols-[1.35fr_.65fr] lg:gap-16">
        <section className="reveal">
          <div className="relative overflow-hidden rounded-[2.5rem] bg-[#d8dfb4] p-3 shadow-[0_20px_60px_rgba(32,38,53,.12)]">
            <div className="absolute left-8 top-8 z-10 flex items-center gap-2 rounded-full bg-card/80 px-3 py-2 font-mono text-[10px] uppercase tracking-[.16em] text-foreground/70 backdrop-blur"><ShieldCheck className="h-3.5 w-3.5 text-primary" /> Verified artifact</div>
            <div className="flex min-h-[55vh] items-center justify-center overflow-hidden rounded-[2rem] bg-[#f3efdf]">
              {isPdf ? (
                <iframe src={`${cert.fileUrl}#toolbar=0`} className="h-[72vh] w-full border-none bg-card" title={cert.title} />
              ) : (
                <img src={cert.fileUrl} alt={cert.title} className="max-h-[72vh] w-full object-contain p-6 transition-transform duration-700 hover:scale-[1.015] sm:p-12" />
              )}
            </div>
          </div>
          <div className="mt-5 flex items-center justify-between px-2 font-mono text-[10px] uppercase tracking-[.16em] text-muted-foreground"><span>Archive / {String(cert.id).padStart(3, "0")}</span><span>{isPdf ? "PDF document" : "Image document"}</span></div>
        </section>

        <aside className="flex flex-col reveal reveal-delay-1">
          <div className="flex items-center gap-3"><span className="h-2.5 w-2.5 rounded-full bg-primary" /><span className="editorial-kicker text-muted-foreground">{cert.category || "Security achievement"}</span></div>
          <h1 className="editorial-display mt-5 text-6xl leading-[.88] tracking-[-.04em] sm:text-7xl">{cert.title}</h1>
          <p className="mt-6 max-w-md text-base leading-7 text-muted-foreground">{cert.description || "A documented milestone in the ongoing practice of cybersecurity."}</p>

          <dl className="mt-10 divide-y divide-border border-y border-border">
            <div className="flex gap-4 py-5"><Building2 className="mt-1 h-4 w-4 shrink-0 text-primary" /><div><dt className="editorial-kicker text-muted-foreground">Issuing authority</dt><dd className="mt-2 text-sm font-semibold">{cert.issuer}</dd></div></div>
            <div className="flex gap-4 py-5"><CalendarDays className="mt-1 h-4 w-4 shrink-0 text-primary" /><div><dt className="editorial-kicker text-muted-foreground">Issued</dt><dd className="mt-2 text-sm font-semibold">{issued}</dd></div></div>
            <div className="flex gap-4 py-5"><FileText className="mt-1 h-4 w-4 shrink-0 text-primary" /><div><dt className="editorial-kicker text-muted-foreground">Archive reference</dt><dd className="mt-2 font-mono text-sm font-semibold">SEC-{String(cert.id).padStart(4, "0")}</dd></div></div>
          </dl>

          <a href={cert.fileUrl} target="_blank" rel="noopener noreferrer" className="mt-auto pt-10">
            <Button data-testid="button-access-original" className="group h-14 w-full rounded-full bg-foreground text-background hover:bg-primary hover:text-foreground focus-visible:ring-2 focus-visible:ring-primary" size="lg">
              {isPdf ? <Download className="h-4 w-4" /> : <ArrowUpRight className="h-4 w-4" />}
              Open original file
            </Button>
          </a>
        </aside>
      </div>
    </div>
  );
}