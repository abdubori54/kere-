import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { Link } from "wouter";
import { ArrowLeft, ArrowRight, Check, ChevronLeft, CircleHelp, LockKeyhole, RotateCcw, ShieldCheck } from "lucide-react";
import { challenges, storyMissions, validateAnswer, type Difficulty, type Puzzle } from "@/components/logic-breach/data";
import {
  emptyLogicBreachProgress,
  readLogicBreachProgress,
  resetLogicBreachProgress,
  writeLogicBreachProgress,
  type LogicBreachProgress,
} from "@/components/logic-breach/storage";

type View = "home" | "story-select" | "challenge-list" | "story-play" | "challenge-play" | "results";
type Feedback = { kind: "success" | "error" | "info"; message: string; explanation?: string } | null;
const scoreAfterHint = (puzzle: Puzzle, used: boolean) => Math.max(0, puzzle.baseScore - (used ? 20 : 0));

function SectionLabel({ children }: { children: ReactNode }) {
  return <p className="editorial-kicker text-primary">{children}</p>;
}

function BackPortfolio() {
  return <Link href="/" data-testid="link-back-portfolio" className="inline-flex min-h-10 items-center gap-2 rounded-full border border-border px-4 py-2 text-xs font-semibold transition-colors hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary">
    <ArrowLeft size={14} aria-hidden="true" /> Back to portfolio
  </Link>;
}

function PuzzleEvidence({ puzzle }: { puzzle: Puzzle }) {
  return <section className="rounded-2xl border border-border bg-card p-5 sm:p-6" aria-labelledby="evidence-title">
    <div className="flex flex-wrap items-center justify-between gap-3">
      <h3 id="evidence-title" className="editorial-kicker text-muted-foreground">Evidence on record</h3>
      <span className="font-mono text-[10px] uppercase tracking-[.12em] text-muted-foreground">{puzzle.category}</span>
    </div>
    <ul className="mt-4 space-y-3">
      {puzzle.evidence.map((item, index) => <li key={`${puzzle.id}-evidence-${index}`} className="grid gap-1 border-t border-border/70 pt-3 first:border-0 first:pt-0 sm:grid-cols-[2rem_1fr] sm:gap-3">
        <span className="font-mono text-[10px] text-primary">0{index + 1}</span><span className="text-sm leading-6">{item}</span>
      </li>)}
    </ul>
    {puzzle.truthTable && <div className="mt-5 overflow-x-auto rounded-xl border border-border/70 bg-background/60 p-4">
      <table className="w-full text-left text-xs" data-testid="table-truth-story-04">
        <caption className="mb-3 text-left font-semibold text-muted-foreground">XOR truth table — output is ON when the inputs differ</caption>
        <thead><tr className="border-b border-border text-muted-foreground"><th scope="col" className="pb-2 pr-5">Flag A</th><th scope="col" className="pb-2 pr-5">Flag B</th><th scope="col" className="pb-2">Output</th></tr></thead>
        <tbody>{puzzle.truthTable.map((row) => <tr key={`${row.a}-${row.b}`} className="border-b border-border/60 last:border-0"><td className="py-2 pr-5 font-mono">{row.a}</td><td className="py-2 pr-5 font-mono">{row.b}</td><td className="py-2 font-mono font-semibold">{row.output}</td></tr>)}</tbody>
      </table>
    </div>}
  </section>;
}

function AnswerPanel({
  puzzle, selected, onSelect, textAnswer, onTextAnswer, onSubmit, hintUsed, onHint, feedback, solved, prefix,
}: {
  puzzle: Puzzle; selected: string; onSelect: (value: string) => void; textAnswer: string; onTextAnswer: (value: string) => void;
  onSubmit: () => void; hintUsed: boolean; onHint: () => void; feedback: Feedback; solved: boolean; prefix: string;
}) {
  const choices = puzzle.choices;
  return <section className="rounded-2xl border border-border bg-card/80 p-5 sm:p-6" aria-labelledby={`${prefix}-question`}>
    <h3 id={`${prefix}-question`} className="text-base font-bold leading-6">{puzzle.instructions}</h3>
    <p className="mt-4 rounded-xl border border-border/70 bg-background/75 px-4 py-4 font-mono text-sm leading-7 break-words" data-testid={`text-puzzle-prompt-${puzzle.id}`}>{puzzle.prompt}</p>
    {choices ? <fieldset className="mt-4">
      <legend className="mb-2 text-xs text-muted-foreground">Select one answer</legend>
      <div className="grid gap-2">
        {choices.map((choice, index) => <button key={choice.id} type="button" onClick={() => onSelect(choice.id)} aria-pressed={selected === choice.id} disabled={solved}
          className={`group flex min-h-12 items-start gap-3 rounded-xl border px-4 py-3 text-left transition-colors hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary disabled:cursor-not-allowed disabled:opacity-65 ${selected === choice.id ? "border-primary bg-primary/15" : "border-border bg-background/70"}`}
          data-testid={`answer-${puzzle.id}-${choice.id}`}>
          <span className={`mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border font-mono text-[10px] ${selected === choice.id ? "border-primary text-foreground" : "border-border text-muted-foreground"}`}>{String.fromCharCode(65 + index)}</span>
          <span className="text-sm leading-6">{choice.label}</span>
        </button>)}
      </div>
    </fieldset> : <div className="mt-4">
      <label htmlFor={`${prefix}-answer`} className="mb-2 block text-xs font-semibold text-muted-foreground">Your answer</label>
      <input id={`${prefix}-answer`} value={textAnswer} onChange={(event) => onTextAnswer(event.target.value)} disabled={solved} maxLength={120} autoComplete="off"
        onKeyDown={(event) => { if (event.key === "Enter" && !solved) { event.preventDefault(); onSubmit(); } }}
        className="min-h-12 w-full rounded-xl border border-border bg-background px-4 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary disabled:opacity-65"
        placeholder="Type the decoded message" data-testid={`input-answer-${puzzle.id}`} />
    </div>}
    <div className="mt-4 flex flex-col gap-3 border-t border-border/70 pt-4 sm:flex-row sm:items-center sm:justify-between">
      <button type="button" onClick={onHint} disabled={hintUsed || solved} className="inline-flex min-h-10 items-center justify-center gap-2 self-start rounded-full border border-border px-4 py-2 text-xs font-semibold transition-colors hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary disabled:cursor-not-allowed disabled:opacity-55" data-testid={`button-hint-${puzzle.id}`}>
        {hintUsed ? <Check size={14} aria-hidden="true" /> : <CircleHelp size={14} aria-hidden="true" />}{hintUsed ? "Hint used · −20 points" : "Reveal hint · −20 points"}
      </button>
      <span className="font-mono text-[11px] text-muted-foreground" data-testid={`text-award-${puzzle.id}`}>Correct answer: +{scoreAfterHint(puzzle, hintUsed)} pts</span>
    </div>
    <button type="button" onClick={onSubmit} disabled={solved}
      className="mt-4 inline-flex min-h-11 items-center gap-2 rounded-full bg-foreground px-5 py-3 text-sm font-semibold text-background transition-colors hover:bg-foreground/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary disabled:cursor-not-allowed disabled:opacity-45"
      data-testid={`button-submit-${puzzle.id}`}>{solved ? "Answer recorded" : "Submit answer"} <ArrowRight size={15} aria-hidden="true" /></button>
    {feedback && <div role={feedback.kind === "error" ? "alert" : "status"} className={`mt-4 rounded-xl border px-4 py-3 text-sm leading-6 ${feedback.kind === "success" ? "border-primary/70 bg-primary/15" : feedback.kind === "error" ? "border-destructive/50 bg-destructive/10" : "border-border bg-muted/60"}`} data-testid={`status-feedback-${puzzle.id}`}>
      <p className="font-semibold">{feedback.kind === "success" ? "Evidence confirmed" : feedback.kind === "error" ? "Not quite" : "Hint"}</p>
      <p className="mt-1">{feedback.message}</p>
      {feedback.explanation && <p className="mt-2 border-t border-current/10 pt-2 text-xs leading-5">{feedback.explanation}</p>}
    </div>}
  </section>;
}

export default function LogicBreachPage() {
  const [progress, setProgress] = useState<LogicBreachProgress>(() => readLogicBreachProgress());
  const [storageUnavailable, setStorageUnavailable] = useState(false);
  const [view, setView] = useState<View>(() => {
    if (typeof window !== "undefined" && new URLSearchParams(window.location.search).get("mode") === "challenges") return "challenge-list";
    if (progress.storyStarted) return progress.storyRunCompleted.length === storyMissions.length ? "results" : "story-play";
    return "home";
  });
  const [storyIndex, setStoryIndex] = useState(() => progress.storyCurrentMission - 1);
  const [storyUnlocked, setStoryUnlocked] = useState(() => Math.min(storyMissions.length, progress.storyRunCompleted.length + 1));
  const [storyCompletedRun, setStoryCompletedRun] = useState<string[]>(() => progress.storyRunCompleted);
  const [storyHints, setStoryHints] = useState<string[]>(() => progress.storyRunHints);
  const [storyScore, setStoryScore] = useState(() => progress.storyScore);
  const [storyFeedback, setStoryFeedback] = useState<Record<string, Feedback>>({});
  const [storyAnswers, setStoryAnswers] = useState<Record<string, string>>({});
  const [storyText, setStoryText] = useState<Record<string, string>>({});
  const [challengeId, setChallengeId] = useState<string | null>(null);
  const [challengeHints, setChallengeHints] = useState<string[]>([]);
  const [challengeSolved, setChallengeSolved] = useState<string[]>([]);
  const [challengeScore, setChallengeScore] = useState(0);
  const [challengeFeedback, setChallengeFeedback] = useState<Record<string, Feedback>>({});
  const [challengeAnswers, setChallengeAnswers] = useState<Record<string, string>>({});
  const [challengeText, setChallengeText] = useState<Record<string, string>>({});
  const challengeAwardedRef = useRef<Set<string>>(new Set());
  const skipStorageWriteRef = useRef(false);
  const [difficultyFilter, setDifficultyFilter] = useState<"All" | Difficulty>("All");
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [finishedStoryScore, setFinishedStoryScore] = useState(() => progress.storyScore);

  useEffect(() => {
    if (skipStorageWriteRef.current) {
      skipStorageWriteRef.current = false;
      return;
    }
    const saved = writeLogicBreachProgress(progress);
    setStorageUnavailable((previous) => previous === !saved ? previous : !saved);
  }, [progress]);

  const currentStory = storyMissions[storyIndex];
  const currentChallenge = challenges.find((puzzle) => puzzle.id === challengeId) ?? null;
  const categories = useMemo(() => [...new Set(challenges.map((puzzle) => puzzle.category))], []);
  const filteredChallenges = useMemo(() => challenges.filter((puzzle) =>
    (difficultyFilter === "All" || puzzle.difficulty === difficultyFilter) &&
    (categoryFilter === "All" || puzzle.category === categoryFilter)), [difficultyFilter, categoryFilter]);
  const challengeBestTotal = Object.values(progress.challengeBest).reduce((sum, value) => sum + value, 0);

  const beginStory = () => {
    setStoryIndex(0); setStoryUnlocked(1); setStoryCompletedRun([]); setStoryHints([]); setStoryScore(0);
    setStoryAnswers({}); setStoryText({}); setStoryFeedback({}); setView("story-play");
    setFinishedStoryScore(0);
    setProgress((old) => ({
      ...old,
      storyCurrentMission: 1,
      storyRunCompleted: [],
      storyRunHints: [],
      storyScore: 0,
      storyStarted: true,
    }));
  };
  const restartStory = () => {
    const unfinishedRun = progress.storyStarted && progress.storyRunCompleted.length < storyMissions.length;
    if (unfinishedRun && !window.confirm("Restart this story run? Its current mission progress, hints, and score will be cleared.")) return;
    beginStory();
  };
  const submitStory = () => {
    const puzzle = currentStory;
    if (storyCompletedRun.includes(puzzle.id)) return;
    const answer = puzzle.choices ? storyAnswers[puzzle.id] ?? "" : storyText[puzzle.id] ?? "";
    if (!answer.trim()) {
      setStoryFeedback((existing) => ({ ...existing, [puzzle.id]: { kind: "error", message: "Choose or enter an answer before submitting." } }));
      return;
    }
    if (!validateAnswer(puzzle, answer)) {
      setStoryFeedback((existing) => ({ ...existing, [puzzle.id]: { kind: "error", message: "That does not fit the evidence. Re-check the clues and try again." } }));
      return;
    }
    const award = scoreAfterHint(puzzle, storyHints.includes(puzzle.id));
    const nextScore = storyScore + award;
    const nextCompleted = [...storyCompletedRun, puzzle.id];
    setStoryScore(nextScore);
    setStoryCompletedRun(nextCompleted);
    setStoryUnlocked(Math.min(storyMissions.length, storyIndex + 2));
    setProgress((old) => ({
      ...old,
      storyCurrentMission: storyIndex + 1,
      storyRunCompleted: nextCompleted,
      storyRunHints: storyHints,
      storyScore: nextScore,
      storyStarted: true,
      storyCompleted: [...new Set([...old.storyCompleted, puzzle.id])],
      storyBest: storyIndex === storyMissions.length - 1 ? Math.max(old.storyBest, nextScore) : old.storyBest,
    }));
    setStoryFeedback((existing) => ({ ...existing, [puzzle.id]: { kind: "success", message: `${puzzle.narrative} ${award} points awarded${storyHints.includes(puzzle.id) ? " after the hint deduction" : ""}.`, explanation: puzzle.explanation } }));
    if (storyIndex === storyMissions.length - 1) {
      setFinishedStoryScore(nextScore);
      setView("results");
    }
  };
  const selectStoryMission = (index: number) => {
    if (index + 1 > storyUnlocked) return;
    setStoryIndex(index);
    setProgress((old) => ({ ...old, storyCurrentMission: index + 1 }));
  };
  const useStoryHint = () => {
    if (storyHints.includes(currentStory.id) || storyCompletedRun.includes(currentStory.id)) return;
    setStoryHints((existing) => [...existing, currentStory.id]);
    setProgress((old) => ({ ...old, storyRunHints: [...new Set([...old.storyRunHints, currentStory.id])] }));
    setStoryFeedback((existing) => ({ ...existing, [currentStory.id]: { kind: "info", message: currentStory.hint } }));
  };
  const openChallenge = (puzzleId: string) => {
    setChallengeId(puzzleId);
    setView("challenge-play");
  };
  const submitChallenge = () => {
    if (!currentChallenge || challengeSolved.includes(currentChallenge.id)) return;
    const answer = currentChallenge.choices ? challengeAnswers[currentChallenge.id] ?? "" : challengeText[currentChallenge.id] ?? "";
    if (!answer.trim()) {
      setChallengeFeedback((existing) => ({ ...existing, [currentChallenge.id]: { kind: "error", message: "Choose or enter an answer before submitting." } }));
      return;
    }
    if (!validateAnswer(currentChallenge, answer)) {
      setChallengeFeedback((existing) => ({ ...existing, [currentChallenge.id]: { kind: "error", message: "That answer does not follow from the displayed clues. Try again." } }));
      return;
    }
    const award = scoreAfterHint(currentChallenge, challengeHints.includes(currentChallenge.id));
    if (challengeAwardedRef.current.has(currentChallenge.id)) return;
    challengeAwardedRef.current.add(currentChallenge.id);
    setChallengeScore((total) => total + award);
    setChallengeSolved((existing) => [...new Set([...existing, currentChallenge.id])]);
    setProgress((old) => ({
      ...old,
      challengeCompleted: [...new Set([...old.challengeCompleted, currentChallenge.id])],
      challengeBest: { ...old.challengeBest, [currentChallenge.id]: Math.max(old.challengeBest[currentChallenge.id] ?? 0, award) },
    }));
    setChallengeFeedback((existing) => ({ ...existing, [currentChallenge.id]: {
      kind: "success",
      message: `${award} points awarded${challengeHints.includes(currentChallenge.id) ? " after the hint deduction" : ""}.`,
      explanation: currentChallenge.explanation,
    } }));
  };
  const useChallengeHint = () => {
    if (!currentChallenge || challengeHints.includes(currentChallenge.id) || challengeSolved.includes(currentChallenge.id)) return;
    setChallengeHints((existing) => [...existing, currentChallenge.id]);
    setChallengeFeedback((existing) => ({ ...existing, [currentChallenge.id]: { kind: "info", message: currentChallenge.hint } }));
  };
  const resetProgress = () => {
    if (!window.confirm("Reset Logic Breach progress stored in this browser? This only removes Logic Breach data.")) return;
    const removed = resetLogicBreachProgress();
    skipStorageWriteRef.current = true;
    setProgress(emptyLogicBreachProgress());
    setStorageUnavailable(!removed);
    setStoryIndex(0); setStoryUnlocked(1); setStoryCompletedRun([]); setStoryHints([]); setStoryScore(0);
    setStoryAnswers({}); setStoryText({}); setStoryFeedback({});
    setChallengeScore(0); setChallengeSolved([]); setChallengeHints([]); setChallengeFeedback({}); setChallengeAnswers({}); setChallengeText({});
    challengeAwardedRef.current.clear();
    setChallengeId(null);
    setFinishedStoryScore(0);
    setView("home");
  };

  const renderChallengeHeader = () => <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
    <button type="button" onClick={() => setView("challenge-list")} className="inline-flex min-h-10 items-center gap-2 rounded-full border border-border px-4 py-2 text-xs font-semibold transition-colors hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary" data-testid="button-back-challenges"><ChevronLeft size={14} aria-hidden="true" /> Challenge list</button>
    <p className="editorial-kicker text-muted-foreground">Challenge session · {challengeScore} pts</p>
  </div>;

  return <div className="mx-auto w-full max-w-7xl px-4 pb-16 pt-8 sm:px-8 sm:pt-12 lg:px-12" data-testid="logic-breach-page">
    <div className="mb-7 flex flex-wrap items-center justify-between gap-3">
      <BackPortfolio />
      <p className="editorial-kicker text-muted-foreground">Fictional investigation · local play only</p>
    </div>

    {view === "home" && <div className="reveal">
      <section className="relative overflow-hidden rounded-[1.75rem] bg-foreground px-6 py-9 text-background sm:px-10 sm:py-12 lg:px-14 lg:py-14" data-testid="logic-breach-landing">
        <div className="absolute -right-24 -top-28 h-80 w-80 rounded-full border border-background/10 sm:h-[26rem] sm:w-[26rem]" aria-hidden="true" />
        <div className="relative grid gap-10 lg:grid-cols-[1fr_310px] lg:items-end">
          <div className="max-w-3xl">
            <SectionLabel>Fictional archive case file · LB—01</SectionLabel>
            <h1 className="editorial-display mt-3 text-6xl leading-[.9] sm:text-7xl lg:text-8xl">Logic <span className="italic text-primary">Breach.</span></h1>
            <p className="mt-6 max-w-xl text-base leading-7 text-background/75">Think clearly. Break the pattern. Solve the breach.</p>
            <p className="mt-2 max-w-xl text-sm leading-6 text-background/60">A junior analyst follows an interrupted digital archive through five connected missions—or tests their reasoning across a shelf of standalone challenges.</p>
            <div className="mt-7 flex flex-wrap gap-3">
              <button type="button" onClick={() => setView("story-select")} className="inline-flex min-h-12 items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-bold text-foreground transition-colors hover:bg-primary/85 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-background" data-testid="button-open-story">Enter the archive <ArrowRight size={15} aria-hidden="true" /></button>
              <button type="button" onClick={() => setView("challenge-list")} className="inline-flex min-h-12 items-center gap-2 rounded-full border border-background/25 px-5 py-3 text-sm font-semibold transition-colors hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-background" data-testid="button-open-challenges">Browse challenges <ArrowRight size={15} aria-hidden="true" /></button>
            </div>
          </div>
          <aside className="rounded-2xl border border-background/15 bg-background/[.06] p-5 backdrop-blur-sm">
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-foreground"><ShieldCheck size={18} aria-hidden="true" /></span>
              <div><p className="text-sm font-bold">The Missing Signal</p><p className="text-xs text-background/55">Five evidence-led missions</p></div>
            </div>
            <div className="mt-5 space-y-3 border-t border-background/15 pt-4 text-xs">
              <div className="flex items-center justify-between"><span className="text-background/70">Story personal best</span><span className="font-mono" data-testid="text-story-best">{progress.storyBest} pts</span></div>
              <div className="flex items-center justify-between"><span className="text-background/70">Story records solved</span><span className="font-mono" data-testid="text-story-completion">{progress.storyCompleted.length} / 5</span></div>
              <div className="flex items-center justify-between"><span className="text-background/70">Challenge personal best</span><span className="font-mono" data-testid="text-challenge-best">{challengeBestTotal} pts</span></div>
            </div>
          </aside>
        </div>
      </section>
      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        <button type="button" onClick={() => setView("story-select")} className="group rounded-2xl border border-border bg-card/70 p-5 text-left transition-colors hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary sm:p-6" data-testid="card-story-mode">
          <span className="editorial-kicker text-muted-foreground">01 / connected case</span><span className="mt-3 flex items-center justify-between gap-4"><span><span className="editorial-display block text-3xl">Story Mode</span><span className="mt-1 block text-xs leading-5 text-muted-foreground">Investigate five linked archive anomalies.</span></span><ArrowRight size={17} className="shrink-0 transition-transform group-hover:translate-x-1" aria-hidden="true" /></span>
        </button>
        <button type="button" onClick={() => setView("challenge-list")} className="group rounded-2xl border border-border bg-card/70 p-5 text-left transition-colors hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary sm:p-6" data-testid="card-challenge-mode">
          <span className="editorial-kicker text-muted-foreground">02 / open case shelf</span><span className="mt-3 flex items-center justify-between gap-4"><span><span className="editorial-display block text-3xl">Challenge Mode</span><span className="mt-1 block text-xs leading-5 text-muted-foreground">Twelve puzzles across three difficulty levels.</span></span><ArrowRight size={17} className="shrink-0 transition-transform group-hover:translate-x-1" aria-hidden="true" /></span>
        </button>
      </div>
      <div className="mt-5 flex flex-col gap-3 rounded-2xl border border-border bg-card/60 px-5 py-4 sm:flex-row sm:items-center">
        <LockKeyhole size={16} className="shrink-0 text-primary" aria-hidden="true" />
        <p className="text-xs leading-5 text-muted-foreground"><strong className="text-foreground">Safe by design:</strong> this is a fixed fictional puzzle game. No commands, scanning, network access, or real system actions. Progress stays in this browser and is not synchronized.</p>
      </div>
    </div>}

    {view === "story-select" && <section className="reveal" data-testid="story-selection">
      <SectionLabel>Story mode / case briefing</SectionLabel>
      <div className="mt-2 grid gap-7 lg:grid-cols-[1fr_300px]">
        <div className="rounded-[1.6rem] bg-foreground p-6 text-background sm:p-9">
          <p className="editorial-kicker text-primary">The Missing Signal</p>
          <h1 className="editorial-display mt-3 text-5xl leading-none sm:text-6xl">An archive went quiet.</h1>
          <p className="mt-5 max-w-2xl text-sm leading-7 text-background/70">You are the junior analyst assigned to a fictional digital archive. A routine catalog refresh ended early, leaving one signal unaccounted for. Each answer opens the next part of the record.</p>
          <div className="mt-7 flex flex-wrap items-center gap-3">
            {progress.storyStarted && progress.storyRunCompleted.length < storyMissions.length ? <>
              <button type="button" onClick={() => { setStoryIndex(progress.storyCurrentMission - 1); setView("story-play"); }} className="inline-flex min-h-11 items-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-bold text-foreground hover:bg-primary/85 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-background" data-testid="button-continue-story">Continue at mission 0{progress.storyCurrentMission} <ArrowRight size={15} aria-hidden="true" /></button>
              <button type="button" onClick={restartStory} className="inline-flex min-h-11 items-center gap-2 rounded-full border border-background/25 px-4 py-2 text-xs font-semibold hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-background" data-testid="button-restart-story-briefing"><RotateCcw size={13} aria-hidden="true" /> Restart story</button>
            </> : <button type="button" onClick={beginStory} className="inline-flex min-h-11 items-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-bold text-foreground hover:bg-primary/85 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-background" data-testid="button-start-story">Start investigation <ArrowRight size={15} aria-hidden="true" /></button>}
            <span className="text-xs text-background/55">{progress.storyCompleted.length} of 5 records solved on this device</span>
          </div>
        </div>
        <aside className="rounded-2xl border border-border bg-card/70 p-5">
          <SectionLabel>Scoring, in the open</SectionLabel>
          <dl className="mt-4 space-y-3 text-xs">
            {storyMissions.map((mission) => <div key={mission.id} className="flex justify-between gap-3 border-t border-border/70 pt-3 first:border-0 first:pt-0"><dt>{mission.title}</dt><dd className="font-mono">{mission.baseScore} pts</dd></div>)}
            <div className="border-t border-border/70 pt-3 text-muted-foreground">One hint per mission · −20 points</div>
          </dl>
        </aside>
      </div>
    </section>}

    {view === "story-play" && currentStory && <div className="reveal">
      <section className="rounded-[1.5rem] bg-foreground px-5 py-6 text-background sm:px-8 sm:py-8" data-testid="story-game-header">
        <div className="grid gap-5 md:grid-cols-[1fr_auto] md:items-end">
          <div><SectionLabel>The Missing Signal / field sequence</SectionLabel><h1 className="editorial-display mt-2 text-5xl leading-none sm:text-6xl">The archive is speaking.</h1><p className="mt-3 max-w-2xl text-sm leading-6 text-background/60">Follow the evidence. Each solved mission reveals the next record.</p></div>
          <div className="grid grid-cols-3 gap-2">
            {[["Mission", `${storyIndex + 1} / 5`], ["Session", `${storyScore} pts`], ["Hints", `${storyHints.length}`]].map(([label, value]) => <div key={label} className="rounded-xl border border-background/15 bg-background/[.06] px-3 py-2"><p className="editorial-kicker text-[9px] text-background/45">{label}</p><p className="mt-1 text-xs font-semibold">{value}</p></div>)}
          </div>
        </div>
      </section>
      <nav aria-label="Story mission progression" className="mt-4 rounded-2xl border border-border bg-card/60 p-4">
        <p className="editorial-kicker text-muted-foreground">Mission ledger</p>
        <ol className="mt-3 grid grid-cols-5 gap-2">
          {storyMissions.map((mission, index) => {
            const locked = index + 1 > storyUnlocked;
            const complete = storyCompletedRun.includes(mission.id);
            return <li key={mission.id} className="min-w-0">
              <button type="button" onClick={() => selectStoryMission(index)} disabled={locked} aria-current={storyIndex === index ? "step" : undefined}
                aria-label={`${mission.title}${locked ? ", locked" : complete ? ", complete" : ", available"}`}
                className={`flex min-h-[4.4rem] w-full flex-col justify-between rounded-xl border p-2.5 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary sm:p-3 ${complete ? "border-primary bg-primary/20" : storyIndex === index ? "border-foreground bg-foreground text-background" : "border-border bg-background/60"} ${locked ? "cursor-not-allowed opacity-50" : "hover:border-primary"}`}
                data-testid={`button-story-mission-${index + 1}`}>
                <span className="font-mono text-[10px]">0{index + 1}</span>
                <span className="truncate text-[10px] font-semibold sm:text-xs">{locked ? "Locked" : complete ? "Complete" : "Available"}</span>
              </button>
            </li>;
          })}
        </ol>
        <p className="mt-3 text-xs text-muted-foreground" data-testid="text-story-progress">{storyCompletedRun.length} of 5 missions complete · hints used: {storyHints.length}</p>
      </nav>
      <div className="mt-6 grid items-start gap-6 lg:grid-cols-[minmax(0,1.3fr)_minmax(18rem,.7fr)]">
        <section className="space-y-5">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div><SectionLabel>Mission 0{currentStory.id.slice(-1)} · {currentStory.category}</SectionLabel><h2 className="editorial-display mt-1 text-4xl leading-none sm:text-5xl">{currentStory.title}</h2></div>
            <span className="rounded-full border border-border px-3 py-1.5 font-mono text-[10px] text-muted-foreground">{storyCompletedRun.includes(currentStory.id) ? "Solved this run" : `Up to ${currentStory.baseScore} pts`}</span>
          </div>
          <p className="max-w-3xl text-sm leading-7 text-muted-foreground">{currentStory.narrative}</p>
          <PuzzleEvidence puzzle={currentStory} />
          <AnswerPanel puzzle={currentStory} prefix="story" selected={storyAnswers[currentStory.id] ?? ""} onSelect={(answer) => { setStoryAnswers((old) => ({ ...old, [currentStory.id]: answer })); setStoryFeedback((old) => ({ ...old, [currentStory.id]: null })); }}
            textAnswer={storyText[currentStory.id] ?? ""} onTextAnswer={(answer) => { setStoryText((old) => ({ ...old, [currentStory.id]: answer })); setStoryFeedback((old) => ({ ...old, [currentStory.id]: null })); }}
            onSubmit={submitStory} hintUsed={storyHints.includes(currentStory.id)} onHint={useStoryHint}
            feedback={storyFeedback[currentStory.id] ?? null} solved={storyCompletedRun.includes(currentStory.id)} />
          {storyCompletedRun.includes(currentStory.id) && storyIndex < 4 && <button type="button" onClick={() => selectStoryMission(storyIndex + 1)} className="inline-flex min-h-11 items-center gap-2 rounded-full bg-foreground px-5 py-3 text-sm font-semibold text-background hover:bg-foreground/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary" data-testid="button-next-story">Continue to mission 0{storyIndex + 2} <ArrowRight size={15} aria-hidden="true" /></button>}
        </section>
        <aside className="space-y-4 lg:sticky lg:top-24">
          <div className="rounded-2xl border border-border bg-card/70 p-5">
            <SectionLabel>Session ledger</SectionLabel>
            <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-4 text-xs">
              <div><dt className="text-muted-foreground">Score</dt><dd className="mt-1 font-mono text-base">{storyScore}</dd></div><div><dt className="text-muted-foreground">Best on device</dt><dd className="mt-1 font-mono text-base">{progress.storyBest}</dd></div>
              <div><dt className="text-muted-foreground">Correct answers</dt><dd className="mt-1 font-mono">{storyCompletedRun.length} / 5</dd></div><div><dt className="text-muted-foreground">Reward after hint</dt><dd className="mt-1 font-mono">{scoreAfterHint(currentStory, storyHints.includes(currentStory.id))} pts</dd></div>
            </dl>
          </div>
          <button type="button" onClick={() => setView("story-select")} className="inline-flex min-h-10 items-center gap-2 rounded-full border border-border px-4 py-2 text-xs font-semibold hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary" data-testid="button-exit-story"><ChevronLeft size={14} aria-hidden="true" /> Case briefing</button>
        </aside>
      </div>
    </div>}

    {view === "challenge-list" && <section className="reveal" data-testid="challenge-list">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div><SectionLabel>Challenge mode / open case shelf</SectionLabel><h1 className="editorial-display mt-2 text-5xl leading-none sm:text-6xl">Choose a puzzle.</h1><p className="mt-3 max-w-xl text-sm leading-6 text-muted-foreground">Independent, evidence-led problems. Return to this shelf at any time; your current answer and hints stay in the session.</p></div>
        <div className="rounded-xl border border-border bg-card/70 px-4 py-3 text-xs"><span className="text-muted-foreground">Session score</span><strong className="ml-3 font-mono" data-testid="text-challenge-session-score">{challengeScore} pts</strong></div>
      </div>
      <div className="mt-6 grid gap-3 rounded-2xl border border-border bg-card/60 p-4 sm:grid-cols-2">
        <label className="text-xs font-semibold">Difficulty
          <select value={difficultyFilter} onChange={(event) => setDifficultyFilter(event.target.value as "All" | Difficulty)} className="mt-2 min-h-11 w-full rounded-xl border border-border bg-background px-3 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary" data-testid="select-challenge-difficulty">
            {["All", "Easy", "Medium", "Hard"].map((value) => <option key={value} value={value}>{value}</option>)}
          </select>
        </label>
        <label className="text-xs font-semibold">Category
          <select value={categoryFilter} onChange={(event) => setCategoryFilter(event.target.value)} className="mt-2 min-h-11 w-full rounded-xl border border-border bg-background px-3 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary" data-testid="select-challenge-category">
            <option value="All">All categories</option>{categories.map((category) => <option key={category} value={category}>{category}</option>)}
          </select>
        </label>
      </div>
      <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground"><span>{filteredChallenges.length} puzzles shown · {progress.challengeCompleted.length} completed on this device</span><span>Best scores are local</span></div>
      {filteredChallenges.length ? <ol className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {filteredChallenges.map((puzzle, index) => {
          const complete = progress.challengeCompleted.includes(puzzle.id);
          return <li key={puzzle.id} className="min-w-0">
            <button type="button" onClick={() => openChallenge(puzzle.id)} className="group flex min-h-[13rem] w-full flex-col rounded-2xl border border-border bg-card/70 p-5 text-left transition-colors hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary" data-testid={`button-open-challenge-${puzzle.id}`}>
              <span className="flex w-full items-center justify-between gap-3"><span className="editorial-kicker text-muted-foreground">Case {String(index + 1).padStart(2, "0")}</span><span className={`rounded-full border px-2.5 py-1 font-mono text-[9px] uppercase tracking-wider ${puzzle.difficulty === "Hard" ? "border-accent/50 text-accent" : puzzle.difficulty === "Medium" ? "border-primary/50 text-foreground" : "border-border text-muted-foreground"}`}>{puzzle.difficulty}</span></span>
              <span className="editorial-display mt-5 block text-3xl leading-none">{puzzle.title}</span>
              <span className="mt-2 text-[11px] leading-5 text-muted-foreground">{puzzle.category}</span>
              <span className="mt-auto flex w-full items-center justify-between border-t border-border/70 pt-4 text-xs"><span className="font-mono text-muted-foreground">{complete ? `Best ${progress.challengeBest[puzzle.id] ?? 0} pts` : `${puzzle.baseScore} pts`}</span><span className="inline-flex items-center gap-1 font-semibold">{complete ? "Replay" : "Open"} <ArrowRight size={13} className="transition-transform group-hover:translate-x-1" aria-hidden="true" /></span></span>
            </button>
          </li>;
        })}
      </ol> : <div className="mt-5 rounded-2xl border border-dashed border-border bg-card/50 px-5 py-10 text-center" data-testid="empty-challenge-filter"><p className="editorial-display text-3xl">No cases in this drawer.</p><button type="button" onClick={() => { setDifficultyFilter("All"); setCategoryFilter("All"); }} className="mt-4 rounded-full border border-border px-4 py-2 text-xs font-semibold hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary" data-testid="button-clear-challenge-filters">Clear filters</button></div>}
    </section>}

    {view === "challenge-play" && currentChallenge && <div className="reveal">
      {renderChallengeHeader()}
      <section className="rounded-[1.5rem] bg-foreground px-5 py-6 text-background sm:px-8 sm:py-8" data-testid="challenge-game-header">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div><SectionLabel>Challenge / {currentChallenge.category}</SectionLabel><h1 className="editorial-display mt-2 text-5xl leading-none sm:text-6xl">{currentChallenge.title}</h1><p className="mt-3 max-w-2xl text-sm leading-6 text-background/65">Apply only the clues shown in this case file.</p></div>
          <div className="flex gap-2"><span className="rounded-full border border-background/20 px-3 py-2 font-mono text-[10px]">{currentChallenge.difficulty}</span><span className="rounded-full border border-background/20 px-3 py-2 font-mono text-[10px]">{challengeScore} pts</span></div>
        </div>
      </section>
      <div className="mt-6 grid items-start gap-6 lg:grid-cols-[minmax(0,1.3fr)_minmax(18rem,.7fr)]">
        <section className="space-y-5">
          <PuzzleEvidence puzzle={currentChallenge} />
          <AnswerPanel puzzle={currentChallenge} prefix="challenge" selected={challengeAnswers[currentChallenge.id] ?? ""} onSelect={(answer) => { setChallengeAnswers((old) => ({ ...old, [currentChallenge.id]: answer })); setChallengeFeedback((old) => ({ ...old, [currentChallenge.id]: null })); }}
            textAnswer={challengeText[currentChallenge.id] ?? ""} onTextAnswer={(answer) => { setChallengeText((old) => ({ ...old, [currentChallenge.id]: answer })); setChallengeFeedback((old) => ({ ...old, [currentChallenge.id]: null })); }}
            onSubmit={submitChallenge} hintUsed={challengeHints.includes(currentChallenge.id)} onHint={useChallengeHint}
            feedback={challengeFeedback[currentChallenge.id] ?? null} solved={challengeSolved.includes(currentChallenge.id)} />
        </section>
        <aside className="space-y-4 lg:sticky lg:top-24">
          <div className="rounded-2xl border border-border bg-card/70 p-5">
            <SectionLabel>Personal ledger</SectionLabel>
            <dl className="mt-4 space-y-3 text-xs">
              <div className="flex justify-between gap-3"><dt className="text-muted-foreground">Session score</dt><dd className="font-mono">{challengeScore} pts</dd></div>
              <div className="flex justify-between gap-3"><dt className="text-muted-foreground">Lifetime best</dt><dd className="font-mono">{progress.challengeBest[currentChallenge.id] ?? 0} pts</dd></div>
              <div className="flex justify-between gap-3"><dt className="text-muted-foreground">Hint status</dt><dd>{challengeHints.includes(currentChallenge.id) ? "Used" : "Available"}</dd></div>
              <div className="flex justify-between gap-3 border-t border-border pt-3"><dt className="text-muted-foreground">Available reward</dt><dd className="font-mono">{scoreAfterHint(currentChallenge, challengeHints.includes(currentChallenge.id))} pts</dd></div>
            </dl>
          </div>
          {challengeSolved.includes(currentChallenge.id) && <button type="button" onClick={() => {
            setChallengeAnswers((old) => ({ ...old, [currentChallenge.id]: "" }));
            setChallengeText((old) => ({ ...old, [currentChallenge.id]: "" }));
            setChallengeFeedback((old) => ({ ...old, [currentChallenge.id]: null }));
            setChallengeSolved((old) => old.filter((id) => id !== currentChallenge.id));
            setChallengeHints((old) => old.filter((id) => id !== currentChallenge.id));
            challengeAwardedRef.current.delete(currentChallenge.id);
          }} className="inline-flex min-h-10 items-center gap-2 rounded-full border border-border px-4 py-2 text-xs font-semibold hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary" data-testid="button-replay-challenge"><RotateCcw size={13} aria-hidden="true" /> Replay this puzzle</button>}
        </aside>
      </div>
    </div>}

    {view === "results" && <section className="reveal mx-auto max-w-4xl rounded-[1.75rem] bg-foreground px-6 py-10 text-background sm:px-10 sm:py-14" data-testid="story-results">
      <SectionLabel>Case closed · local result</SectionLabel>
      <h1 className="editorial-display mt-3 text-6xl leading-none sm:text-7xl">The signal<br /><span className="italic text-primary">is found.</span></h1>
      <p className="mt-5 max-w-2xl text-sm leading-7 text-background/70">Chorus was moved, not erased. The archive can be restored from its own record. You followed the evidence without inventing a cause.</p>
      <div className="mt-8 grid gap-3 sm:grid-cols-3">
        {[["Final score", `${finishedStoryScore} pts`], ["Missions solved", "5 / 5"], ["Personal best", `${progress.storyBest} pts`]].map(([label, value]) => <div key={label} className="rounded-2xl border border-background/15 bg-background/[.06] p-5"><p className="editorial-kicker text-background/50">{label}</p><p className="mt-2 font-mono text-3xl" data-testid={`result-${label.toLowerCase().replaceAll(" ", "-")}`}>{value}</p></div>)}
      </div>
      <p className="mt-5 text-xs text-background/60">Hints used: {storyHints.length} · Story records completed on this device: {progress.storyCompleted.length} / 5</p>
      <div className="mt-8 flex flex-wrap gap-3">
         <button type="button" onClick={beginStory} className="inline-flex min-h-11 items-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-bold text-foreground hover:bg-primary/85 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-background" data-testid="button-restart-story"><RotateCcw size={14} aria-hidden="true" /> Restart story</button>
        <button type="button" onClick={() => setView("challenge-list")} className="inline-flex min-h-11 items-center gap-2 rounded-full border border-background/25 px-5 py-3 text-sm font-semibold hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-background" data-testid="button-results-challenges">Try challenges <ArrowRight size={14} aria-hidden="true" /></button>
        <button type="button" onClick={() => setView("home")} className="inline-flex min-h-11 items-center gap-2 rounded-full border border-background/25 px-5 py-3 text-sm font-semibold hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-background" data-testid="button-results-home">Game home</button>
        <button type="button" onClick={resetProgress} className="inline-flex min-h-11 items-center gap-2 rounded-full border border-background/25 px-5 py-3 text-sm font-semibold text-background/70 hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-background" data-testid="button-reset-progress"><RotateCcw size={13} aria-hidden="true" /> Reset progress</button>
      </div>
    </section>}

    {view !== "home" && view !== "results" && <div className="mt-10 flex flex-wrap items-center justify-between gap-3 border-t border-border pt-5">
      <p className="inline-flex items-center gap-2 text-xs text-muted-foreground"><LockKeyhole size={13} aria-hidden="true" /> Progress is saved locally in this browser only.</p>
      {view !== "challenge-play" && <div className="inline-flex flex-wrap gap-2">
        {view !== "story-play" && <button type="button" onClick={() => setView("home")} className="inline-flex min-h-10 items-center gap-2 rounded-full border border-border px-4 py-2 text-xs font-semibold hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary" data-testid="button-game-home"><ChevronLeft size={13} aria-hidden="true" /> Game home</button>}
        <button type="button" onClick={resetProgress} className="inline-flex min-h-10 items-center gap-2 rounded-full border border-border px-4 py-2 text-xs font-semibold text-muted-foreground transition-colors hover:border-destructive hover:text-destructive focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary" data-testid="button-reset-progress"><RotateCcw size={13} aria-hidden="true" /> Reset progress</button>
      </div>}
    </div>}
    {view === "home" && <div className="mt-6 flex justify-end">
      <button type="button" onClick={resetProgress} className="inline-flex min-h-10 items-center gap-2 rounded-full border border-border px-4 py-2 text-xs font-semibold text-muted-foreground hover:border-destructive hover:text-destructive focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary" data-testid="button-reset-progress"><RotateCcw size={13} aria-hidden="true" /> Reset progress</button>
    </div>}
    {view === "challenge-play" && <div className="mt-8 flex flex-wrap items-center justify-between gap-3 border-t border-border pt-5">
      <p className="inline-flex items-center gap-2 text-xs text-muted-foreground"><LockKeyhole size={13} aria-hidden="true" /> Progress is saved locally in this browser only.</p>
      <button type="button" onClick={resetProgress} className="inline-flex min-h-10 items-center gap-2 rounded-full border border-border px-4 py-2 text-xs font-semibold text-muted-foreground hover:border-destructive hover:text-destructive focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary" data-testid="button-reset-progress">Reset progress</button>
    </div>}
    {storageUnavailable && <p role="status" className="mt-5 rounded-xl border border-accent/40 bg-accent/10 px-4 py-3 text-xs leading-5" data-testid="status-storage">Browser storage is unavailable. Logic Breach remains playable for this visit; progress will not persist.</p>}
    <div className="sr-only" aria-live="polite" data-testid="status-score-updates">Story score {storyScore}. Challenge score {challengeScore}.</div>
  </div>;
}
