import { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowDown, ArrowUp, BarChart3, BookOpen, Check, ChevronDown, ChevronUp, Database, FileText, FlaskConical, FolderKanban, Inbox, LayoutDashboard, ListChecks, LogOut, Plus, Settings, ShieldCheck, Trash2, Wrench, X } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useCertificatesData, useDeleteCert } from "@/hooks/use-certificates-data";
import { apiFetch, type ContactMessage, type SiteSettings, type TerminalCommand } from "@/lib/api";
import { useSettings } from "@/hooks/use-settings";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { SecurityLabAdminPanel } from "@/components/security-lab/SecurityLabAdminPanel";

type Overview = {
  totalProjects: number; totalCertificates: number; totalSkills: number; totalExperience: number;
  unreadMessages: number; publishedPosts: number; portfolioViews: number; terminalCommands: number;
  recentActivity: { id: number; label: string; createdAt: string }[];
};
type Tab = "dashboard" | "projects" | "certificates" | "skills" | "experience" | "blog" | "messages" | "analytics" | "terminal" | "settings" | "security-lab";

const emptySettings: SiteSettings = {
  id: 0, fullName: "", username: "", professionalTitle: "", shortBio: "", email: "", phone: "", location: "",
  githubUrl: "", linkedinUrl: "", telegramUrl: "", availabilityStatus: "", heroTitle: "", heroSubtitle: "", contactText: "",
};

const nav = [
  ["dashboard", "Dashboard", LayoutDashboard], ["projects", "Projects", FolderKanban], ["certificates", "Certificates", FileText],
  ["skills", "Skills", ListChecks], ["experience", "Experience", Wrench], ["blog", "Blog", BookOpen],
  ["messages", "Messages", Inbox], ["analytics", "Analytics", BarChart3], ["terminal", "Terminal", Database], ["security-lab", "Security Lab", FlaskConical], ["settings", "Site Settings", Settings],
] as const;

export default function AdminDashboard() {
  const { isAdmin, isLoading: authLoading, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [tab, setTab] = useState<Tab>("dashboard");
  const { toast } = useToast();
  useEffect(() => { if (!authLoading && !isAdmin) setLocation("/admin"); }, [authLoading, isAdmin, setLocation]);
  if (authLoading || !isAdmin) return null;

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-8 lg:px-12">
      <header className="mb-8 flex flex-col gap-5 border-b border-border pb-6 sm:flex-row sm:items-end sm:justify-between">
        <div><p className="editorial-kicker text-primary">Private workspace</p><h1 className="editorial-display mt-2 text-5xl leading-none">Control panel</h1></div>
        <Button variant="ghost" className="gap-2 self-start rounded-full text-xs text-muted-foreground sm:self-auto" onClick={async () => { await logout(); setLocation("/"); }}><LogOut className="h-4 w-4" /> Log out</Button>
      </header>
      <div className="grid gap-8 lg:grid-cols-[13rem_1fr]">
        <aside className="flex gap-1 overflow-x-auto pb-2 lg:block lg:space-y-1">
          {nav.map(([id, label, Icon]) => <button key={id} onClick={() => setTab(id)} className={`flex shrink-0 items-center gap-2 rounded-xl px-3 py-2 text-left text-xs font-medium transition ${tab === id ? "bg-foreground text-background" : "text-muted-foreground hover:bg-card hover:text-foreground"}`}><Icon className="h-3.5 w-3.5" /> {label}{id === "messages" && <MessageBadge />}</button>)}
        </aside>
        <main className="min-w-0">
          {tab === "dashboard" && <DashboardOverview />}
          {tab === "certificates" && <CertificatesPanel />}
          {tab === "messages" && <MessagesPanel />}
          {tab === "terminal" && <TerminalPanel />}
          {tab === "settings" && <SettingsPanel />}
          {tab === "analytics" && <AnalyticsPanel />}
          {tab === "security-lab" && <SecurityLabAdminPanel />}
          {(["projects", "skills", "experience", "blog"] as Tab[]).includes(tab) && <EmptyContentPanel tab={tab} />}
        </main>
      </div>
      <p className="mt-10 flex items-center gap-2 text-xs text-muted-foreground"><ShieldCheck className="h-3.5 w-3.5 text-primary" /> Server-side admin session active. Public messages and settings are never exposed through this panel.</p>
    </div>
  );
}

function useOverview() {
  return useQuery({ queryKey: ["/api/admin/overview"], queryFn: () => apiFetch<Overview>("/api/admin/overview") });
}

function MessageBadge() {
  const { data } = useOverview();
  return data?.unreadMessages ? <span className="ml-auto rounded-full bg-primary px-1.5 py-0.5 text-[10px] text-foreground">{data.unreadMessages}</span> : null;
}

function DashboardOverview() {
  const { data, isLoading } = useOverview();
  const cards = [
    ["Projects", data?.totalProjects ?? 0, FolderKanban], ["Certificates", data?.totalCertificates ?? 0, FileText], ["Skills", data?.totalSkills ?? 0, ListChecks],
    ["Experience", data?.totalExperience ?? 0, Wrench], ["Unread messages", data?.unreadMessages ?? 0, Inbox], ["Published posts", data?.publishedPosts ?? 0, BookOpen], ["Portfolio views", data?.portfolioViews ?? 0, BarChart3],
  ] as const;
  return <section className="space-y-6"><PanelHeading kicker="Overview" title="Dashboard" description="A quick read on the public archive and its private workspace." />
    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">{cards.map(([label, value, Icon]) => <div key={label} className="soft-card rounded-2xl p-4"><Icon className="h-4 w-4 text-primary" /><p className="mt-6 text-3xl font-semibold">{isLoading ? "—" : value}</p><p className="mt-1 text-xs text-muted-foreground">{label}</p></div>)}</div>
    <div className="soft-card rounded-2xl p-5"><p className="editorial-kicker text-primary">Recent activity</p>{data?.recentActivity.length ? <div className="mt-4 space-y-3">{data.recentActivity.map((item) => <div key={item.id} className="flex items-center justify-between border-b border-border/60 pb-3 text-sm"><span>{item.label}</span><span className="font-mono text-[10px] text-muted-foreground">{format(new Date(item.createdAt), "dd MMM yyyy, HH:mm")}</span></div>)}</div> : <p className="mt-4 text-sm text-muted-foreground">No recent activity yet.</p>}</div>
  </section>;
}

function CertificatesPanel() {
  const { data: certs, isLoading } = useCertificatesData();
  const deleteMutation = useDeleteCert();
  const { toast } = useToast();
  return <section className="space-y-6"><PanelHeading kicker="Archive" title="Certificates" description="The certificate uploader is intentionally disabled here; the archive is managed from the seeded records and the database." />
    <div className="soft-card overflow-hidden rounded-2xl"><div className="border-b border-border/60 px-5 py-4 font-mono text-xs text-primary">RECORDS_REGISTRY</div>{isLoading ? <p className="p-5 text-sm text-muted-foreground">Loading records…</p> : certs?.length ? <div className="divide-y divide-border/60">{certs.map((cert) => <div key={cert.id} className="flex items-center gap-4 p-4"><img src={cert.thumbnailUrl || cert.fileUrl} alt="" className="h-12 w-16 rounded-lg object-cover" /><div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{cert.title}</p><p className="text-xs text-muted-foreground">{cert.issuer} · {cert.issuedDate || "Undated"}</p></div><button aria-label={`Delete ${cert.title}`} className="text-muted-foreground hover:text-destructive" onClick={async () => { if (!confirm("Delete this certificate?")) return; await deleteMutation.mutateAsync({ id: cert.id }); toast({ title: "Certificate deleted" }); }}><Trash2 className="h-4 w-4" /></button></div>)}</div> : <p className="p-5 text-sm text-muted-foreground">No certificates found.</p>}</div>
  </section>;
}

function MessagesPanel() {
  const queryClient = useQueryClient();
  const { data: messages, isLoading } = useQuery({ queryKey: ["/api/contact"], queryFn: () => apiFetch<ContactMessage[]>("/api/contact") });
  const [openId, setOpenId] = useState<number | null>(null);
  const { toast } = useToast();
  const update = async (id: number, isRead: boolean) => { await apiFetch(`/api/contact/${id}`, { method: "PATCH", body: JSON.stringify({ isRead }) }); await queryClient.invalidateQueries({ queryKey: ["/api/contact"] }); await queryClient.invalidateQueries({ queryKey: ["/api/admin/overview"] }); };
  const remove = async (id: number) => { await apiFetch(`/api/contact/${id}`, { method: "DELETE" }); await queryClient.invalidateQueries({ queryKey: ["/api/contact"] }); toast({ title: "Message deleted" }); };
  return <section className="space-y-6"><PanelHeading kicker="Inbox" title="Messages" description="Private contact submissions. Open a row to read the full message." />
    <div className="soft-card overflow-hidden rounded-2xl">{isLoading ? <p className="p-5 text-sm text-muted-foreground">Loading messages…</p> : messages?.length ? messages.map((message) => <div key={message.id} className={`border-b border-border/60 p-4 last:border-0 ${!message.isRead ? "bg-primary/5" : ""}`}><button onClick={() => { setOpenId(openId === message.id ? null : message.id); if (!message.isRead) void update(message.id, true); }} className="flex w-full items-center gap-3 text-left"><span className={`h-2 w-2 rounded-full ${message.isRead ? "bg-border" : "bg-primary"}`} /><span className="min-w-0 flex-1"><span className="block truncate text-sm font-semibold">{message.subject}</span><span className="block truncate text-xs text-muted-foreground">{message.name} · {message.email}</span></span><span className="hidden font-mono text-[10px] text-muted-foreground sm:block">{format(new Date(message.createdAt), "dd MMM yyyy")}</span>{openId === message.id ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}</button>{openId === message.id && <div className="ml-5 mt-4 rounded-xl border border-border/60 bg-background/50 p-4"><p className="whitespace-pre-wrap text-sm leading-6 text-muted-foreground">{message.message}</p><div className="mt-4 flex flex-wrap gap-2"><a href={`mailto:${message.email}`} className="rounded-full bg-foreground px-3 py-2 text-xs text-background">Reply</a><button onClick={() => void update(message.id, !message.isRead)} className="rounded-full border border-border px-3 py-2 text-xs">{message.isRead ? "Mark unread" : "Mark read"}</button><button onClick={() => void remove(message.id)} className="rounded-full border border-destructive/30 px-3 py-2 text-xs text-destructive">Delete</button></div></div>}</div>) : <p className="p-5 text-sm text-muted-foreground">No messages yet.</p>}</div>
  </section>;
}

function TerminalPanel() {
  const queryClient = useQueryClient();
  const { data } = useQuery({ queryKey: ["/api/terminal", "admin"], queryFn: () => apiFetch<TerminalCommand[]>("/api/terminal?admin=1") });
  const [rows, setRows] = useState<TerminalCommand[]>([]);
  const { toast } = useToast();
  useEffect(() => { if (data) setRows(data); }, [data]);
  const save = async () => { await apiFetch("/api/terminal", { method: "PUT", body: JSON.stringify({ commands: rows }) }); await queryClient.invalidateQueries({ queryKey: ["/api/terminal"] }); toast({ title: "Terminal saved" }); };
  const update = (index: number, patch: Partial<TerminalCommand>) => setRows(rows.map((row, i) => i === index ? { ...row, ...patch } : row));
  return <section className="space-y-6"><PanelHeading kicker="Simulated shell" title="Terminal CMS" description="These are display-only portfolio responses. No database value is ever executed as a server command." /><div className="soft-card space-y-3 rounded-2xl p-5">{rows.map((row, i) => <div key={row.id ?? i} className="grid gap-2 rounded-xl border border-border/60 p-3 lg:grid-cols-[.7fr_1fr_1fr_auto_auto]"><Input value={row.command} onChange={(e) => update(i, { command: e.target.value })} placeholder="command" className="font-mono text-xs" /><Input value={row.output} onChange={(e) => update(i, { output: e.target.value })} placeholder="output" className="font-mono text-xs" /><Input value={row.description ?? ""} onChange={(e) => update(i, { description: e.target.value })} placeholder="description" className="text-xs" /><button title="Move up" onClick={() => i > 0 && setRows(rows.map((item, j) => j === i - 1 ? rows[i] : j === i ? rows[i - 1] : item))}><ArrowUp className="h-4 w-4" /></button><div className="flex items-center gap-2"><button title="Move down" onClick={() => i < rows.length - 1 && setRows(rows.map((item, j) => j === i + 1 ? rows[i] : j === i ? rows[i + 1] : item))}><ArrowDown className="h-4 w-4" /></button><button title={row.enabled ? "Disable" : "Enable"} onClick={() => update(i, { enabled: !row.enabled })} className={row.enabled ? "text-primary" : "text-muted-foreground"}>{row.enabled ? <Check className="h-4 w-4" /> : <X className="h-4 w-4" />}</button><button title="Delete" onClick={() => setRows(rows.filter((_, j) => j !== i))} className="text-destructive"><Trash2 className="h-4 w-4" /></button></div></div>)}<div className="flex flex-wrap gap-2"><Button variant="outline" onClick={() => setRows([...rows, { id: Date.now(), command: "", response: "", output: "", description: "", sortOrder: rows.length, enabled: true }])}><Plus className="mr-2 h-4 w-4" /> Add command</Button><Button onClick={save}>Save commands</Button></div></div></section>;
}

function SettingsPanel() {
  const queryClient = useQueryClient();
  const { data } = useSettings();
  const [form, setForm] = useState<SiteSettings>(emptySettings);
  const { toast } = useToast();
  useEffect(() => {
    if (data) {
      setForm({
        ...data,
        fullName: data.fullName ?? "",
        username: data.username ?? "",
        professionalTitle: data.professionalTitle ?? "",
        shortBio: data.shortBio ?? "",
        email: data.email ?? "",
        phone: data.phone ?? "",
        location: data.location ?? "",
        githubUrl: data.githubUrl ?? "",
        linkedinUrl: data.linkedinUrl ?? "",
        telegramUrl: data.telegramUrl ?? "",
        availabilityStatus: data.availabilityStatus ?? "",
        heroTitle: data.heroTitle ?? "",
        heroSubtitle: data.heroSubtitle ?? "",
        contactText: data.contactText ?? "",
      });
    }
  }, [data]);
  const save = async (event: React.FormEvent) => { event.preventDefault(); await apiFetch("/api/settings", { method: "PUT", body: JSON.stringify(form) }); await queryClient.invalidateQueries({ queryKey: ["/api/settings"] }); toast({ title: "Settings saved" }); };
  const field = (key: keyof SiteSettings, label: string, multiline = false) => <div className={multiline ? "sm:col-span-2" : ""}><Label className="editorial-kicker text-muted-foreground">{label}</Label>{multiline ? <Textarea value={String(form[key] ?? "")} onChange={(e) => setForm({ ...form, [key]: e.target.value })} className="mt-2 min-h-24 bg-background/60" /> : <Input value={String(form[key] ?? "")} onChange={(e) => setForm({ ...form, [key]: e.target.value })} className="mt-2 bg-background/60" />}</div>;
  return <section className="space-y-6"><PanelHeading kicker="Public identity" title="Site Settings" description="Every public identity field on the portfolio is managed here." /><form onSubmit={save} className="soft-card grid gap-5 rounded-2xl p-5 sm:grid-cols-2">{field("fullName", "FULL NAME")}{field("username", "USERNAME")}{field("professionalTitle", "PROFESSIONAL TITLE")}{field("availabilityStatus", "AVAILABILITY STATUS")}{field("email", "EMAIL")}{field("phone", "PHONE")}{field("location", "LOCATION")}{field("githubUrl", "GITHUB URL")}{field("linkedinUrl", "LINKEDIN URL")}{field("telegramUrl", "TELEGRAM URL")}{field("heroTitle", "HERO TITLE", true)}{field("heroSubtitle", "HERO SUBTITLE", true)}{field("shortBio", "SHORT BIO", true)}{field("contactText", "CONTACT TEXT", true)}<div className="sm:col-span-2"><Button type="submit">Save settings</Button></div></form></section>;
}

function AnalyticsPanel() {
  const { data } = useQuery({ queryKey: ["/api/analytics/summary"], queryFn: () => apiFetch<{ totalViews: number }>("/api/analytics/summary") });
  return <section className="space-y-6"><PanelHeading kicker="Signal" title="Analytics" description="Simple portfolio traffic signals collected without exposing visitor identities." /><div className="soft-card rounded-2xl p-6"><BarChart3 className="h-5 w-5 text-primary" /><p className="mt-6 text-5xl font-semibold">{data?.totalViews ?? 0}</p><p className="mt-2 text-sm text-muted-foreground">Portfolio views</p></div></section>;
}

function EmptyContentPanel({ tab }: { tab: Tab }) {
  const label = tab[0].toUpperCase() + tab.slice(1);
  return <section className="space-y-6"><PanelHeading kicker="Content module" title={label} description="This module is ready in the dashboard navigation and can be populated as the portfolio grows." /><div className="soft-card rounded-2xl p-8 text-center"><FolderKanban className="mx-auto h-8 w-8 text-muted-foreground" /><p className="mt-4 text-sm text-muted-foreground">No {label.toLowerCase()} records yet.</p></div></section>;
}

function PanelHeading({ kicker, title, description }: { kicker: string; title: string; description: string }) {
  return <div><p className="editorial-kicker text-primary">{kicker}</p><h2 className="editorial-display mt-2 text-5xl leading-none">{title}</h2><p className="mt-3 max-w-2xl text-sm leading-6 text-muted-foreground">{description}</p></div>;
}