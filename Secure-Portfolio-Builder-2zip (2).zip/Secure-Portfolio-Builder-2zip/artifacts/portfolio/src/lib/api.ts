export async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(path, {
    credentials: "include",
    cache: init?.cache ?? "no-store",
    headers: {
      ...(init?.body && !(init.body instanceof FormData) ? { "Content-Type": "application/json" } : {}),
      ...init?.headers,
    },
    ...init,
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data?.error || `Request failed (${response.status})`);
  return data as T;
}

export interface SiteSettings {
  id: number;
  fullName: string | null;
  username: string | null;
  professionalTitle: string | null;
  shortBio: string | null;
  email: string | null;
  phone: string | null;
  location: string | null;
  githubUrl: string | null;
  linkedinUrl: string | null;
  telegramUrl: string | null;
  availabilityStatus: string | null;
  heroTitle: string | null;
  heroSubtitle: string | null;
  contactText: string | null;
}

export interface TerminalCommand {
  id: number;
  command: string;
  response: string;
  output: string;
  description: string | null;
  sortOrder: number;
  enabled: boolean;
}

export interface ContactMessage {
  id: number;
  name: string;
  email: string;
  subject: string;
  message: string;
  isRead: boolean;
  createdAt: string;
}