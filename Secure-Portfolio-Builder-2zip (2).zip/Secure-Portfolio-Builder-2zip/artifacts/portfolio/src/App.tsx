import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { lazy, Suspense, useEffect } from "react";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/HomeEditorial";
import AdminLogin from "@/pages/AdminLogin";
import AdminDashboard from "@/pages/AdminDashboard";
import CertificateDetail from "@/pages/CertificateDetailEditorial";
import SecurityLabIndex from "@/pages/SecurityLabIndex";
import SecurityLabChallenge from "@/pages/SecurityLabChallenge";
import { Shell } from "@/components/layout/Shell";

const queryClient = new QueryClient();
const QALabPage = lazy(() => import("@/pages/QALab"));
const HackTheSystemPage = lazy(() => import("@/pages/HackTheSystem"));
const LogicBreachPage = lazy(() => import("@/pages/LogicBreachPage"));

function Router() {
  return (
    <Shell>
      <Suspense fallback={<div className="mx-auto max-w-7xl px-4 py-16 text-sm text-muted-foreground sm:px-8">Loading page…</div>}>
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/certificates/:id" component={CertificateDetail} />
          <Route path="/admin" component={AdminLogin} />
          <Route path="/admin/dashboard" component={AdminDashboard} />
          <Route path="/security-lab" component={SecurityLabIndex} />
          <Route path="/security-lab/:slug" component={SecurityLabChallenge} />
          <Route path="/qa-lab" component={QALabPage} />
          <Route path="/hack-the-system" component={HackTheSystemPage} />
          <Route path="/logic-breach" component={LogicBreachPage} />
          <Route component={NotFound} />
        </Switch>
      </Suspense>
    </Shell>
  );
}

function App() {
  useEffect(() => {
    if (window.location.pathname.endsWith("/hack-the-system") || window.location.pathname.endsWith("/logic-breach")) return;
    void fetch("/api/analytics/view", {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ path: window.location.pathname }),
    });
  }, []);
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
