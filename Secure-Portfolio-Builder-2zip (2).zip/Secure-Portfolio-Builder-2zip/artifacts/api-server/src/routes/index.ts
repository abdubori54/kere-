import { Router } from "express";
import healthRouter from "./health";
import certificatesRouter from "./certificates";
import adminRouter from "./admin";
import profileRouter from "./profile";
import terminalRouter from "./terminal";
import contactRouter from "./contact";
import settingsRouter from "./settings";
import analyticsRouter from "./analytics";
import securityLabsRouter from "./security-labs";

const router = Router();

router.use("/healthz", healthRouter);
router.use("/certificates", certificatesRouter);
router.use("/admin", adminRouter);
router.use("/profile", profileRouter);
router.use("/terminal", terminalRouter);
router.use("/contact", contactRouter);
router.use("/settings", settingsRouter);
router.use("/analytics", analyticsRouter);
router.use("/security-labs", securityLabsRouter);

export default router;
