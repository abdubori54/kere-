import { Router } from "express";
import { asc, eq, sql } from "drizzle-orm";
import { z } from "zod";
import { db, securityLabTypesTable, securityLabsTable } from "@workspace/db";
import { requireAdmin } from "../middlewares/admin";

const router = Router();
const categories = ["Web Security", "Authentication", "Input Validation", "Security Headers", "Access Control", "Secure Coding"] as const;
const demoTypes = ["xss", "auth", "headers", "access-control", "generic"] as const;
const labSchema = z.object({
  slug: z.string().trim().min(2).max(100).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/),
  title: z.string().trim().min(2).max(140),
  shortDescription: z.string().trim().min(2).max(300),
  category: z.enum(categories),
  difficulty: z.enum(["Beginner", "Intermediate", "Advanced"]),
  estimatedMinutes: z.number().int().min(1).max(180),
  learningObjective: z.string().trim().min(2).max(1000),
  challengeDescription: z.string().trim().min(2).max(2000),
  task: z.string().trim().min(2).max(1200),
  hints: z.array(z.string().trim().min(1).max(500)).max(10),
  expectedResult: z.string().trim().min(2).max(1200),
  explanation: z.string().trim().min(2).max(3000),
  demoType: z.enum(demoTypes),
  published: z.boolean(),
  enabled: z.boolean(),
  featured: z.boolean(),
  sortOrder: z.number().int().min(0).max(10000),
});
const typeSchema = z.object({ enabled: z.boolean() });

function formatLab(lab: typeof securityLabsTable.$inferSelect) {
  return {
    ...lab,
    hints: lab.hints ? lab.hints.split("\n").filter(Boolean) : [],
    createdAt: lab.createdAt.toISOString(),
    updatedAt: lab.updatedAt.toISOString(),
  };
}

function formatType(type: typeof securityLabTypesTable.$inferSelect) {
  return type;
}

router.get("/types", async (req, res) => {
  try {
    const rows = await db.select().from(securityLabTypesTable)
      .where(req.query.admin === "1" ? undefined : eq(securityLabTypesTable.enabled, true))
      .orderBy(asc(securityLabTypesTable.sortOrder));
    if (req.query.admin === "1" && !req.session?.isAdmin) return res.status(403).json({ error: "Admin access required" });
    return res.json(rows.map(formatType));
  } catch (err) {
    req.log.error({ err }, "Failed to list security lab types");
    return res.status(500).json({ error: "Failed to load lab types" });
  }
});

router.patch("/types/:id", requireAdmin, async (req, res) => {
  const id = Number(String(req.params.id));
  const parsed = typeSchema.safeParse(req.body);
  if (!Number.isInteger(id) || !parsed.success) return res.status(400).json({ error: "Invalid lab type update" });
  try {
    const [updated] = await db.update(securityLabTypesTable).set(parsed.data)
      .where(eq(securityLabTypesTable.id, id)).returning();
    if (!updated) return res.status(404).json({ error: "Lab type not found" });
    return res.json(formatType(updated));
  } catch (err) {
    req.log.error({ err }, "Failed to update security lab type");
    return res.status(500).json({ error: "Failed to update lab type" });
  }
});

router.get("/", async (req, res) => {
  if (req.query.admin === "1" && !req.session?.isAdmin) return res.status(403).json({ error: "Admin access required" });
  try {
    const rows = await db.select().from(securityLabsTable)
      .where(req.query.admin === "1" ? undefined : sql`${securityLabsTable.published} = true AND ${securityLabsTable.enabled} = true`)
      .orderBy(asc(securityLabsTable.sortOrder), asc(securityLabsTable.id));
    return res.json(rows.map(formatLab));
  } catch (err) {
    req.log.error({ err }, "Failed to list security labs");
    return res.status(500).json({ error: "Failed to load security labs" });
  }
});

router.get("/:slug", async (req, res) => {
  const slug = String(req.params.slug);
  const isAdmin = req.query.admin === "1";
  if (isAdmin && !req.session?.isAdmin) return res.status(403).json({ error: "Admin access required" });
  try {
    const [lab] = await db.select().from(securityLabsTable).where(eq(securityLabsTable.slug, slug));
    if (!lab || (!isAdmin && (!lab.published || !lab.enabled))) return res.status(404).json({ error: "Lab not found" });
    return res.json(formatLab(lab));
  } catch (err) {
    req.log.error({ err }, "Failed to get security lab");
    return res.status(500).json({ error: "Failed to load security lab" });
  }
});

router.post("/", requireAdmin, async (req, res) => {
  const parsed = labSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Please check the lab fields." });
  try {
    const [created] = await db.insert(securityLabsTable).values({ ...parsed.data, hints: parsed.data.hints.join("\n") }).returning();
    return res.status(201).json(formatLab(created));
  } catch (err) {
    req.log.error({ err }, "Failed to create security lab");
    return res.status(500).json({ error: "Failed to create security lab" });
  }
});

router.put("/:id", requireAdmin, async (req, res) => {
  const id = Number(String(req.params.id));
  const parsed = labSchema.safeParse(req.body);
  if (!Number.isInteger(id) || !parsed.success) return res.status(400).json({ error: "Please check the lab fields." });
  try {
    const [updated] = await db.update(securityLabsTable).set({ ...parsed.data, hints: parsed.data.hints.join("\n") }).where(eq(securityLabsTable.id, id)).returning();
    if (!updated) return res.status(404).json({ error: "Lab not found" });
    return res.json(formatLab(updated));
  } catch (err) {
    req.log.error({ err }, "Failed to update security lab");
    return res.status(500).json({ error: "Failed to update security lab" });
  }
});

router.delete("/:id", requireAdmin, async (req, res) => {
  const id = Number(String(req.params.id));
  if (!Number.isInteger(id)) return res.status(400).json({ error: "Invalid lab id" });
  try {
    const [deleted] = await db.delete(securityLabsTable).where(eq(securityLabsTable.id, id)).returning();
    if (!deleted) return res.status(404).json({ error: "Lab not found" });
    return res.json({ success: true });
  } catch (err) {
    req.log.error({ err }, "Failed to delete security lab");
    return res.status(500).json({ error: "Failed to delete security lab" });
  }
});

export default router;