import { Router } from "express";
import { z } from "zod";
import { db, siteSettingsTable } from "@workspace/db";
import { requireAdmin } from "../middlewares/admin";

const router = Router();
const urlOrBlank = z.string().trim().max(400).refine((value) => !value || /^https?:\/\/\S+$/i.test(value), "Must be a valid http(s) URL");
const emailOrBlank = z.string().trim().max(160).refine((value) => !value || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value), "Must be a valid email");
const settingsSchema = z.object({
  fullName: z.string().trim().max(120),
  username: z.string().trim().max(80),
  professionalTitle: z.string().trim().max(160),
  shortBio: z.string().trim().max(600),
  email: emailOrBlank,
  phone: z.string().trim().max(40),
  location: z.string().trim().max(120),
  githubUrl: urlOrBlank,
  linkedinUrl: urlOrBlank,
  telegramUrl: urlOrBlank,
  availabilityStatus: z.string().trim().max(80),
  heroTitle: z.string().trim().max(240),
  heroSubtitle: z.string().trim().max(600),
  contactText: z.string().trim().max(600),
});

async function getOrCreateSettings() {
  const [existing] = await db.select().from(siteSettingsTable).limit(1);
  if (existing) return existing;
  const [created] = await db.insert(siteSettingsTable).values({}).returning();
  return created;
}

router.get("/", async (req, res) => {
  try {
    return res.json(await getOrCreateSettings());
  } catch (err) {
    req.log.error({ err }, "Failed to get site settings");
    return res.status(500).json({ error: "Failed to load site settings" });
  }
});

router.put("/", requireAdmin, async (req, res) => {
  const parsed = settingsSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Please check the settings fields." });
  try {
    const current = await getOrCreateSettings();
    const [updated] = await db.update(siteSettingsTable).set(parsed.data).where(
      /* singleton row */ (await import("drizzle-orm")).eq(siteSettingsTable.id, current.id),
    ).returning();
    return res.json(updated);
  } catch (err) {
    req.log.error({ err }, "Failed to update site settings");
    return res.status(500).json({ error: "Failed to save site settings" });
  }
});

export default router;