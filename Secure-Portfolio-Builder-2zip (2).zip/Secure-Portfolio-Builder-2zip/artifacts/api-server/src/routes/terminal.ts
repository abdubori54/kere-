import { Router } from "express";
import { db } from "@workspace/db";
import { terminalCommandsTable } from "@workspace/db";
import { asc, eq } from "drizzle-orm";
import { requireAdmin } from "../middlewares/admin";

const router = Router();

router.get("/", async (req, res) => {
  if (req.query.admin === "1" && !req.session?.isAdmin) {
    return res.status(403).json({ error: "Admin access required" });
  }
  try {
    const rows = await db
      .select()
      .from(terminalCommandsTable)
      .where(req.query.admin === "1" ? undefined : eq(terminalCommandsTable.enabled, true))
      .orderBy(asc(terminalCommandsTable.sortOrder));
    return res.json(rows.map((row) => ({ ...row, output: row.output || row.response })));
  } catch (err) {
    req.log.error({ err }, "Failed to get terminal commands");
    return res.status(500).json({ error: "Failed to get terminal commands" });
  }
});

router.put("/", requireAdmin, async (req, res) => {
  try {
    const { commands } = req.body as {
      commands: { command: string; output?: string; response?: string; description?: string; sortOrder?: number; enabled?: boolean }[];
    };

    if (!Array.isArray(commands)) {
      return res.status(400).json({ error: "commands must be an array" });
    }

    await db.delete(terminalCommandsTable);

    if (commands.length > 0) {
      await db.insert(terminalCommandsTable).values(
        commands.map((c, i) => ({
          command: c.command.trim(),
          response: (c.output ?? c.response ?? "").trim(),
          output: (c.output ?? c.response ?? "").trim(),
          description: c.description?.trim() || null,
          sortOrder: Number.isInteger(c.sortOrder) ? c.sortOrder : i,
          enabled: c.enabled !== false,
        }))
      );
    }

    const rows = await db
      .select()
      .from(terminalCommandsTable)
      .orderBy(asc(terminalCommandsTable.sortOrder));

    req.log.info({ count: rows.length }, "Terminal commands updated");
    return res.json(rows.map((row) => ({ ...row, output: row.output || row.response })));
  } catch (err) {
    req.log.error({ err }, "Failed to update terminal commands");
    return res.status(500).json({ error: "Failed to update terminal commands" });
  }
});

export default router;
