import { Router } from "express";
import { count, desc } from "drizzle-orm";
import { db, portfolioViewsTable } from "@workspace/db";
import { requireAdmin } from "../middlewares/admin";

const router = Router();

router.post("/view", async (req, res) => {
  if (req.session.viewRecorded) return res.json({ success: true });
  try {
    await db.insert(portfolioViewsTable).values({ path: typeof req.body?.path === "string" ? req.body.path.slice(0, 120) : "/" });
    req.session.viewRecorded = true;
    return res.json({ success: true });
  } catch (err) {
    req.log.error({ err }, "Failed to record portfolio view");
    return res.status(500).json({ error: "Unable to record view" });
  }
});

router.get("/summary", requireAdmin, async (_req, res) => {
  const [result] = await db.select({ total: count() }).from(portfolioViewsTable);
  return res.json({ totalViews: Number(result?.total ?? 0) });
});

export default router;