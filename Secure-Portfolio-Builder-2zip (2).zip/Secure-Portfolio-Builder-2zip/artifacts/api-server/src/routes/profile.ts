import { Router } from "express";
import { db } from "@workspace/db";
import { profileTable } from "@workspace/db";
import { requireAdmin } from "../middlewares/admin";

const router = Router();

router.get("/", async (req, res) => {
  try {
    const rows = await db.select().from(profileTable).limit(1);
    if (rows.length === 0) {
      const [created] = await db.insert(profileTable).values({}).returning();
      return res.json(created);
    }
    return res.json(rows[0]);
  } catch (err) {
    req.log.error({ err }, "Failed to get profile");
    return res.status(500).json({ error: "Failed to get profile" });
  }
});

router.put("/", requireAdmin, async (req, res) => {
  try {
    const { name, bio, phone, email, linkedin, instagram, telegram } = req.body as {
      name?: string;
      bio?: string;
      phone?: string;
      email?: string;
      linkedin?: string;
      instagram?: string;
      telegram?: string;
    };

    const rows = await db.select().from(profileTable).limit(1);

    const values = {
      name: name ?? null,
      bio: bio ?? null,
      phone: phone ?? null,
      email: email ?? null,
      linkedin: linkedin ?? null,
      instagram: instagram ?? null,
      telegram: telegram ?? null,
    };

    let result;
    if (rows.length === 0) {
      const [created] = await db.insert(profileTable).values(values).returning();
      result = created;
    } else {
      const { eq } = await import("drizzle-orm");
      const [updated] = await db
        .update(profileTable)
        .set(values)
        .where(eq(profileTable.id, rows[0].id))
        .returning();
      result = updated;
    }

    req.log.info("Profile updated");
    return res.json(result);
  } catch (err) {
    req.log.error({ err }, "Failed to update profile");
    return res.status(500).json({ error: "Failed to update profile" });
  }
});

export default router;
