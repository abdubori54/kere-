import { Router } from "express";
import { desc, eq } from "drizzle-orm";
import { z } from "zod";
import { db, contactMessagesTable } from "@workspace/db";
import { requireAdmin } from "../middlewares/admin";

const router = Router();
const attempts = new Map<string, { count: number; resetAt: number }>();
const contactSchema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.string().trim().email().max(160),
  subject: z.string().trim().min(2).max(160),
  message: z.string().trim().min(10).max(4000),
  website: z.string().max(200).optional(),
});

function serializeMessage(message: typeof contactMessagesTable.$inferSelect) {
  return {
    id: message.id,
    name: message.name,
    email: message.email,
    subject: message.subject,
    message: message.message,
    isRead: message.isRead,
    createdAt: message.createdAt.toISOString(),
  };
}

router.post("/", async (req, res) => {
  const ip = req.ip || req.socket.remoteAddress || "unknown";
  const now = Date.now();
  const current = attempts.get(ip);
  if (!current || current.resetAt <= now) {
    attempts.set(ip, { count: 1, resetAt: now + 15 * 60 * 1000 });
  } else if (current.count >= 5) {
    return res.status(429).json({ error: "Too many messages. Please try again later." });
  } else {
    current.count += 1;
  }

  const parsed = contactSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Please check the form fields." });
  if (parsed.data.website) return res.status(400).json({ error: "Invalid submission." });

  try {
    const [created] = await db.insert(contactMessagesTable).values({
      name: parsed.data.name,
      email: parsed.data.email,
      subject: parsed.data.subject,
      message: parsed.data.message,
    }).returning();
    return res.status(201).json({ success: true, id: created.id });
  } catch (err) {
    req.log.error({ err }, "Failed to save contact message");
    return res.status(500).json({ error: "Unable to send your message right now." });
  }
});

router.get("/", requireAdmin, async (req, res) => {
  try {
    const messages = await db.select().from(contactMessagesTable).orderBy(desc(contactMessagesTable.createdAt));
    return res.json(messages.map(serializeMessage));
  } catch (err) {
    req.log.error({ err }, "Failed to list contact messages");
    return res.status(500).json({ error: "Failed to load messages" });
  }
});

router.patch("/:id", requireAdmin, async (req, res) => {
  const id = Number(String(req.params.id));
  if (!Number.isInteger(id)) return res.status(400).json({ error: "Invalid message id" });
  const parsed = z.object({ isRead: z.boolean() }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid read state" });
  try {
    const [updated] = await db.update(contactMessagesTable)
      .set({ isRead: parsed.data.isRead })
      .where(eq(contactMessagesTable.id, id))
      .returning();
    if (!updated) return res.status(404).json({ error: "Message not found" });
    return res.json(serializeMessage(updated));
  } catch (err) {
    req.log.error({ err }, "Failed to update contact message");
    return res.status(500).json({ error: "Failed to update message" });
  }
});

router.delete("/:id", requireAdmin, async (req, res) => {
  const id = Number(String(req.params.id));
  if (!Number.isInteger(id)) return res.status(400).json({ error: "Invalid message id" });
  try {
    const [deleted] = await db.delete(contactMessagesTable).where(eq(contactMessagesTable.id, id)).returning();
    if (!deleted) return res.status(404).json({ error: "Message not found" });
    return res.json({ success: true });
  } catch (err) {
    req.log.error({ err }, "Failed to delete contact message");
    return res.status(500).json({ error: "Failed to delete message" });
  }
});

export default router;