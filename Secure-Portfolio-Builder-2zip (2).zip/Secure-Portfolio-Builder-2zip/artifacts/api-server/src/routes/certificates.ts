import { Router } from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import { db } from "@workspace/db";
import { certificatesTable } from "@workspace/db";
import { eq, desc, sql } from "drizzle-orm";
import { logger } from "../lib/logger";
import { requireAdmin } from "../middlewares/admin";

const router = Router();

const UPLOADS_DIR = path.resolve(import.meta.dirname, "..", "uploads");
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname);
    const name = `${Date.now()}-${Math.random().toString(36).slice(2)}${ext}`;
    cb(null, name);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 20 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = [".pdf", ".jpg", ".jpeg", ".png", ".webp"];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowed.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error("Only PDF and image files are allowed"));
    }
  },
});

router.get("/", async (req, res) => {
  try {
    const certs = await db
      .select()
      .from(certificatesTable)
      .orderBy(desc(certificatesTable.createdAt));
    return res.json(certs.map(formatCert));
  } catch (err) {
    req.log.error({ err }, "Failed to list certificates");
    return res.status(500).json({ error: "Failed to list certificates" });
  }
});

router.get("/stats", async (req, res) => {
  try {
    const [totalResult] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(certificatesTable);

    const byCategoryRaw = await db
      .select({
        category: certificatesTable.category,
        count: sql<number>`count(*)::int`,
      })
      .from(certificatesTable)
      .groupBy(certificatesTable.category);

    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const [recentResult] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(certificatesTable)
      .where(sql`${certificatesTable.createdAt} >= ${thirtyDaysAgo}`);

    return res.json({
      total: totalResult?.count ?? 0,
      byCategory: byCategoryRaw.map((r) => ({
        category: r.category ?? "Uncategorized",
        count: r.count,
      })),
      recentCount: recentResult?.count ?? 0,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get stats");
    return res.status(500).json({ error: "Failed to get stats" });
  }
});

router.get("/:id", async (req, res) => {
  const id = parseInt(String(req.params.id), 10);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });

  try {
    const [cert] = await db
      .select()
      .from(certificatesTable)
      .where(eq(certificatesTable.id, id));

    if (!cert) return res.status(404).json({ error: "Not found" });
    return res.json(formatCert(cert));
  } catch (err) {
    req.log.error({ err }, "Failed to get certificate");
    return res.status(500).json({ error: "Failed to get certificate" });
  }
});

router.post("/", requireAdmin, upload.single("file"), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "File is required" });
    }

    const { title, issuer, description, category, issuedDate } = req.body as {
      title: string;
      issuer: string;
      description?: string;
      category?: string;
      issuedDate?: string;
    };

    if (!title || !issuer) {
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ error: "title and issuer are required" });
    }

    const ext = path.extname(req.file.originalname).toLowerCase();
    const isImage = [".jpg", ".jpeg", ".png", ".webp"].includes(ext);

    const fileUrl = `/api/files/${req.file.filename}`;
    const thumbnailUrl = isImage ? fileUrl : null;

    const [inserted] = await db
      .insert(certificatesTable)
      .values({
        title,
        issuer,
        description: description || null,
        category: category || null,
        fileUrl,
        thumbnailUrl,
        issuedDate: issuedDate || null,
      })
      .returning();

    req.log.info({ id: inserted.id }, "Certificate uploaded");
    return res.status(201).json(formatCert(inserted));
  } catch (err) {
    req.log.error({ err }, "Failed to upload certificate");
    return res.status(500).json({ error: "Failed to upload certificate" });
  }
});

router.delete("/:id", requireAdmin, async (req, res) => {
  const id = parseInt(String(req.params.id), 10);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });

  try {
    const [cert] = await db
      .select()
      .from(certificatesTable)
      .where(eq(certificatesTable.id, id));

    if (!cert) return res.status(404).json({ error: "Not found" });

    const filename = cert.fileUrl.split("/api/files/")[1];
    if (filename) {
      const filePath = path.join(UPLOADS_DIR, filename);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    }

    await db.delete(certificatesTable).where(eq(certificatesTable.id, id));
    req.log.info({ id }, "Certificate deleted");
    return res.json({ success: true });
  } catch (err) {
    req.log.error({ err }, "Failed to delete certificate");
    return res.status(500).json({ error: "Failed to delete certificate" });
  }
});

function formatCert(cert: typeof certificatesTable.$inferSelect) {
  return {
    id: cert.id,
    title: cert.title,
    issuer: cert.issuer,
    description: cert.description,
    category: cert.category,
    fileUrl: cert.fileUrl,
    thumbnailUrl: cert.thumbnailUrl,
    issuedDate: cert.issuedDate,
    createdAt: cert.createdAt.toISOString(),
  };
}

export default router;
