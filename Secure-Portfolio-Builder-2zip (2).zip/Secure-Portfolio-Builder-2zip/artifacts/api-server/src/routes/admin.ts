import { Router } from "express";
import crypto from "node:crypto";
import { count, desc, eq } from "drizzle-orm";
import { db, certificatesTable, contactMessagesTable, terminalCommandsTable, portfolioViewsTable } from "@workspace/db";
import { requireAdmin } from "../middlewares/admin";

const router = Router();

router.get("/overview", requireAdmin, async (req, res) => {
  try {
    const [[certificates], [messages], [terminal], [views]] = await Promise.all([
      db.select({ count: count() }).from(certificatesTable),
      db.select({ count: count() }).from(contactMessagesTable).where(eq(contactMessagesTable.isRead, false)),
      db.select({ count: count() }).from(terminalCommandsTable),
      db.select({ count: count() }).from(portfolioViewsTable),
    ]);
    const recentMessages = await db.select({
      id: contactMessagesTable.id,
      type: contactMessagesTable.subject,
      createdAt: contactMessagesTable.createdAt,
    }).from(contactMessagesTable).orderBy(desc(contactMessagesTable.createdAt)).limit(5);
    return res.json({
      totalProjects: 0,
      totalCertificates: Number(certificates?.count ?? 0),
      totalSkills: 0,
      totalExperience: 0,
      unreadMessages: Number(messages?.count ?? 0),
      publishedPosts: 0,
      portfolioViews: Number(views?.count ?? 0),
      terminalCommands: Number(terminal?.count ?? 0),
      recentActivity: recentMessages.map((item) => ({ id: item.id, label: item.type, createdAt: item.createdAt.toISOString() })),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to load admin overview");
    return res.status(500).json({ error: "Failed to load dashboard overview" });
  }
});

router.post("/login", (req, res) => {
  const username = typeof req.body?.username === "string" ? req.body.username : "";
  const password = typeof req.body?.password === "string" ? req.body.password : "";
  const expectedUsername = process.env.ADMIN_USERNAME || "admin";
  const expectedPassword = process.env.ADMIN_PASSWORD;
  if (!expectedPassword) return res.status(503).json({ error: "Admin access is not configured." });
  const same = (left: string, right: string) => {
    const leftBuffer = Buffer.from(left);
    const rightBuffer = Buffer.from(right);
    return leftBuffer.length === rightBuffer.length && crypto.timingSafeEqual(leftBuffer, rightBuffer);
  };
  if (!same(username, expectedUsername) || !same(password, expectedPassword)) {
    return res.status(401).json({ error: "Invalid admin credentials." });
  }
  req.session.regenerate((err) => {
    if (err) {
      req.log.error({ err }, "Admin session regeneration failed");
      return res.status(500).json({ error: "Unable to create an admin session." });
    }
    req.session.isAdmin = true;
    return res.json({ isAdmin: true });
  });
  return undefined;
});

router.post("/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      req.log.error({ err }, "Session destroy failed");
    }
  });
  res.json({ isAdmin: false });
});

router.get("/me", (req, res) => {
  return res.json({ isAdmin: req.session?.isAdmin === true });
});

export default router;
